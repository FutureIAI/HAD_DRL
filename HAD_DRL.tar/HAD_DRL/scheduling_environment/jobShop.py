# 对操作进行调度的移除和添加
from typing import List, Dict
from scheduling_environment.machine import Machine
from scheduling_environment.job import Job
from scheduling_environment.operation import Operation
from scheduling_environment.worker import Worker


class JobShop:
    def __init__(self) -> None:
        self._nr_of_jobs = 0
        self._nr_of_machines = 0
        self._nr_of_workers = 0
        self._jobs: List[Job] = []
        self._operations: List[Operation] = []
        self._machines: List[Machine] = []
        self._workers: List[Worker] = []
        self._precedence_relations_jobs: Dict[int, List[int]] = {}
        self._precedence_relations_operations: Dict[int, List[int]] = {}
        self._sequence_dependent_setup_times: List = []  # 操作之间的切换时间矩阵
        self._operations_to_be_scheduled: List[Operation] = []  # 待调度的操作列表
        self._operations_available_for_scheduling: List[Operation] = []  # 可用于调度的操作列表
        self._scheduled_operations: List[Operation] = []  # 已调度的操作列表
        self._name: str = ""  # 作业车间的名称

    def reset(self):
        self._scheduled_operations = []

        self._operations_to_be_scheduled = [  # 重置为包含所有操作的列表
            operation for operation in self._operations]

        for machine in self._machines:
            machine.reset()

        for operation in self._operations:
            operation.reset()

        for worker in self._workers:
            worker.reset()

    def __str__(self):
        return f"Instance {self._name}, {self.nr_of_jobs} jobs, {len(self.operations)} operations, {len(self.machines)} machines, {len(self.workers)} workers"

    def set_nr_of_jobs(self, nr_of_jobs: int) -> None:
        """设置作业的数量"""
        self._nr_of_jobs = nr_of_jobs

    def set_nr_of_machines(self, nr_of_machines: int) -> None:
        """设置机器的数量"""
        self._nr_of_machines = nr_of_machines

    def set_nr_of_workers(self, nr_of_workers: int) -> None:
        self._nr_of_workers = nr_of_workers

    def add_operation(self, operation) -> None:
        """向作业车间添加一个操作（同时添加到待调度的操作列表和操作列表中）"""
        self._operations_to_be_scheduled.append(operation)
        self._operations.append(operation)

    def add_machine(self, machine) -> None:
        """添加一个机器"""
        self._machines.append(machine)

    def add_worker(self, worker) -> None:
        """添加一个工人"""
        self._workers.append(worker)

    def add_job(self, job) -> None:
        """添加一个作业"""
        self._jobs.append(job)

    def add_precedence_relations_jobs(self, precedence_relations_jobs: Dict[int, List[int]]) -> None:
        """用于添加'作业'之间的前置关系（键是作业索引，值是前置作业的索引列表）"""
        self._precedence_relations_jobs = precedence_relations_jobs

    def add_precedence_relations_operations(self, precedence_relations_operations: Dict[int, List[int]]) -> None:
        """用于添加'操作'之间的前置关系（键是操作索引，值是前置操作的索引列表）"""
        self._precedence_relations_operations = precedence_relations_operations

    def add_sequence_dependent_setup_times(self, sequence_dependent_setup_times: List) -> None:
        """用于向类中添加依赖于序列的设置时间"""
        self._sequence_dependent_setup_times = sequence_dependent_setup_times

    def set_operations_available_for_scheduling(self, operations_available_for_scheduling: List) -> None:
        """用于设置可供调度的操作"""
        self._operations_available_for_scheduling = operations_available_for_scheduling

    def get_job(self, job_id):
        """用于根据作业ID获取对应的操作对象"""
        return next((job for job in self.jobs if job.job_id == job_id), None)

    def get_operation(self, operation_id):
        """根据操作ID获取相应的操作对象"""
        return next((operation for operation in self.operations if operation.operation_id == operation_id), None)

    def get_machine(self, machine_id):
        """根据机器ID获取对应的机器对象"""
        for machine in self._machines:
            if machine.machine_id == machine_id:
                return machine

    @property
    def jobs(self) -> List[Job]:
        """返回所有作业列表"""
        return self._jobs

    @property
    def nr_of_jobs(self) -> int:
        """返回作业数量"""
        return self._nr_of_jobs

    @property
    def operations(self) -> List[Operation]:
        """返回操作对象列表"""
        return self._operations

    @property
    def nr_of_operations(self) -> int:
        """返回操作的数量"""
        return len(self._operations)

    @property
    def machines(self) -> List[Machine]:
        """返回机器对象列表"""
        return self._machines

    @property
    def nr_of_machines(self) -> int:
        """返回机器数量"""
        return self._nr_of_machines

    @property
    def workers(self) -> List[Worker]:
        """返回机器对象列表"""
        return self._workers

    @property
    def nr_of_workers(self) -> int:
        """返回机器数量"""
        return self._nr_of_workers

    @property
    def operations_to_be_scheduled(self) -> List[Operation]:
        """返回待调度的操作对象列表"""
        return self._operations_to_be_scheduled

    @property
    def operations_available_for_scheduling(self) -> List[Operation]:
        """Return all the operations that are available for scheduling"""
        return self._operations_available_for_scheduling

    @property
    def scheduled_operations(self) -> List[Operation]:
        """返回可供调度的操作对象列表"""
        return self._scheduled_operations

    @property
    def precedence_relations_operations(self) -> Dict[int, List[int]]:
        """返回操作之间的先行关系"""
        return self._precedence_relations_operations

    @property
    def precedence_relations_jobs(self) -> Dict[int, List[int]]:
        """返回作业之间的先行关系"""
        return self._precedence_relations_jobs

    @property
    def instance_name(self) -> str:
        """返回实例的名称"""
        return self._name

    @property
    def makespan(self) -> float:
        """返回所有操作中最晚结束时间的最大值"""
        return max(  # 遍历机器对象和其已调度的操作对象
            [operation.scheduled_end_time for machine in self.machines for operation in machine.scheduled_operations])

    @property
    def total_workload(self) -> float:
        """返回所有已调度操作的处理时间之和"""
        return sum(  # 遍历机器对象和其已调度的操作对象
            [operation.scheduled_duration for machine in self.machines for operation in machine.scheduled_operations])

    @property
    def max_workload(self) -> float:
        """返回所有机器上所有已调度的操作处理时间之和的最大值"""
        return max(  # 计算每台机器上操作处理时间的总和
            sum(op.scheduled_duration for op in machine.scheduled_operations) for machine in self.machines)

    def schedule_operation_with_backfilling(self, operation: Operation, machine_id, duration) -> None:
        """调度一个操作"""
        if operation not in self.operations_available_for_scheduling:  # 检查要调度的操作是否在可供调度的操作列表中
            raise ValueError(
                f"Operation {operation.operation_id} is not available for scheduling")
        machine = self.get_machine(machine_id)  # 通过给定的机器ID获取对应的机器对象
        if not machine:
            raise ValueError(
                f"Invalid machine ID {machine_id}")
        # 使用后填充 backfilling 算法，在指定的机器上调度操作，并传入指定的持续时间
        self.schedule_operation_on_machine_backfilling(operation, machine_id, duration)
        self.mark_operation_as_scheduled(operation)  # 将操作标记为已调度

    def unschedule_operation(self, operation: Operation) -> None:
        """取消调度一个操作"""
        machine = self.get_machine(operation.scheduled_machine)  # 通过操作对象的性获取对应的机器对象
        machine.unschedule_operation(operation)
        self.mark_operation_as_available(operation)  # 标记为可供调度，即将其添加回可供调度的操作列表中

    def schedule_operation_on_machine_backfilling(self, operation: Operation, machine_id, duration) -> None:
        """用于在指定的机器上使用后填充算法进行操作调度"""
        machine = self.get_machine(machine_id)
        if machine is None:
            raise ValueError(
                f"Invalid machine ID {machine_id}")

        machine.add_operation_to_schedule_backfilling(
            operation, duration, self._sequence_dependent_setup_times)

    def mark_operation_as_scheduled(self, operation: Operation) -> None:
        """用于将操作标记为已调度"""
        if operation not in self.operations_available_for_scheduling:  # 检查要标记的操作是否在可供调度的操作列表中
            raise ValueError(
                f"Operation {operation.operation_id} is not available for scheduling")
        self.operations_available_for_scheduling.remove(operation)  # 从可供调度的操作列表中移除
        self.scheduled_operations.append(operation)  # 将操作添加到已调度的操作列表中
        self.operations_to_be_scheduled.remove(operation)  # 从待调度的操作列表中移除

    def mark_operation_as_available(self, operation: Operation) -> None:
        """将操作标记为可供调度"""
        if operation not in self.scheduled_operations:
            raise ValueError(
                f"Operation {operation.operation_id} is not scheduled")
        self.scheduled_operations.remove(operation)  # 从已调度的操作列表中移除
        self.operations_available_for_scheduling.append(operation)  # 添加到可供调度的操作列表中
        self.operations_to_be_scheduled.append(operation)  # 添加到待调度的操作列表中
