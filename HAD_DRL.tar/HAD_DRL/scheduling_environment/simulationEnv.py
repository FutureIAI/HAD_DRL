# 模拟连续作业到达的生成逻辑
import simpy  # 建立离散事件模型，并对仿真系统进行分析和优化
import random
from typing import Optional, List, Dict

from scheduling_environment.jobShop import JobShop
from scheduling_environment.machine import Machine
from scheduling_environment.job import Job
from scheduling_environment.operation import Operation


class SimulationEnv:
    """
    在线车间调度环境主类
    """

    def __init__(self, online_arrivals: bool):  # 表示是否启用在线作业到达
        self.simulator = simpy.Environment()
        self.JobShop = JobShop()
        self.online_arrivals = online_arrivals
        self.machine_resources = []  # 用于存储所有的机器资源
        self.processed_operations = set()

        # 与在线作业到达相关的参数
        self.inter_arrival_time: Optional[int] = None  # 作业之间的平均时差
        self.min_nr_operations_per_job = None  # 每个作业的最小操作数
        self.max_nr_operations_per_job = None  # 每个作业的最大操作数
        self.min_duration_per_operation = None  # 每个操作的最小持续时间
        self.max_duration_per_operation = None  # 每个操作的最大持续时间

    def set_online_arrival_details(self, parameters: Dict[str, int]) -> None:
        """设置在线作业到达的参数的函数"""
        self.inter_arrival_time = parameters['inter_arrival_time']
        self.min_nr_operations_per_job = parameters['min_nr_operations_per_job']
        self.max_nr_operations_per_job = parameters['max_nr_operations_per_job']
        self.min_duration_per_operation = parameters['min_duration_per_operation']
        self.max_duration_per_operation = parameters['max_duration_per_operation']

    def add_machine_resources(self) -> None:
        """向环境中添加一台机器"""
        self.machine_resources.append(simpy.Resource(self.simulator, capacity=1))  # 资源的容量为1，每次只能由一个进程使用

    def perform_operation(self, operation, machine):
        """在机器上执行操作（阻塞资源一段时间）"""
        if machine.machine_id in operation.processing_times:  # 该机器能够处理该操作
            with self.machine_resources[machine.machine_id].request() as req:  # 请求该机器资源，并将请求存储在 req 变量中
                yield req  # 使用语句暂停方法的执行，直到该机器资源可用时继续执行
                start_time = self.simulator.now  # 获取开始时间和在该机器上的运行时间
                processing_time = operation.processing_times[machine.machine_id]
                # print('scheduled job:', operation.job_id, 'operation:', operation.operation_id, 'at', start_time, 'taking', processing_time)
                # 在该机器上安排操作的执行时间
                machine.add_operation_to_schedule_at_time(operation, start_time, processing_time, setup_time=0)
                yield self.simulator.timeout(processing_time - 0.0001)  # 模拟操作在机器上执行所需的时间（减去一个微小的时间偏移量）
                # print('machine', machine.machine_id, 'released at time', simulationEnv.simulator.now)

                self.processed_operations.add(operation)  # 添加到已处理调度列表

    def generate_online_job_arrivals(self):
        """实现了在线作业到达的生成逻辑(online arrivals==True)"""
        job_id = 0
        operation_id = 0

        for id_machine in range(0, self.JobShop.nr_of_machines):
            self.JobShop.add_machine((Machine(id_machine)))
            self.add_machine_resources()

        while True:  # 使用一个无限循环来模拟连续的作业到达
            inter_arrival_time = random.expovariate(1.0 / self.inter_arrival_time)  # 根据指数分布生成作业到达之间的时间间隔
            yield self.simulator.timeout(inter_arrival_time)  # 返回一个延迟对象，将在指定的时间间隔后触发继续执行循环

            # 作业生成逻辑
            counter = 0
            job = Job(job_id)

            # Add some logic to generate operations for each job 为每个作业添加逻辑生成操作
            num_operations = random.randint(self.min_nr_operations_per_job,  # 生成每个作业的操作数量
                                            self.max_nr_operations_per_job)
            for i in range(num_operations):
                operation = Operation(job, job_id, operation_id)  # 创建一个新的操作对象
                self.JobShop.add_operation(operation)
                for machine_id in range(self.JobShop.nr_of_machines):  # 为每个机器生成运行时间
                    duration = random.randint(self.min_duration_per_operation,
                                              self.max_duration_per_operation)
                    operation.add_operation_option(machine_id, duration)  # 生成操作选项
                job.add_operation(operation)
                if counter != 0:  # 对于除第一个操作外的其他操作，建立前序关系以确保操作的顺序性
                    self.JobShop.precedence_relations_operations[operation_id] = [job.get_operation(operation_id - 1)]
                    operation.add_predecessors([job.get_operation(operation_id - 1)])
                else:
                    self.JobShop.precedence_relations_operations[operation_id] = []

                counter += 1
                operation_id += 1

            self.JobShop.add_job(job)
            # print(f"Job {job_id} generated with {num_operations} operations")  # Debugging print statement
            job_id += 1