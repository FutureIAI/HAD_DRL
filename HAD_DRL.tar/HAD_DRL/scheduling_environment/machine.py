# 关于机器的信息获取，寻找back filling 更新信息
from typing import List
from scheduling_environment.operation import Operation


class Machine:
    def __init__(self, machine_id, machine_idlepower, machine_opepower):
        self._machine_id = machine_id
        self._machine_idlepower = machine_idlepower
        self._machine_opepower = machine_opepower
        self._processed_operations = []  # 已处理的操作列表

    def reset(self):
        self._processed_operations = []

    def __str__(self):  # 返回一个包含机器ID和已调度操作数的字符串
        return f"Machine {self._machine_id}, {len(self._processed_operations)} scheduled operations"

    @property
    def machine_id(self):
        """返回机器ID"""
        return self._machine_id

    @property
    def machine_idlepower(self):
        """返回机器空闲单位能耗"""
        return self._machine_idlepower

    @property
    def machine_opepower(self):
        """返回机器运行单位能耗"""
        return self._machine_opepower

    @property
    def scheduled_operations(self) -> List[Operation]:
        """返回在该机器上已调度的操作列表"""
        sorted_operations = sorted(self._processed_operations, key=lambda op: op['start_time'])
        return [op['operation'] for op in sorted_operations]

    def get_idlepower(self, machine_id):
        if machine_id == self.machine_id:
            return self._machine_idlepower

    def get_opepower(self, machine_id):
        if machine_id == self.machine_id:
            return self._machine_opepower

    def add_operation_to_schedule_at_time(self, operation, start_time, processing_time, setup_time):
        """用于将操作添加到机器的调度中"""
        operation.add_operation_scheduling_information(self.machine_id, start_time, setup_time, processing_time)

        self._processed_operations.append({
            'operation': operation,
            'start_time': start_time,
            'end_time': start_time + processing_time,
            'processing_time': processing_time,
            'start_setup': start_time - setup_time,  # 设置开始时间
            'end_setup': start_time,  # 设置结束时间（开始时间）
            'setup_time': setup_time  # 设置时间
        })

    def add_operation_to_schedule_backfilling(self, operation: Operation, processing_time, sequence_dependent_setup_times):
        """将操作加入机器的调度序列，并使用 backfilling 算法进行调度"""

        # 找到最晚完成时间
        finishing_time_predecessors = operation.finishing_time_predecessors  # 表示当前操作的前置操作的完成时间列表
        finishing_time_machine = max([operation.scheduled_end_time for operation in self.scheduled_operations],
                                     default=0)

        setup_time = 0
        if len(self.scheduled_operations) != 0:  # 计算操作之间的切换时间 setup_time
            setup_time = \
                sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[-1].operation_id][
                    operation.operation_id]  # 二维矩阵，第一维索引表示当前机器的 ID，第二维索引表示前一个操作的 ID，而值表示两个操作之间的切换时间

        # backfilling 机会指的是，当前有一些操作虽然在当前操作之前开始，但是它们可以在当前操作之后结束
        start_time_backfilling, setup_time_backfilling = self.find_backfilling_opportunity(
            operation, finishing_time_predecessors, processing_time, sequence_dependent_setup_times)

        if start_time_backfilling is not None:
            start_time = start_time_backfilling
            setup_time = setup_time_backfilling
        else:
            # 不存在，就把当前操作安排在最晚完成时间和前置操作完成时间之间的最大值
            start_time = max(finishing_time_predecessors, finishing_time_machine + setup_time)

        operation.add_operation_scheduling_information(
            self.machine_id, start_time, setup_time, processing_time)

        self._processed_operations.append({
            'operation': operation,
            'start_time': start_time,
            'end_time': start_time + processing_time,
            'processing_time': processing_time,
            'start_setup': start_time-setup_time,
            'end_setup': start_time,
            'setup_time': setup_time
        })

    def find_backfilling_opportunity(self, operation, finishing_time_predecessors, duration, sequence_dependent_setup_times):
        """用于在机器上找到一个可以插入操作的最早时间点"""

        if len(self.scheduled_operations) > 0:  # 是否调度列表为空
            # 检查是否可以在第一个已调度操作之前进行 backfilling:
            if duration <= self.scheduled_operations[0].scheduled_start_time - sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[0].operation_id] \
                    and finishing_time_predecessors <= self.scheduled_operations[0].scheduled_start_time - duration - sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[0].operation_id]:
                start_time_backfilling = min([finishing_time_predecessors, (self.scheduled_operations[0].scheduled_start_time - duration -
                                             sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[0].operation_id])])

                # 更新下一个操作的切换时间，接收两个参数（新的起始时间和新的切换时间）
                next_operation = self.scheduled_operations[0]  # 获取第一个已调度操作的引用
                next_operation.update_sequence_dependent_setup_times(next_operation.scheduled_start_time - sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[0].operation_id],
                                                                     sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[0].operation_id])
                # 假设第一个已调度操作没有切换时间
                return start_time_backfilling, 0

            else:
                for i in range(1, len(self.scheduled_operations[1:])):  # 遍历从第二个已调度操作开始的操作列表
                    # 是否有足够大的间隔可以容纳新的操作（包括切换时间）
                    if (self.scheduled_operations[i].scheduled_start_time - self.scheduled_operations[i - 1].scheduled_end_time) >= \
                            duration + sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id] + sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id]:

                        # 检查前置操作是否在可能的起始时间之前完成
                        if self.scheduled_operations[i - 1].scheduled_end_time + sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id] >= finishing_time_predecessors:
                            # 更新下一个操作的切换时间
                            self.scheduled_operations[i].update_sequence_dependent_setup_times(
                                self.scheduled_operations[i].scheduled_start_time - sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id],
                                sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id])
                            # 返回前一个操作的结束时间加上前一个操作与当前操作之间的切换时间作为起始时间，以及前一个操作与当前操作之间的切换时间
                            return self.scheduled_operations[i - 1].scheduled_end_time + sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id], sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id]
                        # 判断当前操作的前置操作的完成时间加上当前操作的切换时间和持续时间是否小于等于前一个操作的结束时间
                        elif finishing_time_predecessors + sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id] + duration <= self.scheduled_operations[i - 1].scheduled_end_time:
                            self.scheduled_operations[i].update_sequence_dependent_setup_times(
                                self.scheduled_operations[i].scheduled_start_time -
                                sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id],
                                sequence_dependent_setup_times[self.machine_id][operation.operation_id][self.scheduled_operations[i].operation_id])
                            return finishing_time_predecessors + sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id], sequence_dependent_setup_times[self.machine_id][self.scheduled_operations[i - 1].operation_id][operation.operation_id]
        return None, None

    def unschedule_operation(self, operation: Operation):
        """用于从机器的已调度操作列表中移除一个操作"""
        self._processed_operations.remove(operation)
