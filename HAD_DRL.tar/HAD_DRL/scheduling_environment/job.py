# 关于job的信息获取
from .operation import Operation
from typing import List


class Job:
    def __init__(self, job_id: int):
        self._job_id: int = job_id
        self._operations: List[Operation] = []  # 作业中包含的操作列表，每个操作都是Operation类的实例

    def add_operation(self, operation: Operation):
        """向作业中添加一个操作"""
        self._operations.append(operation)

    @property
    def nr_of_ops(self) -> int:
        """返回作业中操作的数量"""
        return len(self._operations)

    @property
    def operations(self) -> List[Operation]:
        """返回作业中的操作列表"""
        return self._operations

    @property
    def job_id(self) -> int:
        """返回作业ID"""
        return self._job_id

    def get_operation(self, operation_id):
        """获取作业job中ID为operation_id的操作对象"""
        for operation in self._operations:  # 检查其操作ID是否与传入的operation_id相等
            if operation.operation_id == operation_id:
                return operation