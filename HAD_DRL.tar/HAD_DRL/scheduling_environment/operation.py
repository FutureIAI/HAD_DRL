# 关于操作的一些信息获取
from typing import List, Dict
from collections import OrderedDict


class Operation:
    def __init__(self, job, job_id, operation_id):
        self._job = job
        self._job_id = job_id
        self._operation_id = operation_id
        self._processing_times = OrderedDict()  # 用有序字典存储当前操作的加工时间
        self._processing_power = OrderedDict()
        self._predecessors: List = []  # 存储当前操作的前驱操作列表
        self._scheduling_information = {}  # 用于存储与当前操作相关的调度信息

    def reset(self):
        self._scheduling_information = {}

    def __str__(self):  # 返回字符串表示形式
        return f"Job {self.job_id}, Operation {self.operation_id}"

    # 装饰器属性，没有settle方法，因为是只可读属性
    @property
    def job(self):
        """返回当前操作所属的作业对象"""
        return self._job

    @property
    def job_id(self) -> int:
        """返回当前操作所属的作业ID"""
        return self._job_id

    @property
    def operation_id(self) -> int:
        """返回当前操作的ID"""
        return self._operation_id

    @property
    def scheduling_information(self) -> Dict:
        """返回与当前操作相关的调度信息"""
        return self._scheduling_information

    @property
    def processing_times(self) -> dict:
        """返回当前操作的加工时间字典，键表示机器ID，值表示对应机器上的加工时间"""
        return self._processing_times

    @property
    def processing_power(self) -> dict:
        """返回当前操作的加工时间字典，键表示机器ID，值表示对应机器上的加工时间"""
        return self._processing_power

    @property
    def scheduled_start_time(self) -> int:
        """返回当前操作的调度开始时间"""
        if 'start_time' in self._scheduling_information:
            return self._scheduling_information['start_time']
        return None

    @property
    def scheduled_end_time(self) -> int:
        """返回当前操作的调度结束时间"""
        if 'end_time' in self._scheduling_information:
            return self._scheduling_information['end_time']
        return None

    @property
    def scheduled_duration(self) -> int:
        """返回当前操作的调度持续时间"""
        return self._scheduled_duration

    @property
    def scheduled_machine(self) -> None:
        """返回当前操作所调度的机器ID"""
        if 'machine_id' in self._scheduling_information:
            return self._scheduling_information['machine_id']
        return None

    @property
    def predecessors(self) -> List:
        """返回当前操作的前驱操作列表"""
        return self._predecessors

    @property
    def finishing_time_predecessors(self) -> int:
        """返回所有前驱操作中最晚的结束时间"""
        if not self.predecessors:
            return 0
        end_times_predecessors = [operation.scheduled_end_time for operation in self.predecessors]
        return max(end_times_predecessors)

    def update_job_id(self, new_job_id: int) -> None:
        """更新作业的ID（用于装配调度问题，没有预设的作业ID）"""
        self._job_id = new_job_id

    def update_job(self, job) -> None:
        """将当前操作所属的作业更新为新的作业对象"""
        self._job = job

    def add_predecessors(self, predecessors: List) -> None:
        """向当前操作添加一组前驱操作"""
        self.predecessors.extend(predecessors)

    def add_operation_option(self, machine_id, duration, power) -> None:
        """添加一个操作，将一个机器ID和对应的加工时间添加到当前操作的加工时间字典"""
        self._processing_times[machine_id] = duration
        self._processing_power[machine_id] = power

    def update_sequence_dependent_setup_times(self, start_time_setup, setup_duration):
        """将当前操作的设置开始时间和设置持续时间更新为新的值"""
        self._start_time_setup = start_time_setup
        self._setup_duration = setup_duration

    def add_operation_scheduling_information(self, machine_id: int, start_time: int, setup_time: int, duration) -> None:
        """将机器ID、开始时间、结束时间和持续时间等信息添加到当前操作的调度信息字典中"""
        self._scheduling_information = {
            'machine_id': machine_id,
            'start_time': start_time,
            'end_time': start_time + duration,
            'processing_time': duration,
            'start_setup': start_time - setup_time,  # 开始时间 -设置时间
            'end_setup': start_time,
            'setup_time': setup_time}
