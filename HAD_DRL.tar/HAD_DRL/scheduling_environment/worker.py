# 关于机器的信息获取，寻找back filling 更新信息
from typing import List
from scheduling_environment.machine import Machine
from collections import OrderedDict


class Worker:
    def __init__(self, worker_id):
        self._worker_id = worker_id
        self._worker_first = OrderedDict()
        self._worker_end = OrderedDict()
        self._processed_operations = []  # 已处理的操作列表

    def reset(self):
        self._processed_operations = []

    def __str__(self):  # 返回一个包含工人ID和已调度操作数的字符串
        return f"Worer {self._worker_id}, {len(self._processed_operations)} scheduled operations"

    @property
    def worker_id(self):
        """返回工人ID"""
        return self._worker_id

    @property
    def worker_first(self) -> dict:
        """返回当前操作的加工时间字典，键表示工人ID，值表示对应机器上的初始率"""
        return self._worker_first

    @property
    def worker_end(self) -> dict:
        """返回当前操作的加工时间字典，键表示工人ID，值表示对应机器上的最终率"""
        return self._worker_end

    def add_worker_first(self, machine_id, first_rate) -> None:
        """添加一个操作，将一个机器ID和对应的初始率添加到当前工人的学习率字典"""
        self._worker_first[machine_id] = first_rate

    def add_worker_end(self, machine_id, end_rate) -> None:
        """添加一个操作，将一个机器ID和对应的最终率添加到当前工人的学习率字典"""
        self._worker_end[machine_id] = end_rate
