# 数据不是在线生成的，打开文件，建立前驱矩阵
from pathlib import Path
import re

from scheduling_environment.machine import Machine
from scheduling_environment.job import Job
from scheduling_environment.operation import Operation
from scheduling_environment.worker import Worker


def parse(JobShop, instance, from_absolute_path=False):
    # 根据from_absolute_path的值来选择要打开的文件路径
    if not from_absolute_path:  # 如果from_absolute_path为False，则使用当前文件的父目录的绝对路径构建data_path
        base_path = Path(__file__).parent.parent.absolute()
        data_path = base_path.joinpath('data' + instance)
    else:  # 如果from_absolute_path为True，则直接将instance赋值给data_path
        data_path = instance

    with open(data_path, "r") as data:  # 使用open()函数打开data_path指定的文件
        total_operations, total_precedence_relations, total_machines, total_workers = re.findall('\S+', data.readline())  # 读取文件的第一行
        number_total_operations, number_precedence_relations, number_total_machines, number_total_workers = int(
            total_operations), int(total_precedence_relations), int(total_machines), int(total_workers)  # 转换为 int 类型

        precedence_relations = {}
        job_id = 10000
        ope_power = []

        for key, line in enumerate(data):  # 使用enumerate()遍历data列表，为每个元素生成一个索引key和相应的行内容line
            # 划分数据 with multiple spaces as separator
            parsed_line = re.findall('\S+', line)

            # 设置 machine
            if key == 0:
                i = 0
                while i < len(parsed_line):
                    for machine_id in range(0, number_total_machines):  # 添加操作的机器编号和处理时间
                        idlepower = int(parsed_line[i])
                        opepower = int(parsed_line[i + 1])
                        ope_power.append(opepower)
                        JobShop.add_machine((Machine(machine_id, idlepower, opepower)))
                        i += 2

            # 构建一个操作的先后关系字典，字典中每个键都是一个后继操作，对应的值是一个包含其前驱操作的列表 [0,1] --> {1:[0]}
            # 检查parsed_line列表中索引为1的元素是否已存在于precedence_relations的键集中，即检查先后关系中的后继操作是否已经在字典中有对应的键
            elif (key <= number_precedence_relations) & (key >= 1):  # 遍历前驱关系
                if int(parsed_line[1]) in precedence_relations.keys():
                    # 存在于字典的键集中，那么它将当前操作追加到对应的前驱操作列表里
                    precedence_relations[int(parsed_line[1])].append(int(parsed_line[0]))
                else:
                    # 创建一个新的键值对，将后继操作作为键，将当前操作作为值的列表并插入字典中
                    precedence_relations[int(parsed_line[1])] = [int(parsed_line[0])]

            elif ((key > number_precedence_relations) & (key <= number_precedence_relations + number_total_operations)) :  # 遍历操作时间
                i = 0
                while i < len(parsed_line):
                    # 操作的总选项数
                    operation_options = int(parsed_line[0])  # 列表的第一个数表示操作总数
                    # 操作的可能选项数
                    operation_id = key - number_precedence_relations - 1  # 操作 ID
                    operation = Operation(None, job_id, operation_id)  # 创建一个Operation对象，并设置其所属的作业ID和操作ID
                    for operation_option_id in range(operation_options):  # 添加操作的机器编号和处理时间
                        machine_id = int(parsed_line[i + (2 * operation_option_id) + 1])
                        duration = int(parsed_line[i + (2 * operation_option_id) + 2])
                        power = duration * ope_power[machine_id]
                        operation.add_operation_option(machine_id, duration, power)
                    JobShop.add_operation(operation)  # 同时添加到待调度的操作列表和操作列表中

                    i += 1 + 2 * operation_options  # 指向下一个操作选项总数的位置
            else:
                worker_id = key - number_precedence_relations - number_total_operations - 1
                worker = Worker(worker_id)
                i = 0
                for worker_option_id in range(number_total_machines):
                    machine_id = worker_option_id
                    first_rate = float(parsed_line[i])
                    end_rate = float(parsed_line[i + 1])
                    worker.add_worker_first(machine_id, first_rate)
                    worker.add_worker_end(machine_id, end_rate)
                    i += 2
                JobShop.add_worker(worker)


    # 将没有前驱操作的操作也添加到前驱关系字典中
    for operation in JobShop.operations:
        if operation.operation_id not in precedence_relations.keys():
            # 不存在，将该操作ID添加为新键，并将值设置为空列表
            precedence_relations[operation.operation_id] = []
        else:
            # 若存在，将其对应的值由操作ID列表转换为操作对象列表
            precedence_relations[operation.operation_id] = [JobShop.get_operation(
                operation_id) for operation_id in precedence_relations[operation.operation_id]]
        operation.add_predecessors(  # 将前驱操作添加到当前操作的前驱列表中
            precedence_relations[operation.operation_id])

    # 三维列表（由多个二维列表组成），并将其初始化为全零，遍历获得每个机器间的操作设置时间
    # number_total_machines行，len(JobShop.operations)列，每列 len(JobShop.operations)个元素
    sequence_dependent_setup_times = [[[0 for r in range(len(JobShop.operations))] for t in range(len(JobShop.operations))] for
                                      m in range(number_total_machines)]

    # 为无前驱的操作创造虚拟 job_ids
    job_id = 0
    for operation in JobShop.operations:
        # 如果前驱为空，表示是一个新作业的起始操作
        if precedence_relations[operation.operation_id] == []:
            operation.update_job_id(job_id)  # 将当前操作的作业ID更新为job_id
            job = Job(job_id)  # 创建一个新的作业对象Job，并将其添加到JobShop中
            JobShop.add_job(job)
            job_id += 1  # 递增job_id的值，以便为下一个作业分配新的作业ID

    # 根据前驱操作的数量和前驱操作之间的关系，更新 job_id
    for operation in JobShop.operations:
        if operation.job_id == 10000:
            # 统计当前操作是前驱操作的次数，and，当前操作的前驱操作列表长度（后驱 and 前驱）
            if sum(predecessors.count(operation) for predecessors in precedence_relations.values()) > 1 or len(
                    precedence_relations[operation.operation_id]) > 1:  # 表示当前操作是一个新的作业的起始操作
                operation.update_job_id(job_id)
                job = Job(job_id)
                JobShop.add_job(job)
                job_id += 1

            elif sum(predecessors.count(operation) for predecessors in precedence_relations.values()) == 1 or len(
                    precedence_relations[operation.operation_id]) == 1:  # 前驱操作数 =1，or，后驱操作数 =1
                if sum(predecessors.count(precedence_relations[operation.operation_id][0]) for predecessors in
                       precedence_relations.values()) > 1:  # 前驱操作的后继操作数 > 1
                    operation.update_job_id(job_id)
                    job = Job(job_id)
                    JobShop.add_job(job)
                    job_id += 1

                else:  # 更新为前驱操作的Job_id（形似--xx--）
                    predecessor_job_id = precedence_relations[operation.operation_id][0].job_id
                    operation.update_job_id(predecessor_job_id)

            elif sum(predecessors.count(operation) for predecessors in precedence_relations.values()) == 0 and len(
                    precedence_relations[operation.operation_id]) == 1:  # 前驱 = 1，后继 = 0
                predecessor_job_id = precedence_relations[operation.operation_id][0].job_id
                operation.update_job_id(predecessor_job_id)

    for operation in JobShop.operations:
        job = JobShop.get_job(operation.job_id)
        job.add_operation(operation)
        operation.update_job(job)

    precedence_relations_jobs = {}  # 用于存储每个作业的前驱作业列表
    for operation in JobShop.operations:
        if operation.job_id not in precedence_relations_jobs.keys():
            precedence_relations_jobs[operation.job_id] = [prec.job_id for prec in
                                                           precedence_relations[operation.operation_id]]
        else:
            precedence_relations_jobs[operation.job_id].extend(  # 添加前驱作业ID
                [prec.job_id for prec in precedence_relations[operation.operation_id]])

    for key, values in precedence_relations_jobs.items():
        # 移除重复值
        values = list(set(values))

        # 移除等于键的值
        values = [value for value in values if value != key]

        precedence_relations_jobs[key] = values

    # 前驱关系 & 序列相关的切换时间
    JobShop.add_precedence_relations_jobs(precedence_relations_jobs)  # 存储的作业间前驱关系
    JobShop.add_precedence_relations_operations(precedence_relations)  # 存储的操作间前驱关系
    JobShop.add_sequence_dependent_setup_times(sequence_dependent_setup_times)  # 序列相关的设备设置时间

    JobShop.set_nr_of_jobs(len(JobShop.jobs))  # 设置作业数量
    JobShop.set_nr_of_machines(number_total_machines)  # 设置总机器数
    JobShop.set_nr_of_workers(number_total_workers)

    return JobShop
