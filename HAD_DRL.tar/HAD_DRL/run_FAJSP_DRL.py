# GITHUB REPO: https://github.com/songwenas12/fjsp-drl

import argparse
import copy
import logging
import math
import time
from datetime import datetime

import gym
import numpy as np
import ctypes
import torch
import matplotlib.pyplot as plt

from plotting.drawer import draw_gantt
from scheduling_environment.simulationEnv import SimulationEnv
from solutions.FAJSP_DRL import PPO_model, DQN
from solutions.FAJSP_DRL.env import FAJSPEnv
from solutions.FAJSP_DRL.load_data import nums_detec
from solutions.helper_functions import load_parameters

logging.basicConfig(level=logging.INFO)

PARAM_FILE = "configs/FAJSP_DRL.toml"
DEFAULT_RESULTS_ROOT = "./results/single_runs"  # 表示默认的结果存储目录的路径


def schedule(env: FAJSPEnv, model: PPO_model.PPO, model_DQN: DQN.DQN, memories, flag_sample=False, flag_train=True):
    """
    使用给定的模型和记忆安排提供的环境（用于将模型预测的动作应用于环境并进行调度）

    Parameters:
    - env:  调度的环境
    - model: 用于调度的模型
    - memories:  与模型一起使用的记忆
    - flag_sample: 确定是否应该执行采样的标志

    Returns:
    - A deep copy of the makespan batch from the environment.  环境中完成时间批次的深拷贝
    """

    # 初始化环境状态和完成信号
    T = 1
    x = []
    goal1 = []
    goal2 = []
    start_time = time.time()
    pairs = []
    # state = env.state
    rewards = []
    optical_env = env.reset()
    ma_b = 0
    ene_b = 0

    for episode in range(T):

        state = env.reset()
        dones = env.done_batch  # 指示每个任务是否已完成
        done = False
        n1 = 0
        n2 = 0

        # 循环直到所有任务完成
        while not done:
            # 无需累积梯度预测下一个动作（torch.no_grad禁止梯度计算）
            with torch.no_grad():
                prob, weight = model_DQN.net_weight(state, 0)
                print(prob)
                print(weight)
                # if weight[0] >= 0.5:  # 次数加
                #     n1 += 1
                # else:
                #     n2 += 1
                # print(n1, n2)
                n1 += weight[0]  # 概率加
                n2 += weight[1]
                actions = model.policy_old.act(state, memories, weight, flag_sample=flag_sample, flag_train=flag_train)
                s = copy.deepcopy(state)  # s

            # 根据预测的动作更新环境状态
            print(actions)
            state, N, dones = env.step(actions, weight)  # s'
            done = dones.all()
            if done == False:
                model_DQN.reward_batch(s, actions, state, N)
            memories.rewards.append(copy.deepcopy(state.reward))
            memories.is_terminals.append(copy.deepcopy(dones))
            loss_a, reward_a = model.update(memories)
            print(loss_a, reward_a)

        # 检查生成的甘特图的有效性（仅适用于FJSP）
        if not env.validate_gantt()[0]:
            print("Scheduling Error!")
        # else:
        #     # draw_pre_rela(env)
        #     draw_gantt(env)
        #     draw_reward(env)

        # # 绘制甘特图
        # for ix, sim_env in enumerate(env.simulation_envs):
        #     draw_gantt_chart(sim_env)
        ma = env.reward_batch[:, env.N[0].item(), 0].item()
        ene = env.reward_batch[:, env.N[0].item(), 1].item()
        # re = -(1 / 5) * (torch.log(n1 * ma)) + (-(1 / 5) * (torch.log(n2 * ene)))
        print("jianglizhi:", n1 * ma, n2 * ene)
        print("奖励值：", torch.log(n1 * ma), torch.log(n2 * ene))
        # rewards.append(-((1 / 100) * n1 * torch.log(torch.Tensor([ma])) + (1 / 100) * n2 * torch.log(torch.Tensor([ene]))))  # 次数加
        rewards.append((-(1 / 5) * (torch.log(n1 * ma))) + (-(1 / 5) * (torch.log(n2 * ene))))  # 概率加
        goal1.append(ma)
        goal2.append(ene)
        pairs.append([ma, ene])
        # rewards.append((-1) * (1 / 1000) * ma)  # 单

        if episode == 0:
            optical_env = env
            ma_b = optical_env.reward_batch[:, optical_env.N[0].item(), 0].item()
            ene_b = optical_env.reward_batch[:, optical_env.N[0].item(), 1].item()
        elif (ma < ma_b) and (ene < ene_b) and (episode > 0):
            optical_env = copy.deepcopy(env)
            ma_b = ma
            ene_b = ene
    print(ma_b, ene_b)
    end_time = time.time()
    run_time = end_time - start_time

    print(f"//////////////程序运行时间为 {run_time:.4f} 秒////////////////")
    window_size = 10
    moving_average1 = np.convolve(goal1, np.ones(window_size)/window_size, mode='valid')
    current_date = datetime.now().strftime('%Y-%m-%d-%H%M')
    plt.subplot(1, 1, 1)
    plt.plot(x, goal1, label='makespan')
    plt.plot(x[window_size - 1:], moving_average1, label='移动平均', color='red', linewidth=2)
    plt.xlabel('T')
    plt.ylabel('makespan')
    plt.title('MakeSpan_Total')
    plt.tight_layout()
    plt.savefig(f'C:/Users/CGZ/Desktop/result/MakeSpan{current_date}.png', format='png')
    plt.show()

    moving_average2 = np.convolve(goal2, np.ones(window_size)/window_size, mode='valid')
    plt.subplot(1, 1, 1)
    plt.plot(x, goal2, label='power')
    plt.plot(x[window_size - 1:], moving_average2, label='移动平均', color='red', linewidth=2)
    plt.xlabel('T')
    plt.ylabel('power')
    plt.title('Energe_Total')
    plt.tight_layout()
    plt.savefig(f'C:/Users/CGZ/Desktop/result/Energe{current_date}.png', format='png')
    plt.show()

    moving_average3 = np.convolve(rewards, np.ones(window_size) / window_size, mode='valid')
    plt.subplot(1, 1, 1)
    plt.plot(x, rewards, label='rewards')
    plt.plot(x[window_size - 1:], moving_average3, label='移动平均', color='red', linewidth=2)
    plt.xlabel('T')
    plt.ylabel('rewards')
    plt.title('Reward_Total')
    plt.tight_layout()
    plt.savefig(f'C:/Users/CGZ/Desktop/result/Reward{current_date}.png', format='png')
    plt.show()

    model.save(current_date)
    model_DQN.save(current_date)

    with open(f'C:/Users/CGZ/Desktop/result/{current_date}.txt', 'w', encoding='utf-8') as file:
        for row in pairs:
            # 将每个张量转换为字符串，使用空格分隔
            # line = " ".join([str(t.item()) for t in row])  # 使用 item() 获取张量值
            line = " ".join([str(t.item()) if isinstance(t, torch.Tensor) else str(t) for t in row])
            file.write(line + "\n")  # 添加换行符
        file.write(f"{run_time}\n")

    # 绘制甘特图
    print(optical_env.reward_batch)
    draw_gantt(optical_env, current_date)

    return copy.deepcopy(optical_env.reward_batch)


def main(param_file: str):
    # 加载参数文件
    try:
        parameters = load_parameters(param_file)
    except FileNotFoundError:
        logging.error(f"Parameter file {param_file} not found.")
        return

    device = torch.device('cpu')
    logging.info(f"Using device {device}")  # 根据使用设备类型选择 GPU 或 CPU
    # Configure PyTorch's default device
    torch.set_default_tensor_type('torch.FloatTensor')

    # 提取环境、模型、训练和测试参数
    env_parameters = parameters["env_parameters"]
    model_parameters = parameters["model_parameters"]
    train_parameters = parameters["train_parameters"]
    DQN_parameters = parameters["DQN_parameters"]
    test_parameters = parameters["test_parameters"]

    batch_size = test_parameters["num_sample"] if test_parameters["sample"] else 1
    env_parameters["batch_size"] = batch_size
    # 根据模型参数中的机器和操作输出大小，计算演员网络输入的维度和评论家网络输入的维度
    model_parameters["actor_in_dim"] = model_parameters["out_size_ma"] * 2 + model_parameters["out_size_ope"] * 2
    model_parameters["critic_in_dim"] = model_parameters["out_size_ma"] + model_parameters["out_size_ope"]

    instance_path = "./data/{0}".format(test_parameters["problem_instance"])

    # 分配设备参数信息
    env_parameters["device"] = device
    model_parameters["device"] = device

    # 加载实例数据并配置强化学习环境
    with open(instance_path) as file_object:
        line = file_object.readlines()
        num_machines, num_operations, num_relations, num_workers = nums_detec(line)

    env_parameters["num_opes"] = num_operations
    env_parameters["num_relas"] = num_relations
    env_parameters["num_mas"] = num_machines
    env_parameters["num_wos"] = num_workers

    DQN_parameters["num_mas"] = num_machines

    # 初始化模型和环境
    model = PPO_model.PPO(model_parameters, train_parameters)
    model_DQN = DQN.DQN(model_parameters, DQN_parameters)

    # 加载训练好的策略
    trained_policy = test_parameters['trained_policy']
    if trained_policy.endswith('.pt'):
        policy = torch.load(trained_policy, map_location='cpu')
        print('\nloading checkpoint:', trained_policy)
        model.policy.load_state_dict(policy)
        model.policy_old.load_state_dict(policy)

    # DQN_policy = test_parameters['DQN_policy']
    # if DQN_policy.endswith('.pt'):
    #     print('\nloading checkpoint:', DQN_policy)
    #     model_DQN.load(DQN_policy)

    # 采样或者是贪婪, 每个环境包含一个实例的多个副本
    if test_parameters["sample"]:
        env = gym.make('fajsp-v0', case=[instance_path] * test_parameters["num_sample"], env_paras=env_parameters,
                       data_source='file')
    else:
        # 贪婪, 每个环境包含一个事例
        env = gym.make('fajsp-v0', case=[instance_path], env_paras=env_parameters, data_source='file')
    reward = schedule(env, model, model_DQN, PPO_model.Memory(), flag_sample=test_parameters["sample"], flag_train=test_parameters["train"])
    print(f"Instance: {instance_path}, Reward: {reward}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run FAJSP_DRL")
    parser.add_argument(
        "config_file",
        metavar='-f',
        type=str,
        nargs="?",
        default=PARAM_FILE,
        help="path to config JSON",
    )

    args = parser.parse_args()  # 解析命令行参数
    main(param_file=args.config_file)
