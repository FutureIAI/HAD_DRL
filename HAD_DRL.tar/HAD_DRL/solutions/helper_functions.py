import os
import tomli  # 用于解析 TOML 格式的配置文件

import pandas as pd

from scheduling_environment.jobShop import JobShop
from data_parsers import parser_fajsp, parser_fjsp


def load_parameters(config_toml):
    """从 TOML 文件中加载参数"""
    with open(config_toml, "rb") as f:
        config_params = tomli.load(f)
    return config_params


def load_job_shop_env(problem_instance: str, from_absolute_path=False) -> JobShop:
    """用于加载作业车间调度问题的环境"""
    jobShopEnv = JobShop()
    # 根据 problem_instance 参数中指定的问题实例类型，使用不同的解析器对 jobShopEnv 进行解析和设置
    if '/fjsp/' in problem_instance:
        jobShopEnv = parser_fjsp.parse(jobShopEnv, problem_instance, from_absolute_path)
    elif '/fajsp/' in problem_instance:
        jobShopEnv = parser_fajsp.parse(jobShopEnv, problem_instance, from_absolute_path)
    else:
        raise NotImplementedError(
            f"""Problem instance {
            problem_instance
            } not implemented"""
        )
    jobShopEnv._name = problem_instance  # 将 jobShopEnv 的名称设置为 problem_instance

    return jobShopEnv


def create_stats_list(population, gen):
    """创建统计信息列表"""
    stats_list = []
    for ind in population:
        tmp_dict = {}
        tmp_dict.update(
            {
                "Generation": gen,  # 表示当前代数
                "obj1": ind.fitness.values[0]  # 个体 ind 的适应度值的第一个元素
            })
        if hasattr(ind, "objectives"):  # 如果个体 ind 具有属性 "objectives"
            tmp_dict.update(
                {
                    "obj1": ind.objectives[0],  # 个体 ind 的目标函数值的第一个元素
                }
            )
        tmp_dict = {**tmp_dict}  # 扩展为一个新的字典
        stats_list.append(tmp_dict)
    return stats_list


def record_stats(gen, population, logbook, stats, verbose, df_list, logging):
    """记录统计信息"""
    stats_list = create_stats_list(population, gen)
    df_list.append(pd.DataFrame(stats_list))  # 将统计信息的列表转化为 pandas.DataFrame，添加到给定的 df_list 列表中
    record = stats.compile(population) if stats is not None else {}
    logbook.record(gen=gen, **record)  # 计算并记录当前种群的统计信息到 logbook 中
    if verbose:
        logging.info(logbook.stream)


def update_operations_available_for_scheduling(env):
    """更新可调度的操作列表"""
    scheduled_operations = set(env.scheduled_operations)  # 已经安排调度的操作合集
    precedence_relations = env.precedence_relations_operations  # 操作之间的先后顺序
    operations_available = [  # 筛选出可调度的操作
        operation
        for operation in env.operations
        if operation not in scheduled_operations and all(
            prec_operation in scheduled_operations
            for prec_operation in precedence_relations[operation.operation_id]
        )  # 操作不在可调度合集中，所有前置操作均在 scheduled_operations 集合中
    ]
    env.set_operations_available_for_scheduling(operations_available)


def dict_to_excel(dictionary, folder, filename):
    """将字典保存到 Excel 文件中"""

    # 检查目标文件夹是否存在, if not, create it
    if not os.path.exists(folder):
        os.makedirs(folder)

    # 检查目标文件是否存在, if so, give a warning
    full_path = os.path.join(folder, filename)  # 将目标文件夹和文件名合并为完整路径
    if os.path.exists(full_path):
        print(f"Warning: {full_path} already exists. Overwriting file.")

    # 将字典转换为 DataFrame
    df = pd.DataFrame([dictionary])

    # 将 DataFrame 保存到 Excel 文件中
    df.to_excel(full_path, index=False, engine='openpyxl')
