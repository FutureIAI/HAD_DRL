import torch


def Features(self, n, ope, mas, last_time, start_time, time_ope):
    # 每个机器的利用率
    ma_uti = torch.zeros(size=(self.num_mas,))
    for ma in range(self.num_mas):
        ma_uti[ma] = self.feat_mas_batch[:, 2, ma]
    # 机器平均利用率
    ma_ave_uti = torch.mean(ma_uti)
    # 机器平均利用率标准差
    ma_ave_uti_a = torch.std(ma_uti)
    # 完成的ope数
    count_nonzero = torch.count_nonzero(self.feat_opes_batch[:, 0, :])
    # 作业完成率
    job_ave = torch.sum(self.mask_job_finish_batch) / self.num_jobs
    # 加工能耗
    TE_pro = self.proc_times_batch[:, ope, mas] * self.ma_power[:, mas, 1]
    # 空载能耗
    if start_time > last_time:
        TE_idl = (start_time - last_time) * self.ma_power[:, mas, 0]
    else:
        TE_idl = 0
    TE_ij = TE_pro + TE_idl
    self.reward_batch[:, n, 2] = TE_ij
    temp = []
    for machine in range(self.num_mas):
        if ~(self.mask_ma_procing_batch[:, machine]) & (time_ope[:, :, machine] != 0):
            idle = (start_time - self.machines_batch[self.batch_idxes, machine, 1]) * self.ma_power[:, machine, 0]
            operate = time_ope[:, :, machine] * self.ma_power[:, machine, 1]
            temp.append(idle + operate)
    if len(temp) != 0:
        TE_min = min(temp) if min(temp) < TE_ij else TE_ij
        TE_max = max(temp) if max(temp) > TE_ij else TE_ij
        TE_mid = (TE_max + TE_min) / 2 if TE_max != TE_min else (TE_max + TE_min + 1) / 2
        EI = abs((TE_mid - TE_ij) / (TE_mid - TE_min))
    else:
        EI = 1
        TE_mid = TE_ij + 1
    return ma_ave_uti, ma_ave_uti_a, job_ave, TE_ij, EI, TE_mid


def cos(num):
    # 计算归一化的比例因子
    if num[0] > 0 and num[1] > 0:
        a = num[0]
        b = num[1]
    elif num[0] < 0 and num[1] < 0:
        min_z = max(abs(num[0]), abs(num[1]))
        offset = min_z + 1
        a = num[0] + offset
        b = num[1] + offset
    else:
        offset = abs(num[0]) + 1 if num[0] < 0 else abs(num[1]) + 1
        a = num[0] + offset
        b = num[1] + offset
    a_normalized = a / torch.sqrt(b ** 2 - a ** 2)
    b_normalized = b / torch.sqrt(b ** 2 - a ** 2)
    return a_normalized, b_normalized

def Immediate_reward(self, n, ma_ave_uti, ma_ave_uti_a, EI_t1, TE_ij, TE_mid, makespan, times, proc_times, mean_proc_time, weight):
    reward_Eco = 0
    reward_En = 0
    if self.feature[:, 0] == 0:
        reward_Eco += 0
    else:
        if self.feature[:, 0] < ma_ave_uti:  # 利用率增大表示优化
            reward_Eco += 1
        elif self.feature[:, 0] > ma_ave_uti:
            reward_Eco += -5
        else:
            reward_Eco += 0

        if self.feature[:, 1] > ma_ave_uti_a:
            reward_Eco += 1
        elif self.feature[:, 1] < ma_ave_uti_a:
            reward_Eco += -1
        else:
            reward_Eco += 0

    if makespan < times:
        reward_Eco += -20
    elif makespan > times:  # n-1步比n步大，表示优化
        reward_Eco += 5
    else:
        if proc_times <= mean_proc_time:
            reward_Eco += 5
        else:
            reward_Eco += -20


    if n == 1:
        reward_En += 0
    else:
        if self.feature[:, 3] > EI_t1:  # n-1步比n步大，表示优化
            reward_En += 5
        elif self.feature[:, 3] < EI_t1:
            reward_En -= 20
        else:
            reward_En += 0

        if TE_mid >= TE_ij:
            reward_En += 2
        else:
            reward_En -= 2
    # a, b = cos(weight)
    print(reward_Eco, reward_En)
    reward = weight[0] * reward_Eco + weight[1] * reward_En
    return reward


def Cumulative_reward(weight, tardiness, energy_t, tardiness_t1, energy_t1):
    if tardiness == 0:
        reward_Eco = 0
    elif tardiness_t1 < tardiness:
        reward_Eco = 10
    elif tardiness_t1 > tardiness:
        reward_Eco = -50
    else:
        reward_Eco = -50
    # 能耗奖励
    if energy_t == 0:
        reward_En = 0
    elif energy_t1 < energy_t:
        reward_En = 10
    elif energy_t1 > energy_t:
        reward_En = -50
    else:
        reward_En = -50
    # reward = 100 * (0.5 * reward_Eco + 0.5 * reward_En)
    reward = weight[0] * reward_Eco + weight[1] * reward_En
    return reward
