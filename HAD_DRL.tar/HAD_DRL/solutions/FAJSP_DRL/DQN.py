import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import torch
import copy
from solutions.FAJSP_DRL.replay_buffer import *
from solutions.FAJSP_DRL.network import DuelingNet, Net, CNN_FNN
from solutions.FAJSP_DRL.reward import Immediate_reward
from solutions.FAJSP_DRL.hgnn import GATedge, MLPsim


class MLPs(nn.Module):
    """
    MLPs in operation node embedding 用于操作节点嵌入
    """

    def __init__(self, W_sizes_ope, hidden_size_ope, out_size_ope, num_head, dropout):
        """
        用于设置模型的参数和构建模型的层结构
        The multi-head and dropout mechanisms 没有实际运用到最后实验中.
        :param W_sizes_ope: 一个包含各类型输入向量维度的列表，包括 [机器, 操作（前驱），操作（后继），操作（自身）]
        :param hidden_size_ope: 隐藏层的维度
        :param out_size_ope: 操作节点嵌入的维度
        :param num_head: 多头注意力机制的头数量
        :param dropout: Dropout 层的丢弃率
        """
        super(MLPs, self).__init__()
        self.in_sizes_ope = W_sizes_ope
        self.hidden_size_ope = hidden_size_ope
        self.out_size_ope = out_size_ope
        self.num_head = num_head
        self.dropout = dropout
        self.gnn_layers = nn.ModuleList()  # 存储 MLPsim 对象的模型列表

        # A total of five MLPs and MLP_0 (self.project) aggregates information from other MLPs
        for i in range(len(self.in_sizes_ope)):  # 创建了五个 MLPsim 对象，将其添加到 gnn_layers 模块列表中（ 4？
            self.gnn_layers.append(MLPsim(self.in_sizes_ope[i], self.out_size_ope, self.hidden_size_ope, self.num_head,
                                          self.dropout, self.dropout))
        self.project = nn.Sequential(
            nn.ELU(),
            nn.Linear(self.out_size_ope * len(self.in_sizes_ope), self.hidden_size_ope),
            nn.ELU(),
            nn.Linear(self.hidden_size_ope, self.hidden_size_ope),
            nn.ELU(),
            nn.Linear(self.hidden_size_ope, self.out_size_ope),
        )

    def forward(self, ope_ma_adj_batch, ope_pre_adj_batch, ope_sub_adj_batch, batch_idxes, feats):
        """
        :param ope_ma_adj_batch: Adjacency matrix of 操作和机器节点
        :param ope_pre_adj_batch: Adjacency matrix of 操作和前驱操作节点
        :param ope_sub_adj_batch: Adjacency matrix of 操作和后驱操作节点
        :param batch_idxes: Uncompleted instances 批处理索引
        :param feats: 包括操作、机器和边特征
        """
        h = (feats[1], feats[0], feats[0], feats[0])
        # Identity matrix for self-loop of nodes 用于表示节点的自环
        self_adj = torch.eye(feats[0].size(-2), dtype=torch.int64).unsqueeze(0).expand_as(ope_pre_adj_batch[batch_idxes])

        # 计算一个操作嵌入返回值    将输入的邻接矩阵数据与self_adj组合成一个元组adj
        adj = (ope_ma_adj_batch[batch_idxes], ope_pre_adj_batch[batch_idxes],
               ope_sub_adj_batch[batch_idxes], self_adj)
        MLP_embeddings = []
        for i in range(len(adj)):
            MLP_embeddings.append(self.gnn_layers[i](h[i], adj[i]))  # 特征向量h[i]和邻接矩阵adj[i]
        MLP_embedding_in = torch.cat(MLP_embeddings, dim=-1)  # 按最后一个维度进行拼接
        mu_ij_prime = self.project(MLP_embedding_in)
        return mu_ij_prime


class DQN(object):
    def __init__(self, model_paras, args):
        self.action_dim = args["action_dim"]  # 动作集维度
        self.state_dim = args["state_dim"]
        self.batch_size = args["batch_size"]  # 批处理大小
        self.max_train_steps = args["max_train_steps"]
        self.lr = args["lr"]  # 学习率
        self.gamma = args["gamma"]  # 折扣因子
        self.tau = args["tau"]  # T
        self.use_soft_update = args["use_soft_update"]  # 软更新
        self.target_update_freq = args["target_update_freq"]  # 硬更新
        self.update_count = 0
        self.device = model_paras["device"]
        self.num_heads = model_paras["num_heads"]
        self.dropout = model_paras["dropout"]
        self.in_size_ma = model_paras["in_size_ma"]  # 机器节点'原始特征'向量的维度
        self.out_size_ma = model_paras["out_size_ma"]  # 机器节点'嵌入'向量的维度
        self.in_size_ope = model_paras["in_size_ope"]  # 操作节点‘原始特征‘向量的维度
        self.out_size_ope = model_paras["out_size_ope"]  # 操作节点‘嵌入’向量的维度
        self.hidden_size_ope = model_paras["hidden_size_ope"]  # MLP隐藏层的维度

        self.ope_max = torch.tensor(args["ope_max"])

        self.replay_buffer = ReplayBuffer(args)
        self.grad_clip = args["grad_clip"]
        self.use_lr_decay = args["use_lr_decay"]  # 学习率衰减

        self.get_machines = nn.ModuleList()  # 专门用于保存和管理多个子模块
        self.get_machines.append(GATedge((self.in_size_ope, self.in_size_ma), self.out_size_ma, self.num_heads[0],
                                         self.dropout, self.dropout, activation=F.elu))
        for i in range(1, len(self.num_heads)):  # 将 GATedge 模型添加到 get_machines 列表中
            self.get_machines.append(GATedge((self.out_size_ope, self.out_size_ma), self.out_size_ma, self.num_heads[i],
                                             self.dropout, self.dropout, activation=F.elu))

        # 操作节点嵌入
        self.get_operations = nn.ModuleList()
        self.get_operations.append(MLPs([self.out_size_ma, self.in_size_ope, self.in_size_ope, self.in_size_ope],
                                        self.hidden_size_ope, self.out_size_ope, self.num_heads[0], self.dropout))
        for i in range(len(self.num_heads) - 1):  # 将MLPs模型添加到get_operations列表中
            self.get_operations.append(MLPs([self.out_size_ma, self.out_size_ope, self.out_size_ope, self.out_size_ope],
                                            self.hidden_size_ope, self.out_size_ope, self.num_heads[i], self.dropout))

        self.loss_func = nn.L1Loss()

        self.model = CNN_FNN(args)
        self.target_model = copy.deepcopy(self.model)
        self.target_model.load_state_dict(self.model.state_dict())

        # self.use_double = args.use_double  # double DQN
        # self.use_dueling = args.use_dueling  # dueling DQN
        # self.use_per = args.use_per  # 优先经验回放
        # self.use_n_steps = args.use_n_steps  # Multi-Step Learning
        # if self.use_n_steps:  # 是否使用 'Multi-Step Learning'
        #     self.gamma = self.gamma ** args.n_steps
        #
        # if self.use_dueling:  # 是否使用 'dueling network'
        #     self.net = DuelingNet(args)
        # else:
        #     self.net = Net(args)


        self.net = CNN_FNN(args)
        self.net = Net(args)

        # self.target_net = copy.deepcopy(self.net)  # 复制 online_net 到 target_net20
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)  # 优化器

    def load(self, model_path):
        checkpoint = torch.load(model_path)
        # 恢复模型参数
        self.model.load_state_dict(checkpoint['model_state_dict'])
        # 恢复优化器状态
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

    def save(self, current_date):
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, f'D:/PyCharm Community Edition 2022.3/PythonProject/Job_Shop_Scheduling-2/solutions/FAJSP_DRL/models/DQN{current_date}.pt')

    def net_weight(self, state, a):
        with torch.no_grad():
            batch_idxes = state.batch_idxes
            raw_opes = state.feat_opes_batch.transpose(1, 2)[batch_idxes]
            raw_mas = state.feat_mas_batch.transpose(1, 2)[batch_idxes]
            proc_time = state.proc_times_batch[batch_idxes]
            proc_power = state.proc_power_batch[batch_idxes]
            nums_opes = state.nums_opes_batch[batch_idxes]
            num_mas = state.mask_ma_procing_batch.size(1)
            num_job = state.mask_job_finish_batch.size(1)
            num_ope = proc_time.size(1)
            ma_eligible = ~state.mask_ma_procing_batch[batch_idxes]
            job_eligible = ~(state.mask_job_procing_batch[batch_idxes] + state.mask_job_finish_batch[batch_idxes]) & (state.schedule_job[batch_idxes])
            for ba in range(self.batch_size):
                for job_idxes in range(num_job):  # 不能调度的作业（正在调度、完成调度、前驱调度）
                    if ~job_eligible[ba, job_idxes]:
                        start_ope = state.num_ope_biases_batch[ba, job_idxes]
                        end_ope = state.end_ope_biases_batch[ba, job_idxes]
                        proc_time[ba, start_ope.item():end_ope.item() + 1, :] = 0
                        proc_power[ba, start_ope.item():end_ope.item() + 1, :] = 0
                for ma_idxes in range(num_mas):  # 不能调度的机器
                    if ~ma_eligible[ba, ma_idxes]:
                        proc_time[ba, :, ma_idxes] = 0
                        proc_power[ba, :, ma_idxes] = 0
            if torch.count_nonzero(proc_time) == 1:
                return (torch.tensor(0.5), torch.tensor(0.5))
            feature = self.normalized(raw_opes, raw_mas, proc_time, proc_power, batch_idxes, nums_opes)
            norm_proc_time = copy.deepcopy(feature[0])
            norm_proc_power = copy.deepcopy(feature[1])

            # for i in range(len(self.num_heads)):
            #     # First 机器节点嵌入
            #     # shape: [len(batch_idxes), num_mas, out_size_ma]
            #     h_mas = self.get_machines[i](state.ope_ma_adj_batch, state.batch_idxes, feature)
            #     feature = (feature[0], h_mas, feature[2], feature[3])  # （features[1]）替换为第一阶段的嵌入结果h_mas
            #     # Second 操作节点嵌入
            #     # shape: [len(batch_idxes), max(num_opes), out_size_ope]
            #     h_opes = self.get_operations[i](state.ope_ma_adj_batch, state.ope_pre_adj_batch,
            #                                     state.ope_sub_adj_batch,
            #                                     state.batch_idxes, feature)
            #     feature = (h_opes, feature[1], feature[2], feature[3])
            #
            # h_mas_pooled = h_mas.mean(dim=-2)  # shape: [len(batch_idxes), out_size_ma]
            # # 每个作业可能会有不同操作, which cannot be 池化 directly by the matrix
            # h_opes_pooled = h_opes.mean(dim=-2)  # shape: [len(batch_idxes), out_size_ope]
            #
            # # 筛选满足条件的操作节点-机器节点对，并生成计算所需的张量
            # # 将操作节点步数张量结束偏置张量进行比较，选取两者中较小的值作为操作节点步数（因为如果操作节点步数超过了结束偏置，那么该操作节点就已经完成）
            # ope_step_batch = torch.where(state.ope_step_batch > state.end_ope_biases_batch, state.end_ope_biases_batch,
            #                              state.ope_step_batch)
            # jobs_gather = ope_step_batch[..., :, None].expand(-1, -1, h_opes.size(-1))[batch_idxes]
            # # 使用gather函数将最新的操作节点嵌入结果h_opes与操作节点步数张量进行匹配，得到与每个操作节点相对应的机器节点
            # h_jobs = h_opes.gather(1, jobs_gather)  # shape[len(batch_idxes), num_jobs, out_size_ope]
            # # 将操作-机器邻接矩阵与操作节点步数（已筛选掉已完成的操作节点）进行匹配，得到每个操作-机器节点对是否可行的结果 eligible_proc
            # # shape[len(batch_idxes), num_jobs, num_mas]
            # eligible_proc = state.ope_ma_adj_batch[batch_idxes].gather(1, ope_step_batch[..., :, None].expand(-1, -1,
            #                                                                                                   state.ope_ma_adj_batch.size(
            #                                                                                                       -1))[
            #     batch_idxes])
            # # 在 h_jobs 倒数第二维上扩展维度 shape[len(batch_idxes), num_jobs, num_mas, out_size_ope]
            # h_jobs_padding = h_jobs.unsqueeze(-2).expand(-1, -1, state.proc_times_batch.size(-1), -1)
            # h_mas_padding = h_mas.unsqueeze(-3).expand_as(h_jobs_padding)  # 在倒数第三维上扩展
            # h_mas_pooled_padding = h_mas_pooled[:, None, None, :].expand_as(h_jobs_padding)
            # h_opes_pooled_padding = h_opes_pooled[:, None, None, :].expand_as(h_jobs_padding)
            # # 矩阵指示机器是否可用  shape: [len(batch_idxes), num_jobs, num_mas]
            # # 若某个机器节点处于处理中状态，则设置为 false
            # ma_eligible = ~state.mask_ma_procing_batch[batch_idxes].unsqueeze(1).expand_as(h_jobs_padding[..., 0])
            # # 矩阵指示操作是否可用  shape: [len(batch_idxes), num_jobs, num_mas]
            # # 若某个操作节点处于处理中或已完成状态，则对应的位置为 false
            # job_eligible = ~(state.mask_job_procing_batch[batch_idxes] + state.mask_job_finish_batch[batch_idxes])[:, :,
            #                 None].expand_as(h_jobs_padding[..., 0])
            # # 作业与作业之前的约束关系
            # ope_eligible = (state.schedule_job[batch_idxes])[:, :, None].expand_as(h_jobs_padding[..., 0])
            # # shape: [len(batch_idxes), num_jobs, num_mas]
            # eligible = job_eligible & ma_eligible & (eligible_proc == 1) & ope_eligible
            # if (~(eligible)).all():  # 所有操作-机器节点对均不行
            #     print("No eligible O-M pair!")
            #     return
            #
            # # actor网络的输入张量 shape: [len(batch_idxes), num_mas, num_jobs, out_size_ma*2 + out_size_ope*2]
            # h_actions = torch.cat((h_jobs_padding, h_mas_padding, h_opes_pooled_padding, h_mas_pooled_padding),
            #                       dim=-1).transpose(1, 2)
            # h_pooled = torch.cat((h_opes_pooled, h_mas_pooled), dim=-1)  # deprecated
            # mask = eligible.transpose(1, 2).flatten(1)  # 进行转置和扁平化处理，将不可行的操作-机器节点对所对应的值屏蔽掉

            if num_ope < int(self.ope_max):  # 扩充为（1，1，30，5）
                r = int(self.ope_max) - num_ope
                expand = torch.zeros(size=(batch_idxes.size(0), r, 5))
                net_proc_time = torch.cat((norm_proc_time, expand), dim=1).unsqueeze(0)
                net_proc_power = torch.cat((norm_proc_power, expand), dim=1).unsqueeze(0)
            else:
                net_proc_time = norm_proc_time.unsqueeze(0)
                net_proc_power = norm_proc_power.unsqueeze(0)
            net_proc_ = torch.cat((net_proc_time, net_proc_power), dim=1)
            if a == 0:  # 区分 net或 target_net
                probability = self.model(net_proc_)
            else:
                probability = self.target_model(net_proc_)
            pro_time, pro_power = self.cos(probability)
            # return (pro_time, pro_power)
            # return (pro_time, pro_power)
            return (probability[0, 0], probability[0, 1]), (pro_time, pro_power)

    def feature_normalize(self, data):  # 特征标准化处理：  输入数据减去平均值，并除以标准差（加上一个小的常数以免除以零）
        return (data - torch.mean(data)) / ((data.std() + 1e-5))

    def normalized(self, raw_opes, raw_mas, proc_time, proc_power, batch_idxes, nums_opes):
        batch_size = batch_idxes.size(0)
        for i in range(batch_size):
            proc_idxes = torch.nonzero(proc_time[i])  # 非零元素的索引proc_idxes
            time_values = proc_time[i, proc_idxes[:, 0], proc_idxes[:, 1]]  # 根据索引从proc_time中取出对应的值
            power_values = proc_power[i, proc_idxes[:, 0], proc_idxes[:, 1]]
            time_norm = self.feature_normalize(time_values)
            power_norm = self.feature_normalize(power_values)
            proc_time[i, proc_idxes[:, 0], proc_idxes[:, 1]] = time_norm
            proc_power[i, proc_idxes[:, 0], proc_idxes[:, 1]] = power_norm
        proc_time_norm = proc_time
        proc_power_norm = proc_power
        return (proc_time_norm, proc_power_norm)

    def cos(self, num):
        # 计算归一化的比例因子
        if num[0, 0] > 0 and num[0, 1] > 0:
            a = num[0, 0]
            b = num[0, 1]
        elif num[0, 0] < 0 and num[0, 1] < 0:
            min_z = max(abs(num[0, 0]), abs(num[0, 1]))
            offset = min_z + 1
            a = num[0, 0] + offset
            b = num[0, 1] + offset
        else:
            offset = abs(num[0, 0]) + 1 if num[0, 0] < 0 else abs(num[0, 1]) + 1
            a = num[0, 0] + offset
            b = num[0, 1] + offset
        a_normalized = a / torch.sqrt(b ** 2 + a ** 2)
        b_normalized = b / torch.sqrt(b ** 2 + a ** 2)
        return a_normalized, b_normalized

    def reward_batch(self, state, action, next_state, N):
        self.replay_buffer.store_transition(state, action, state.reward, next_state)  # 存储转换

        # if self.replay_buffer.current_size >= self.batch_size:
        #     self.learn(self.replay_buffer, count_nonzero)
        self.learn(self.replay_buffer, N)

    def learn(self, replay_buffer, total_steps):  # 更新网络参数
        batch = replay_buffer.sample(total_steps)  # 采样一个批次的数据

        # sample batch from memory 采样
        loss = []
        for i in range(len(batch)):
            batch_state = batch[i][0]
            batch_next_state = batch[i][3]
            batch_action = batch[i][1]
            batch_reward = batch[i][2]

            with torch.no_grad():  # q_target has no gradient
                q_next = torch.tensor(self.net_weight(batch_next_state, 1))
                q_target = (batch_reward + self.gamma * q_next).unsqueeze(1)

            q_current = torch.tensor(self.net_weight(batch_state, 0)).unsqueeze(1)
            loss.append((q_target - q_current).pow(2).mean())

        loss = torch.tensor(loss)
        loss_a = loss.mean()
        self.optimizer.zero_grad()
        loss_a.requires_grad_(True)
        loss_a.backward()

        if self.grad_clip:  # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
        self.optimizer.step()

        if self.use_soft_update:  # soft update
            for param, target_param in zip(self.model.parameters(), self.target_model.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        else:  # hard update
            self.update_count += 1
            if self.update_count % self.target_update_freq == 0:
                self.target_model.load_state_dict(self.model.state_dict())

        if self.use_lr_decay:  # learning rate Decay
            self.lr_decay(total_steps)

    def lr_decay(self, total_steps):
        lr_now = 0.9 * self.lr * (1 - total_steps / self.max_train_steps) + 0.1 * self.lr
        for p in self.optimizer.param_groups:
            p['lr'] = lr_now
