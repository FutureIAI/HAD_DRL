

import copy
import math
import random

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
from torch.nn.utils import clip_grad_norm_

from solutions.FAJSP_DRL.hgnn import GATedge, MLPsim
from solutions.FAJSP_DRL.mlp import MLPCritic, MLPActor


class Memory:
    def __init__(self):
        self.states = []
        self.logprobs = []  # 存储动作选择的对数概率
        self.rewards = []
        self.is_terminals = []  # 标识当前状态是否为终止状态
        self.action_indexes = []  # 存储执行的动作索引

        self.ope_ma_adj = []  # 存储操作的移动平均邻接矩阵
        self.ope_pre_adj = []  # 存储操作的前驱邻接矩阵
        self.ope_sub_adj = []  # 存储操作的后驱邻接矩阵
        self.batch_idxes = []  # 存储批处理的索引
        self.raw_opes = []  # 存储原始操作数据
        self.raw_mas = []  # 存储原始移动平均数据
        self.proc_time = []
        self.proc_power = []
        self.jobs_gather = []  # 存储聚合的任务信息
        self.eligible = []  # 标识操作是否可行
        self.nums_opes = []

    def clear_memory(self):  # 用于清空所有存储的数据
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]
        del self.action_indexes[:]

        del self.ope_ma_adj[:]
        del self.ope_pre_adj[:]
        del self.ope_sub_adj[:]
        del self.batch_idxes[:]
        del self.raw_opes[:]
        del self.raw_mas[:]
        del self.proc_time[:]
        del self.proc_power[:]
        del self.jobs_gather[:]
        del self.eligible[:]
        del self.nums_opes[:]


class MLPs(nn.Module):
    """
    MLPs in operation node embedding 用于操作节点嵌入
    """

    def __init__(self, W_sizes_ope, hidden_size_ope, out_size_ope, num_head, dropout):
        """
        用于设置模型的参数和构建模型的层结构
        The multi-head and dropout mechanisms 没有实际运用到最后实验中.
        :param W_sizes_ope: 一个包含各类型输入向量维度的列表，包括 [机器, 操作（前驱），操作（后继），操作（自身）]
        :param hidden_size_ope: 隐藏层的维度
        :param out_size_ope: 操作节点嵌入的维度
        :param num_head: 多头注意力机制的头数量
        :param dropout: Dropout 层的丢弃率
        """
        super(MLPs, self).__init__()
        self.in_sizes_ope = W_sizes_ope
        self.hidden_size_ope = hidden_size_ope
        self.out_size_ope = out_size_ope
        self.num_head = num_head
        self.dropout = dropout
        self.gnn_layers = nn.ModuleList()  # 存储 MLPsim 对象的模型列表

        # A total of five MLPs and MLP_0 (self.project) aggregates information from other MLPs
        for i in range(len(self.in_sizes_ope)):  # 创建了五个 MLPsim 对象，将其添加到 gnn_layers 模块列表中（ 4？
            self.gnn_layers.append(MLPsim(self.in_sizes_ope[i], self.out_size_ope, self.hidden_size_ope, self.num_head,
                                          self.dropout, self.dropout))
        self.project = nn.Sequential(
            nn.ELU(),
            nn.Linear(self.out_size_ope * len(self.in_sizes_ope), self.hidden_size_ope),
            nn.ELU(),
            nn.Linear(self.hidden_size_ope, self.hidden_size_ope),
            nn.ELU(),
            nn.Linear(self.hidden_size_ope, self.out_size_ope),
        )

    def forward(self, ope_ma_adj_batch, ope_pre_adj_batch, ope_sub_adj_batch, batch_idxes, feats):
        """
        :param ope_ma_adj_batch: Adjacency matrix of 操作和机器节点
        :param ope_pre_adj_batch: Adjacency matrix of 操作和前驱操作节点
        :param ope_sub_adj_batch: Adjacency matrix of 操作和后驱操作节点
        :param batch_idxes: Uncompleted instances 批处理索引
        :param feats: 包括操作、机器和边特征
        """
        h = (feats[1], feats[0], feats[0], feats[0])
        # Identity matrix for self-loop of nodes 用于表示节点的自环
        self_adj = torch.eye(feats[0].size(-2), dtype=torch.int64).unsqueeze(0).expand_as(ope_pre_adj_batch[batch_idxes])

        # 计算一个操作嵌入返回值    将输入的邻接矩阵数据与self_adj组合成一个元组adj
        adj = (ope_ma_adj_batch[batch_idxes], ope_pre_adj_batch[batch_idxes],
               ope_sub_adj_batch[batch_idxes], self_adj)
        MLP_embeddings = []
        for i in range(len(adj)):
            MLP_embeddings.append(self.gnn_layers[i](h[i], adj[i]))  # 特征向量h[i]和邻接矩阵adj[i]
        MLP_embedding_in = torch.cat(MLP_embeddings, dim=-1)  # 按最后一个维度进行拼接
        mu_ij_prime = self.project(MLP_embedding_in)
        return mu_ij_prime


class HGNNScheduler(nn.Module):  # 异质图神经网络
    def __init__(self, model_paras):  # 通过 model_paras 获取参数
        super(HGNNScheduler, self).__init__()
        self.device = model_paras["device"]
        self.in_size_ma = model_paras["in_size_ma"]  # 机器节点'原始特征'向量的维度
        self.out_size_ma = model_paras["out_size_ma"]  # 机器节点'嵌入'向量的维度
        self.in_size_ope = model_paras["in_size_ope"]  # 操作节点‘原始特征‘向量的维度
        self.out_size_ope = model_paras["out_size_ope"]  # 操作节点‘嵌入’向量的维度
        self.hidden_size_ope = model_paras["hidden_size_ope"]  # MLP隐藏层的维度
        self.actor_dim = model_paras["actor_in_dim"]  # Actor输入维度
        self.critic_dim = model_paras["critic_in_dim"]  # Critic输入维度
        self.n_latent_actor = model_paras["n_latent_actor"]  # Actor隐层的维度
        self.n_latent_critic = model_paras["n_latent_critic"]  # Critic隐层的维度
        self.n_hidden_actor = model_paras["n_hidden_actor"]  # Actor层数
        self.n_hidden_critic = model_paras["n_hidden_critic"]  # Critic层数
        self.action_dim = model_paras["action_dim"]  # Actor输出维度
        self.epsilon = model_paras["epsilon_start"]
        self.t = 0

        # len() 表示HGNN（Hierarchical Graph Neural Network）迭代的次数
        # 参数表示迭代的次数和每个HGNN头部的数量 (=1 in final experiment)
        self.num_heads = model_paras["num_heads"]
        self.dropout = model_paras["dropout"]

        # 机器节点嵌入
        self.get_machines = nn.ModuleList()  # 专门用于保存和管理多个子模块
        self.get_machines.append(GATedge((self.in_size_ope, self.in_size_ma), self.out_size_ma, self.num_heads[0],
                                         self.dropout, self.dropout, activation=F.elu))
        for i in range(1, len(self.num_heads)):  # 将 GATedge 模型添加到 get_machines 列表中
            self.get_machines.append(GATedge((self.out_size_ope, self.out_size_ma), self.out_size_ma, self.num_heads[i],
                                             self.dropout, self.dropout, activation=F.elu))

        # 操作节点嵌入
        self.get_operations = nn.ModuleList()
        self.get_operations.append(MLPs([self.out_size_ma, self.in_size_ope, self.in_size_ope, self.in_size_ope],
                                        self.hidden_size_ope, self.out_size_ope, self.num_heads[0], self.dropout))
        for i in range(len(self.num_heads) - 1):  # 将MLPs模型添加到get_operations列表中
            self.get_operations.append(MLPs([self.out_size_ma, self.out_size_ope, self.out_size_ope, self.out_size_ope],
                                            self.hidden_size_ope, self.out_size_ope, self.num_heads[i], self.dropout))

        self.actor = MLPActor(self.n_hidden_actor, self.actor_dim, self.n_latent_actor, self.action_dim).to(self.device)
        self.critic = MLPCritic(self.n_hidden_critic, self.critic_dim, self.n_latent_critic, 1).to(self.device)

    def forward(self):
        """
        被独立的act和evaluate函数进行替代
        """
        raise NotImplementedError

    def feature_normalize(self, data, weight):  # 特征标准化处理：  输入数据减去平均值，并除以标准差（加上一个小的常数以免除以零）
        return (data - (torch.mean(data) - weight)) / ((data.std() + 1e-5))

    '''
        raw_opes: shape: [len(batch_idxes), max(num_opes), in_size_ope]  原始操作节点特征的张量
        raw_mas: shape: [len(batch_idxes), num_mas, in_size_ma]  原始机器节点特征的张量
        proc_time: shape: [len(batch_idxes), max(num_opes), num_mas]  运行时间特征的张量
    '''

    def get_normalized(self, raw_opes, raw_mas, proc_time, proc_power, batch_idxes, nums_opes, weight, flag_sample=False, flag_train=False):
        """
        对输入的原始特征进行标准化处理
        :param raw_opes: 原始操作节点特征的张量
        :param raw_mas: 原始机器节点特征的张量
        :param proc_time: 运行时间特征的张量
        :param batch_idxes: 未完成实例的索引
        :param nums_opes: 作业的操作数
        :param flag_sample: DRL-S的标志，用于指示是否进行采样
        :param flag_train: 训练标志，用于指示是否处于训练模式
        :return: Normalized feats, including operations, machines and edges
        """
        batch_size = batch_idxes.size(0)  # 未完成实例数

        # 每个作业的不同操作可能, which cannot be 标准化 directly by the matrix
        #
        mean_opes = []  # 操作节点特征的均值
        std_opes = []  # 标准差
        for i in range(batch_size):
            mean_opes.append(torch.mean(raw_opes[i, :nums_opes[i], :], dim=-2, keepdim=True))
            std_opes.append(torch.std(raw_opes[i, :nums_opes[i], :], dim=-2, keepdim=True))
            # 处理时间进行特征标准化处理
            proc_idxes = torch.nonzero(proc_time[i])  # 非零元素的索引proc_idxes
            proc_values1 = proc_time[i, proc_idxes[:, 0], proc_idxes[:, 1]]  # 根据索引从proc_time中取出对应的值
            proc_values2 = proc_power[i, proc_idxes[:, 0], proc_idxes[:, 1]]
            print(proc_values1)
            proc_norm_time = self.feature_normalize(proc_values1, weight[0])
            print(proc_norm_time)
            proc_norm_power = self.feature_normalize(proc_values2, weight[1])
            proc_time[i, proc_idxes[:, 0], proc_idxes[:, 1]] = proc_norm_time
            proc_power[i, proc_idxes[:, 0], proc_idxes[:, 1]] = proc_norm_power
        mean_opes = torch.stack(mean_opes, dim=0)
        std_opes = torch.stack(std_opes, dim=0)
        mean_mas = torch.mean(raw_mas, dim=-2, keepdim=True)  # 机器节点特征的均值
        std_mas = torch.std(raw_mas, dim=-2, keepdim=True)  # 标准差
        proc_time_norm = proc_time
        proc_power_norm = proc_power
        return ((raw_opes - mean_opes) / (std_opes + 1e-5), (raw_mas - mean_mas) / (std_mas + 1e-5),
                proc_time_norm, proc_power_norm)   # 用于将原始特征缩放到均值为0，方差为1的范围内

    def get_action_prob(self, state, memories, weight, flag_sample=False, flag_train=True):
        """
        得到在决策中选择每个动作的可能性
        """
        # 未完成作业索引
        batch_idxes = state.batch_idxes
        # Raw feats 原始数据
        raw_opes = state.feat_opes_batch.transpose(1, 2)[batch_idxes]  # 使用transpose(1, 2)将维度进行转置
        raw_mas = state.feat_mas_batch.transpose(1, 2)[batch_idxes]
        proc_time = state.proc_times_batch[batch_idxes]
        proc_power = state.proc_power_batch[batch_idxes]
        # Normalize 标准化
        nums_opes = state.nums_opes_batch[batch_idxes]  # 据标志位flag_sample和flag_train决定是否进行样本采样或训练
        features = self.get_normalized(raw_opes, raw_mas, proc_time, proc_power, batch_idxes, nums_opes, weight, flag_sample, flag_train)
        norm_opes = (copy.deepcopy(features[0]))
        norm_mas = (copy.deepcopy(features[1]))
        norm_proc = (copy.deepcopy(features[2]))
        norm_power = (copy.deepcopy(features[3]))

        # HGNN 的L次迭代过程
        for i in range(len(self.num_heads)):
            # First 机器节点嵌入
            # shape: [len(batch_idxes), num_mas, out_size_ma]
            h_mas = self.get_machines[i](state.ope_ma_adj_batch, state.batch_idxes, features)
            features = (features[0], h_mas, features[2], features[3])  # （features[1]）替换为第一阶段的嵌入结果h_mas
            # Second 操作节点嵌入
            # shape: [len(batch_idxes), max(num_opes), out_size_ope]
            h_opes = self.get_operations[i](state.ope_ma_adj_batch, state.ope_pre_adj_batch, state.ope_sub_adj_batch,
                                            state.batch_idxes, features)
            features = (h_opes, features[1], features[2], features[3])  # （features[0]）替换为第二阶段的嵌入结果h_opes

        # Stacking and pooling 池化操作：将节点嵌入的多维信息转化为固定维度的汇总表示
        h_mas_pooled = h_mas.mean(dim=-2)  # shape: [len(batch_idxes), out_size_ma]
        # 每个作业可能会有不同操作, which cannot be 池化 directly by the matrix
        if not flag_sample and not flag_train:
            h_opes_pooled = []
            for i in range(len(batch_idxes)):
                h_opes_pooled.append(torch.mean(h_opes[i, :nums_opes[i], :], dim=-2))
            h_opes_pooled = torch.stack(h_opes_pooled)  # shape: [len(batch_idxes), d] 在新的维度上堆叠
        else:
            h_opes_pooled = h_opes.mean(dim=-2)  # shape: [len(batch_idxes), out_size_ope]

        # 筛选满足条件的操作节点-机器节点对，并生成计算所需的张量
        # 将操作节点步数张量结束偏置张量进行比较，选取两者中较小的值作为操作节点步数（因为如果操作节点步数超过了结束偏置，那么该操作节点就已经完成）
        ope_step_batch = torch.where(state.ope_step_batch > state.end_ope_biases_batch, state.end_ope_biases_batch, state.ope_step_batch)
        jobs_gather = ope_step_batch[..., :, None].expand(-1, -1, h_opes.size(-1))[batch_idxes]
        # 使用gather函数将最新的操作节点嵌入结果h_opes与操作节点步数张量进行匹配，得到与每个操作节点相对应的机器节点
        h_jobs = h_opes.gather(1, jobs_gather)  # shape[len(batch_idxes), num_jobs, out_size_ope]
        # 将操作-机器邻接矩阵与操作节点步数（已筛选掉已完成的操作节点）进行匹配，得到每个操作-机器节点对是否可行的结果 eligible_proc
        # shape[len(batch_idxes), num_jobs, num_mas]
        eligible_proc = state.ope_ma_adj_batch[batch_idxes].gather(1, ope_step_batch[..., :, None].expand(-1, -1, state.ope_ma_adj_batch.size(-1))[batch_idxes])
        # 在 h_jobs 倒数第二维上扩展维度 shape[len(batch_idxes), num_jobs, num_mas, out_size_ope]
        h_jobs_padding = h_jobs.unsqueeze(-2).expand(-1, -1, state.proc_times_batch.size(-1), -1)
        h_mas_padding = h_mas.unsqueeze(-3).expand_as(h_jobs_padding)  # 在倒数第三维上扩展
        h_mas_pooled_padding = h_mas_pooled[:, None, None, :].expand_as(h_jobs_padding)
        h_opes_pooled_padding = h_opes_pooled[:, None, None, :].expand_as(h_jobs_padding)
        # 矩阵指示机器是否可用  shape: [len(batch_idxes), num_jobs, num_mas]
        # 若某个机器节点处于处理中状态，则设置为 false
        ma_eligible = ~state.mask_ma_procing_batch[batch_idxes].unsqueeze(1).expand_as(h_jobs_padding[..., 0])
        # 矩阵指示操作是否可用  shape: [len(batch_idxes), num_jobs, num_mas]
        # 若某个操作节点处于处理中或已完成状态，则对应的位置为 false
        job_eligible = ~(state.mask_job_procing_batch[batch_idxes] + state.mask_job_finish_batch[batch_idxes])[:, :, None].expand_as(h_jobs_padding[..., 0])
        # 作业与作业之前的约束关系
        ope_eligible = (state.schedule_job[batch_idxes])[:, :, None].expand_as(h_jobs_padding[..., 0])
        # shape: [len(batch_idxes), num_jobs, num_mas]
        eligible = job_eligible & ma_eligible & (eligible_proc == 1) & ope_eligible
        if (~(eligible)).all():  # 所有操作-机器节点对均不行
            print("No eligible O-M pair!")
            return

        # actor网络的输入张量 shape: [len(batch_idxes), num_mas, num_jobs, out_size_ma*2 + out_size_ope*2]
        h_actions = torch.cat((h_jobs_padding, h_mas_padding, h_opes_pooled_padding, h_mas_pooled_padding),
                              dim=-1).transpose(1, 2)
        h_pooled = torch.cat((h_opes_pooled, h_mas_pooled), dim=-1)  # deprecated
        mask = eligible.transpose(1, 2).flatten(1)  # 进行转置和扁平化处理，将不可行的操作-机器节点对所对应的值屏蔽掉

        # 得到优先索引 and 根据不可行的操作-机器节点对的掩码进行处理
        scores = self.actor(h_actions).flatten(1)  # 张量h_actions输入actor，并展平为一维
        scores[~mask] = float('-inf')  # 将不可能动作设置为负无穷
        action_probs = F.softmax(scores, dim=1)  # 得到动作的概率向量

        # 在训练模式下将数据存储在记忆中
        if flag_train == True:
            memories.ope_ma_adj.append(copy.deepcopy(state.ope_ma_adj_batch))  # 操作-机器邻接矩阵
            memories.ope_pre_adj.append(copy.deepcopy(state.ope_pre_adj_batch))  # 前驱操作邻接矩阵
            memories.ope_sub_adj.append(copy.deepcopy(state.ope_sub_adj_batch))  # 后继操作邻接矩阵
            memories.batch_idxes.append(copy.deepcopy(state.batch_idxes))  #
            memories.raw_opes.append(copy.deepcopy(norm_opes))  # 归一化后的操作嵌入结果
            memories.raw_mas.append(copy.deepcopy(norm_mas))  # 归一化后的机器嵌入结果
            memories.proc_time.append(copy.deepcopy(norm_proc))  # 归一化后的处理时间
            memories.proc_power.append(copy.deepcopy(norm_power))
            memories.nums_opes.append(copy.deepcopy(nums_opes))  # 每个批次的操作数量
            memories.jobs_gather.append(copy.deepcopy(jobs_gather))  # 聚合的操作-机器节点可行性矩阵
            memories.eligible.append(copy.deepcopy(eligible))

        return action_probs, ope_step_batch, h_pooled

    def act(self, state, memories, weight, flag_sample=False, flag_train=True):
        # get_action_prob 得到动作概率和每个作业当前操作（等待被调度）的ID
        action_probs, ope_step_batch, _ = self.get_action_prob(state, memories, weight, flag_sample, flag_train=flag_train)

        # DRL-S, sampling actions following \pi
        # if flag_sample:  # 在采样模式下
        #     dist = Categorical(action_probs)  # 使用Categorical分布将动作概率向量转换为离散的动作概率分布
        #     action_indexes = dist.sample()  # 进行采样
        # # DRL-G, greedily 直接选择动作概率最大
        # else:  # 在贪婪模式下
        #     action_indexes = action_probs.argmax(dim=1)

        tensor_reshaped = action_probs.view(-1, state.mask_job_finish_batch.size(1))
        for row in tensor_reshaped:
            print(row)

        dist = Categorical(action_probs)
        if random.random() < self.epsilon:  # 随机数小于当前贪婪度，则执行探索（采样模式）
            action_indexes = dist.sample()
            self.epsilon = max(0.1, self.epsilon * 0.85)
            print('-------------使用了探索')
            # if self.t < 300:
            #     self.epsilon = 0.8
            # elif self.t >= 300 and self.t <= 1000:
            #     self.epsilon = max(0.1, self.epsilon * 0.995)
            # else:
            #     self.epsilon = 0.08
            # self.t += 1
        else:  # 否则执行贪婪策略,贪婪度逐步减少
            action_indexes = action_probs.argmax(dim=1)
        print(self.epsilon)

        # 将动作编号解析为对应的机器节点（mas）、作业（jobs）和操作节点（opes）的索引
        mas = (action_indexes / state.mask_job_finish_batch.size(1)).long()
        jobs = (action_indexes % state.mask_job_finish_batch.size(1)).long()
        opes = ope_step_batch[state.batch_idxes, jobs]  # 选择的是批次索引中对应的批次的操作节点状态中相应作业的操作是否可用

        # 在训练时将数据存储在记忆体中
        if flag_train == True:
            # memories.states.append(copy.deepcopy(state))
            memories.logprobs.append(dist.log_prob(action_indexes))  # 动作概率对数
            memories.action_indexes.append(action_indexes)  # 动作索引

        return torch.stack((opes, mas, jobs), dim=1).t()

    def evaluate(self, ope_ma_adj, ope_pre_adj, ope_sub_adj, raw_opes, raw_mas, proc_time, proc_power,
                 jobs_gather, eligible, action_envs, flag_sample=False):  # 评估状态下的动作价值和状态价值，计算策略分布中的熵
        batch_idxes = torch.arange(0, ope_ma_adj.size(-3)).long()
        features = (raw_opes, raw_mas, proc_time, proc_power)

        # HGNN 的 L 次循环
        for i in range(len(self.num_heads)):
            h_mas = self.get_machines[i](ope_ma_adj, batch_idxes, features)
            features = (features[0], h_mas, features[2], features[3])  # 将features中的第二个元素替换为h_mas，得到新的特征
            h_opes = self.get_operations[i](ope_ma_adj, ope_pre_adj, ope_sub_adj, batch_idxes, features)
            features = (h_opes, features[1], features[2], features[3])

        # Stacking and pooling 汇聚和堆叠
        h_mas_pooled = h_mas.mean(dim=-2)
        h_opes_pooled = h_opes.mean(dim=-2)

        # 找到可用的 O-M pairs (eligible actions) and 生成 tensors for critic calculation
        h_jobs = h_opes.gather(1, jobs_gather)
        h_jobs_padding = h_jobs.unsqueeze(-2).expand(-1, -1, proc_time.size(-1), -1)
        h_mas_padding = h_mas.unsqueeze(-3).expand_as(h_jobs_padding)
        h_mas_pooled_padding = h_mas_pooled[:, None, None, :].expand_as(h_jobs_padding)
        h_opes_pooled_padding = h_opes_pooled[:, None, None, :].expand_as(h_jobs_padding)

        h_actions = torch.cat((h_jobs_padding, h_mas_padding, h_opes_pooled_padding, h_mas_pooled_padding),
                              dim=-1).transpose(1, 2)  # 将这些特征按指定维度进行拼接
        h_pooled = torch.cat((h_opes_pooled, h_mas_pooled), dim=-1)
        scores = self.actor(h_actions).flatten(1)
        mask = eligible.transpose(1, 2).flatten(1)

        scores[~mask] = float('-inf')
        action_probs = F.softmax(scores, dim=1)  # 动作概率
        state_values = self.critic(h_pooled)  # 得到对状态值的估计
        dist = Categorical(action_probs.squeeze())
        action_logprobs = dist.log_prob(action_envs)  # 对数概率
        dist_entropys = dist.entropy()  # 计算概率分布的熵
        return action_logprobs, state_values.squeeze().double(), dist_entropys


class PPO:
    def __init__(self, model_paras, train_paras, num_envs=1):
        self.lr = train_paras["lr"]  # 学习率
        self.betas = train_paras["betas"]  # 默认参数 for Adam
        self.gamma = train_paras["gamma"]  # 折扣因子
        self.eps_clip = train_paras["eps_clip"]  # clip ratio for PPO 用于控制策略更新步长
        self.K_epochs = train_paras["K_epochs"]  # 更新策略 for K epochs 每次更新策略时的循环迭代次数
        self.A_coeff = train_paras["A_coeff"]  # 策略损失的系数
        self.vf_coeff = train_paras["vf_coeff"]  # 值函数损失的系数
        self.entropy_coeff = train_paras["entropy_coeff"]  # coefficient for entropy term 熵项的系数
        self.num_envs = num_envs  # 并行执行的环境实例数量
        self.device = model_paras["device"]  # PyTorch 设备
        self.minibatch_size = train_paras["minibatch_size"]  # 每次更新时的小批量数据大小
        self.update_timestep = train_paras["update_timestep"]

        self.policy = HGNNScheduler(model_paras).to(self.device)  # 创建HGNNScheduler模型的实例
        self.policy_old = copy.deepcopy(self.policy)  # 复制一份作为旧的策略网络
        self.policy_old.load_state_dict(self.policy.state_dict())  # 加载当前策略的参数到旧的策略中
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=self.lr, betas=self.betas)  # Adam优化器初始化参数
        self.MseLoss = nn.MSELoss()  # 均方误差损失

    def stack_list(self, ten):
        tans = []
        for t in ten:
            tans.append(t.transpose(0, 1).flatten(0, 1).unsqueeze(0))
        return tans

    def update(self, memory):
        # 进行扁平化处理存储在记忆中的数据 (parallel instances and decision points) stack和transpose操作将相应的维度移动到正确的位置
        old_ope_pre_adj = self.stack_list(memory.ope_pre_adj)
        old_ope_ma_adj = self.stack_list(memory.ope_ma_adj)
        old_ope_sub_adj = self.stack_list(memory.ope_sub_adj)
        old_raw_opes = self.stack_list(memory.raw_opes)
        old_raw_mas = self.stack_list(memory.raw_mas)
        old_proc_time = self.stack_list(memory.proc_time)
        old_proc_power = self.stack_list(memory.proc_power)
        old_jobs_gather = self.stack_list(memory.jobs_gather)
        old_eligible = self.stack_list(memory.eligible)
        memory_rewards = torch.stack(memory.rewards, dim=0).transpose(0, 1)
        memory_is_terminals = torch.stack(memory.is_terminals, dim=0).transpose(0, 1)
        old_logprobs = torch.stack(memory.logprobs, dim=0).transpose(0, 1).flatten(0, 1)
        old_action_envs = torch.stack(memory.action_indexes, dim=0).transpose(0, 1).flatten(0, 1)

        # 估计和归一化奖励的部分
        rewards_envs = []  # 存储每个环境实例的归一化奖励值
        discounted_rewards = 0
        for i in range(self.num_envs):
            rewards = []
            discounted_reward = 0
            for reward, is_terminal in zip(reversed(memory_rewards[i]),
                                           reversed(memory_is_terminals[i])):  # 逆序遍历，以便按照时间顺序计算累积折扣奖励
                if is_terminal:
                    discounted_rewards += discounted_reward
                    discounted_reward = 0
                discounted_reward = reward + (self.gamma * discounted_reward)  # 当前奖励加上之前的累积折扣奖励乘以折扣因子
                rewards.insert(0, discounted_reward)  # 将discounted_reward插入到rewards列表的第一个位置
            discounted_rewards += discounted_reward
            rewards = torch.tensor(rewards, dtype=torch.float64).to(self.device)  # 将计算得到的累积折扣奖励列表逆序排列
            if (rewards.size(0) == 1):
                rewards[:] = 0
                rewards_envs.append(rewards)
            else:
                rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-5)  # 计算累积折扣奖励的均值和标准差
                rewards_envs.append(rewards)
        rewards_envs = torch.cat(rewards_envs)  # shape(num_envs * num_decisions, )

        loss_epochs = 0  # 统计每个epoch的平均损失
        full_batch_size = len(old_ope_ma_adj)  # 获取当前批次数据的总大小
        num_complete_minibatches = math.floor(full_batch_size / self.minibatch_size)  # 组成完整小批量的数据数量
        # 执行K轮优化策略
        for _ in range(self.K_epochs):
            random_index = random.randint(0, num_complete_minibatches)
            if random_index < num_complete_minibatches:  # 根据当前的小批量数据计算出对应的起始索引start_idx和终止索引end_idx
                start_idx = random_index * self.minibatch_size
                end_idx = (random_index + 1) * self.minibatch_size
            else:
                start_idx = random_index * self.minibatch_size
                end_idx = full_batch_size
            # 根据当前策略网络和环境实例数据计算出当前状态下所有动作的对数概率、对应的状态价值以及动作概率的熵
            loss = []
            for epo in range(start_idx, end_idx):
                logprobs, state_values, dist_entropy = \
                    self.policy.evaluate(old_ope_ma_adj[epo],
                                         old_ope_pre_adj[epo],
                                         old_ope_sub_adj[epo],
                                         old_raw_opes[epo],
                                         old_raw_mas[epo],
                                         old_proc_time[epo],
                                         old_proc_power[epo],
                                         old_jobs_gather[epo],
                                         old_eligible[epo],
                                         old_action_envs[epo])

                # 根据旧策略和新策略的对数概率计算出优势函数比率，并根据优势函数比率、归一化奖励和状态价值之间的差异计算出两个损失函数
                ratios = torch.exp(
                    logprobs - old_logprobs[epo].detach())
                advantages = rewards_envs[epo] - state_values.detach()
                surr1 = ratios * advantages  # 最大化当前策略相对于旧策略的改进程度
                surr2 = torch.clamp(ratios, 1 - self.eps_clip,
                                    1 + self.eps_clip) * advantages  # 将rations限制在1±self.eps_clip的范围内
                # 将两个损失函数项加权求和，得到总的损失函数
                loss1 = self.A_coeff * torch.min(surr1, surr2)
                if state_values.size() == 0:
                    loss2 = self.vf_coeff * self.MseLoss(state_values.unsqueeze(0), rewards_envs[epo])
                else:
                    loss2 = self.vf_coeff * self.MseLoss(state_values, rewards_envs[epo])
                loss.append(- loss1 + loss2 - self.entropy_coeff * dist_entropy)
            loss = torch.tensor(loss)
            loss_a = loss.mean()
            loss_epochs += loss_a.detach()  # 统计当前epoch中每批小批量数据的平均损失

            self.optimizer.zero_grad()  # 优化器梯度设置为0
            loss_a.requires_grad_(True)
            loss_a.backward()  # 求总损失函数的平均值的梯度，并反向传播一次
            self.optimizer.step()

        # Copy new weights into old policy:
        self.policy_old.load_state_dict(self.policy.state_dict())  # 将新策略网络的权重复制到旧策略网络中

        # 计算平均损失和折扣奖励的平均值
        return loss_epochs.item() / self.K_epochs, \
               discounted_rewards.item() / (self.num_envs * self.update_timestep)
        # old_ope_ma_adj = torch.stack(memory.ope_ma_adj, dim=0).transpose(0, 1).flatten(0, 1)
        # old_ope_pre_adj = torch.stack(memory.ope_pre_adj, dim=0).transpose(0, 1).flatten(0, 1)
        # old_ope_sub_adj = torch.stack(memory.ope_sub_adj, dim=0).transpose(0, 1).flatten(0, 1)
        # old_raw_opes = torch.stack(memory.raw_opes, dim=0).transpose(0, 1).flatten(0, 1)
        # old_raw_mas = torch.stack(memory.raw_mas, dim=0).transpose(0, 1).flatten(0, 1)
        # old_proc_time = torch.stack(memory.proc_time, dim=0).transpose(0, 1).flatten(0, 1)
        # old_proc_power = torch.stack(memory.proc_power, dim=0).transpose(0, 1).flatten(0, 1)
        # old_jobs_gather = torch.stack(memory.jobs_gather, dim=0).transpose(0, 1).flatten(0, 1)
        # old_eligible = torch.stack(memory.eligible, dim=0).transpose(0, 1).flatten(0, 1)
        # memory_rewards = torch.stack(memory.rewards, dim=0).transpose(0, 1)
        # memory_is_terminals = torch.stack(memory.is_terminals, dim=0).transpose(0, 1)
        # old_logprobs = torch.stack(memory.logprobs, dim=0).transpose(0, 1).flatten(0, 1)
        # old_action_envs = torch.stack(memory.action_indexes, dim=0).transpose(0, 1).flatten(0, 1)
        #
        # # 估计和归一化奖励的部分
        # rewards_envs = []  # 存储每个环境实例的归一化奖励值
        # discounted_rewards = 0
        # for i in range(self.num_envs):
        #     rewards = []
        #     discounted_reward = 0
        #     for reward, is_terminal in zip(reversed(memory_rewards[i]), reversed(memory_is_terminals[i])):  # 逆序遍历，以便按照时间顺序计算累积折扣奖励
        #         if is_terminal:
        #             discounted_rewards += discounted_reward
        #             discounted_reward = 0
        #         discounted_reward = reward + (self.gamma * discounted_reward)  # 当前奖励加上之前的累积折扣奖励乘以折扣因子
        #         rewards.insert(0, discounted_reward)  # 将discounted_reward插入到rewards列表的第一个位置
        #     discounted_rewards += discounted_reward
        #     rewards = torch.tensor(rewards, dtype=torch.float64).to(self.device)  # 将计算得到的累积折扣奖励列表逆序排列
        #     if(rewards.size(0) == 1):
        #         rewards[:] = 0
        #         rewards_envs.append(rewards)
        #     else:
        #         rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-5)  # 计算累积折扣奖励的均值和标准差
        #         rewards_envs.append(rewards)
        # rewards_envs = torch.cat(rewards_envs)  # shape(num_envs * num_decisions, )
        #
        # loss_epochs = 0  # 统计每个epoch的平均损失
        # full_batch_size = old_ope_ma_adj.size(0)  # 获取当前批次数据的总大小
        # num_complete_minibatches = math.floor(full_batch_size / self.minibatch_size)  # 组成完整小批量的数据数量
        # # 执行K轮优化策略
        # for _ in range(self.K_epochs):
        #     for i in range(num_complete_minibatches + 1):
        #         if i < num_complete_minibatches:  # 根据当前的小批量数据计算出对应的起始索引start_idx和终止索引end_idx
        #             start_idx = i * self.minibatch_size
        #             end_idx = (i + 1) * self.minibatch_size
        #         else:
        #             start_idx = i * self.minibatch_size
        #             end_idx = full_batch_size
        #         # 根据当前策略网络和环境实例数据计算出当前状态下所有动作的对数概率、对应的状态价值以及动作概率的熵
        #         logprobs, state_values, dist_entropy = \
        #             self.policy.evaluate(old_ope_ma_adj[start_idx: end_idx, :, :],
        #                                  old_ope_pre_adj[start_idx: end_idx, :, :],
        #                                  old_ope_sub_adj[start_idx: end_idx, :, :],
        #                                  old_raw_opes[start_idx: end_idx, :, :],
        #                                  old_raw_mas[start_idx: end_idx, :, :],
        #                                  old_proc_time[start_idx: end_idx, :, :],
        #                                  old_proc_power[start_idx: end_idx, :, :],
        #                                  old_jobs_gather[start_idx: end_idx, :, :],
        #                                  old_eligible[start_idx: end_idx, :, :],
        #                                  old_action_envs[start_idx: end_idx])
        #
        #         # 根据旧策略和新策略的对数概率计算出优势函数比率，并根据优势函数比率、归一化奖励和状态价值之间的差异计算出两个损失函数
        #         ratios = torch.exp(logprobs - old_logprobs[i * self.minibatch_size:(i + 1) * self.minibatch_size].detach())
        #         advantages = rewards_envs[i * self.minibatch_size:(i + 1) * self.minibatch_size] - state_values.detach()
        #         surr1 = ratios * advantages  # 最大化当前策略相对于旧策略的改进程度
        #         surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages  # 将rations限制在1±self.eps_clip的范围内
        #         # 将两个损失函数项加权求和，得到总的损失函数
        #         loss1 = self.A_coeff * torch.min(surr1, surr2)
        #         if state_values.size() == 0:
        #             loss2 = self.vf_coeff * self.MseLoss(state_values.unsqueeze(0), rewards_envs[i * self.minibatch_size:(i + 1) * self.minibatch_size])
        #         else:
        #             loss2 = self.vf_coeff * self.MseLoss(state_values, rewards_envs[i * self.minibatch_size:(i + 1) * self.minibatch_size])
        #         loss = - loss1 + loss2 - self.entropy_coeff * dist_entropy
        #         loss_epochs += loss.mean().detach()  # 统计当前epoch中每批小批量数据的平均损失
        #
        #         self.optimizer.zero_grad()  # 优化器梯度设置为0
        #         loss.mean().backward()  # 求总损失函数的平均值的梯度，并反向传播一次
        #
        #         clip_grad_norm_(self.policy.parameters(), max_norm=1.0)  # L2范数裁剪
        #         # clip_grad_value_(self.model.parameters(), clip_value=1.0)  # 最大值裁剪
        #         self.optimizer.step()
        #
        # # Copy new weights into old policy:
        # self.policy_old.load_state_dict(self.policy.state_dict())  # 将新策略网络的权重复制到旧策略网络中
        #
        # # 计算平均损失和折扣奖励的平均值
        # return loss_epochs.item() / self.K_epochs, \
        #        discounted_rewards.item() / (self.num_envs * self.update_timestep)

    def load(self, model_path):
        checkpoint = torch.load(model_path)
        # 恢复模型参数
        self.policy.load_state_dict(checkpoint['model_state_dict'])
        self.policy_old.load_state_dict(checkpoint['model_state_dict'])
        # 恢复优化器状态
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

    def save(self, current_date):
        torch.save({
            'model_state_dict': self.policy.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, f'D:/PyCharm Community Edition 2022.3/PythonProject/Job_Shop_Scheduling-2/solutions/FAJSP_DRL/models/PPO{current_date}(20.pt')
