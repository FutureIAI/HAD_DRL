
import sys

import torch
import numpy as np
from pathlib import Path  # 一种面向对象的方式来处理路径和文件操作

from scheduling_environment.jobShop import JobShop
from data_parsers.parser_fajsp import parse
from solutions.helper_functions import load_job_shop_env
from scheduling_environment.operation import Operation

# 将基本路径（base path）添加到 Python 模块搜索路径中
base_path = Path(__file__).resolve().parents[2]  # .parents[2] 获取脚本文件的父目录的父目录
sys.path.append(str(base_path))  # 将基本路径字符串转换为绝对路径，并添加到 Python 模块搜索路径中


def load_fajs_case(lines, num_mas, num_opes):  # lines：包含 FAJSP 实例信息的文本行列表
    """
    加载本地 FAJSP 实例
    """
    flag = 0  # 标志位，用于处理第一行和最后一行之间的数据行
    matrix_proc_time = torch.zeros(size=(num_opes, num_mas))  # 存储操作在各机器上的处理时间
    matrix_pre_proc = torch.full(size=(num_opes, num_opes), dtype=torch.bool, fill_value=False)  # matrix_ope_ma_adj 的转置矩阵
    matrix_cal_cumul = torch.zeros(size=(num_opes, num_opes)).int()  # 存储操作的累计处理时间
    nums_ope = []  # 每个作业的操作数目列表
    opes_appertain = np.array([])  # 存储操作所属的作业编号
    num_ope_biases = []  # 每个作业第一个操作的编号列表

    # 逐行解析数据
    for line in lines:
        if flag == 0:  # 第一行
            flag += 1
        elif line == "\n":  # 最后一行
            break
        else:  # 其他
            num_ope_bias = int(sum(nums_ope))  # 该作业第一个操作的ID
            num_ope_biases.append(num_ope_bias)
            # 检测该作业的信息 and 返回操作数
            num_ope = edge_detec(line, num_ope_bias, matrix_proc_time, matrix_pre_proc, matrix_cal_cumul)
            nums_ope.append(num_ope)
            # nums_option = np.concatenate((nums_option, num_option))
            opes_appertain = np.concatenate((opes_appertain, np.ones(num_ope) * (flag - 1)))  # ones 函数创建一个长度为 num_ope 的数组，其中每个元素均为 flag - 1（作业编号）
            flag += 1

    matrix_ope_ma_adj = torch.where(matrix_proc_time > 0, 1, 0)  # 当元素大于0时，matrix_ope_ma_adj 中对应位置的元素为1，否则为0
    # 如果操作不够填充为0 (for parallel computation)
    opes_appertain = np.concatenate((opes_appertain, np.zeros(num_opes - opes_appertain.size)))
    return matrix_proc_time, matrix_ope_ma_adj, matrix_pre_proc, matrix_pre_proc.t(), \
           torch.tensor(opes_appertain).int(), torch.tensor(num_ope_biases).int(), \
           torch.tensor(nums_ope).int(), matrix_cal_cumul


def load_fajs(path, num_mas, num_opes, num_wos):
    """
    加载本地 FAJSP 实例
    """
    jobShopEnv = load_job_shop_env(path, from_absolute_path=True)
    drl_tensors = load_fajs_from_sim(jobShopEnv, num_mas, num_opes, num_wos)  # 传入加载得到的 jobShopEnv 对象和其他参数
    return drl_tensors, jobShopEnv


def load_fajs_from_sim(jobShopEnv: JobShop, num_mas, num_opes, num_wos):
    """将scheduling_environment环境转换为DRL环境"""

    matrix_proc_time = torch.zeros(size=(num_opes, num_mas))  # 操作在各机器上的处理时间
    matrix_proc_power = torch.zeros(size=(num_opes, num_mas))
    matrix_ma_idlepower = torch.zeros(size=(num_mas,)).int()
    matrix_ma_opepoer = torch.zeros(size=(num_mas,)).int()
    matrix_ope_ma_adj = torch.zeros(size=(num_opes, num_mas)).int()  # 操作与机器的关联关系
    matrix_pre_proc = torch.full(size=(num_opes, num_opes), dtype=torch.bool, fill_value=False)  # 操作之间的前置关系
    matrix_cal_cumul = torch.zeros(size=(num_opes, num_opes)).int()  # 操作的累计处理时间
    opes_appertain = torch.zeros(size=(num_opes,)).int()  # 操作所属的作业编号
    num_ope_biases = torch.zeros(size=(jobShopEnv.nr_of_jobs,)).int()  # 每个作业第一个操作的编号
    nums_ope = torch.zeros(size=(jobShopEnv.nr_of_jobs,)).int()  # 每个作业的操作数目
    matrix_first_rate = torch.zeros(size=(num_wos, num_mas)).float()
    matrix_end_rate = torch.zeros(size=(num_wos, num_mas)).float()

    for job in jobShopEnv.jobs:
        # 每个作业的第一个操作的编号和操作数目存储在num_ope_biases和nums_ope中
        num_ope_biases[job.job_id] = job.operations[0].operation_id
        nums_ope[job.job_id] = len(job.operations)

        # 为每个操作与其之后的操作建立累计处理时间关系
        nr_remaining_ops = len(job.operations)
        for operation in job.operations:  # 在job内
            nr_remaining_ops -= 1
            for op in range(1, nr_remaining_ops + 1):
                matrix_cal_cumul[operation.operation_id][operation.operation_id + op] = 1

    for pre, ids in jobShopEnv.precedence_relations_jobs.items():
        if len(ids) >= 1:
            for id in range(len(ids)):
                for ope in range(num_ope_biases[ids[id]], num_ope_biases[ids[id]] + nums_ope[ids[id]]):
                    matrix_cal_cumul[ope][num_ope_biases[pre]] = 1


    for operation in jobShopEnv.operations:
        opes_appertain[operation.operation_id] = operation.job_id  # 操作所属编号
        for machine_id, duration in operation.processing_times.items():
            matrix_proc_time[operation.operation_id][machine_id] = duration  # 处理时间
            matrix_ope_ma_adj[operation.operation_id][machine_id] = 1  # 操作与机器的关联
            for predecessor in operation.predecessors:
                predecessor: Operation  # 前驱操作与当前操作置为 true
                matrix_pre_proc[predecessor.operation_id][operation.operation_id] = True
        for machine_id, power in operation.processing_power.items():
            matrix_proc_power[operation.operation_id, machine_id] = power

    for worker in jobShopEnv.workers:
        for machine_id, rate in worker.worker_first.items():
            matrix_first_rate[worker.worker_id][machine_id] = rate
        for machine_id, rate in worker.worker_end.items():
            matrix_end_rate[worker.worker_id][machine_id] = rate

    for machine in jobShopEnv.machines:
        matrix_ma_idlepower[machine.machine_id] = machine.get_idlepower(machine.machine_id)
        matrix_ma_opepoer[machine.machine_id] = machine.get_opepower(machine.machine_id)

    return matrix_proc_time, matrix_ope_ma_adj, matrix_pre_proc, matrix_pre_proc.t(), opes_appertain,\
           num_ope_biases, nums_ope, matrix_cal_cumul, matrix_first_rate, matrix_end_rate, matrix_proc_power, matrix_ma_idlepower, matrix_ma_opepoer


def add_fajs(JobShop, num_mas, num_opes):
    """将scheduling_environment环境转换为DRL环境"""

    matrix_proc_time = torch.zeros(size=(num_opes, num_mas))  # 操作在各机器上的处理时间
    matrix_proc_power = torch.zeros(size=(num_opes, num_mas))
    matrix_ope_ma_adj = torch.zeros(size=(num_opes, num_mas)).int()  # 操作与机器的关联关系
    matrix_pre_proc = torch.full(size=(num_opes, num_opes), dtype=torch.bool, fill_value=False)  # 操作之间的前置关系
    matrix_cal_cumul = torch.zeros(size=(num_opes, num_opes)).int()  # 操作的累计处理时间
    opes_appertain = torch.zeros(size=(num_opes,)).int()  # 操作所属的作业编号
    num_ope_biases = torch.zeros(size=(JobShop.nr_of_jobs,)).int()  # 作业第一个操作的编号
    nums_ope = torch.zeros(size=(JobShop.nr_of_jobs,)).int()  # 每个作业的操作数目

    i = 0
    for job in JobShop.jobs:
        # 每个作业的第一个操作的编号和操作数目存储在num_ope_biases和nums_ope中
        num_ope_biases[i] = job.operations[i].operation_id
        nums_ope[i] = len(job.operations)
        i += 1

        # 为每个操作与其之后的操作建立累计处理时间关系
        nr_remaining_ops = len(job.operations)
        for j in range(len(job.operations)):
            nr_remaining_ops -= 1
            for op in range(1, nr_remaining_ops + 1):
                matrix_cal_cumul[j][j + op] = 1

    k = 0
    first_ope = JobShop.operations[0].operation_id
    for operation in JobShop.operations:
        opes_appertain[k] = operation.job_id  # 操作所属编号
        for machine_id, duration in operation.processing_times.items():
            matrix_proc_time[k][machine_id] = duration  # 处理时间
            matrix_ope_ma_adj[k][machine_id] = 1  # 操作与机器的关联
            for predecessor in operation.predecessors:
                predecessor: Operation  # 前驱操作与当前操作置为 true
                matrix_pre_proc[predecessor.operation_id - first_ope][operation.operation_id - first_ope] = True
        for machine_id, power in operation.processing_power.items():
            matrix_proc_power[k][machine_id] = power
        k += 1

    return matrix_proc_time, matrix_ope_ma_adj, matrix_pre_proc, matrix_pre_proc.t(), \
           opes_appertain, num_ope_biases, nums_ope, matrix_cal_cumul, matrix_proc_power


def nums_detec(lines):
    """
    计算作业、机器、操作的数量
    """
    line_split = lines[0].strip().split()  # 获取第一行的内容
    num_opes = int(line_split[0])
    num_rela = int(line_split[1])
    num_mas = int(line_split[2])
    num_wos = int(line_split[3])
    return num_mas, num_opes, num_rela, num_wos


def edge_detec(line, num_ope_bias, matrix_proc_time, matrix_pre_proc, matrix_cal_cumul):
    """
    解析作业的信息

    line：表示包含作业信息的一行文本。
    num_ope_bias：整数值，表示操作数量的偏移量。
    matrix_proc_time：表示操作和机器之间处理时间的矩阵。
    matrix_pre_proc：表示是否可以在同一作业内的操作之间进行前置处理的矩阵。
    matrix_cal_cumul：表示计算累积时间的矩阵。
    """
    line_split = line.split()
    flag = 0
    flag_time = 0
    flag_new_ope = 1
    idx_ope = -1
    num_ope = 0  # 存储该作业的操作数
    num_option = np.array([])  # 存储该作业每个操作可能的机器数
    mac = 0
    for i in line_split:  # 以空格为分隔符遍历line中的每个元素
        x = int(i)  # 第一个数为操作数
        # 遇到新作业
        if flag == 0:
            num_ope = x
            flag += 1
        # 遇到新操作
        elif flag == flag_new_ope:
            idx_ope += 1
            flag_new_ope += x * 2 + 1
            num_option = np.append(num_option, x)
            if idx_ope != num_ope - 1:
                matrix_pre_proc[idx_ope + num_ope_bias][idx_ope + num_ope_bias + 1] = True
            if idx_ope != 0:
                vector = torch.zeros(matrix_cal_cumul.size(0))
                vector[idx_ope + num_ope_bias - 1] = 1
                matrix_cal_cumul[:, idx_ope + num_ope_bias] = matrix_cal_cumul[:, idx_ope + num_ope_bias - 1] + vector
            flag += 1
        # 记录每个操作在相应机器上的处理时间
        elif flag_time == 0:  # 当前元素是机器编号
            mac = x - 1
            flag += 1
            flag_time = 1
        else:  # 当前元素是处理时间
            matrix_proc_time[idx_ope + num_ope_bias][mac] = x
            flag += 1
            flag_time = 0
    return num_ope