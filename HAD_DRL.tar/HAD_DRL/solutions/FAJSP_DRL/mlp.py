# GITHUB REPO: https://github.com/zcaicaros/L2D


import torch
import torch.nn as nn
import torch.nn.functional as F


class MLP(nn.Module):  # 实现了一个多层感知机（MLP）模型
    def __init__(self, num_layers, input_dim, hidden_dim, output_dim):
        """
            num_layers: 神经网络中层数(EXCLUDING the input layer). 如果层数为1, this reduces to 线性模型.
            input_dim: dimensionality of input features 输入特征维度
            hidden_dim: dimensionality of hidden units at ALL layers 所有层的隐藏单元维度
            output_dim: number of classes for prediction 预测类数
            device: which device to use 使用哪个设备
        """

        super(MLP, self).__init__()

        self.linear_or_not = True  # default is linear model 是否是线性模型
        self.num_layers = num_layers

        if num_layers < 1:
            raise ValueError("number of layers should be positive!")
        elif num_layers == 1:
            # 线性模型
            self.linear = nn.Linear(input_dim, output_dim)
        else:
            # 多层模型
            self.linear_or_not = False
            self.linears = torch.nn.ModuleList()  # 用于存储各个隐藏层的线性变换层
            self.batch_norms = torch.nn.ModuleList()  # 用于存储各个隐藏层的批标准化层

            self.linears.append(nn.Linear(input_dim, hidden_dim))  # 添加了第一个隐藏层的线性变换层
            for layer in range(num_layers - 2):
                self.linears.append(nn.Linear(hidden_dim, hidden_dim))
            self.linears.append(nn.Linear(hidden_dim, output_dim))  # 添加最后一个隐藏层

            for layer in range(num_layers - 1):  # 输入层没有批标准化层
                self.batch_norms.append(nn.BatchNorm1d((hidden_dim)))

    def forward(self, x):  # 用于执行模型的前向运算
        if self.linear_or_not:
            # 是线性模型，对输入进行线性变换
            return self.linear(x)
        else:
            # If MLP
            h = x
            for layer in range(self.num_layers - 1):  # 对输入h依次进行线性变换、批标准化和ReLU激活操作
                h = F.relu(self.batch_norms[layer](self.linears[layer](h)))
            return self.linears[self.num_layers - 1](h)  # 经过线性变换之后再输出


class MLPActor(nn.Module):
    def __init__(self, num_layers, input_dim, hidden_dim, output_dim):
        """
            num_layers: number of layers in the neural networks (EXCLUDING the input layer). If num_layers=1, this reduces to linear model.
            input_dim: dimensionality of input features
            hidden_dim: dimensionality of hidden units at ALL layers
            output_dim: number of classes for prediction
            device: which device to use
        """

        super(MLPActor, self).__init__()

        self.linear_or_not = True  # default is linear model 默认是线性模型
        self.num_layers = num_layers

        if num_layers < 1:
            raise ValueError("number of layers should be positive!")
        elif num_layers == 1:
            # Linear model
            self.linear = nn.Linear(input_dim, output_dim)
        else:
            # Multi-layer model
            self.linear_or_not = False
            self.linears = torch.nn.ModuleList()
            '''
            self.batch_norms = torch.nn.ModuleList()
            '''

            self.linears.append(nn.Linear(input_dim, hidden_dim))
            for layer in range(num_layers - 2):
                self.linears.append(nn.Linear(hidden_dim, hidden_dim))
            self.linears.append(nn.Linear(hidden_dim, output_dim))
            '''
            for layer in range(num_layers - 1):
                self.batch_norms.append(nn.BatchNorm1d((hidden_dim)))
            '''

    def forward(self, x):
        if self.linear_or_not:
            #
            return self.linear(x)
        else:
            # If MLP
            h = x
            for layer in range(self.num_layers - 1):
                '''
                h = F.relu(self.batch_norms[layer](self.linears[layer](h)))
                '''
                # h = torch.tanh(self.linears[layer](h))  # 使用了tanh激活函数，即双曲正切函数
                h = F.leaky_relu(self.linears[layer](h))
            return self.linears[self.num_layers - 1](h)


class MLPCritic(nn.Module):
    def __init__(self, num_layers, input_dim, hidden_dim, output_dim):
        """
            num_layers: number of layers in the neural networks (EXCLUDING the input layer). If num_layers=1, this reduces to linear model.
            input_dim: dimensionality of input features
            hidden_dim: dimensionality of hidden units at ALL layers
            output_dim: number of classes for prediction
            device: which device to use
        """

        super(MLPCritic, self).__init__()

        self.linear_or_not = True  # default is linear model
        self.num_layers = num_layers

        if num_layers < 1:
            raise ValueError("number of layers should be positive!")
        elif num_layers == 1:
            # Linear model
            self.linear = nn.Linear(input_dim, output_dim)
        else:
            # Multi-layer model
            self.linear_or_not = False
            self.linears = torch.nn.ModuleList()
            '''
            self.batch_norms = torch.nn.ModuleList()
            '''

            self.linears.append(nn.Linear(input_dim, hidden_dim))
            for layer in range(num_layers - 2):
                self.linears.append(nn.Linear(hidden_dim, hidden_dim))
            self.linears.append(nn.Linear(hidden_dim, output_dim))
            '''
            for layer in range(num_layers - 1):
                self.batch_norms.append(nn.BatchNorm1d((hidden_dim)))
            '''

    def forward(self, x):
        if self.linear_or_not:
            # If linear model
            return self.linear(x)
        else:
            # If MLP
            h = x
            for layer in range(self.num_layers - 1):
                '''
                h = F.relu(self.batch_norms[layer](self.linears[layer](h)))
                '''
                # h = torch.tanh(self.linears[layer](h))
                h = F.leaky_relu(self.linears[layer](h))
            return self.linears[self.num_layers - 1](h)
