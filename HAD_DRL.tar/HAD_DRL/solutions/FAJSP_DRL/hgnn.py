# GITHUB REPO: https://github.com/songwenas12/fjsp-drl


import torch
from torch import nn
from torch.nn import Identity
import torch.nn.functional as F


class GATedge(nn.Module):
    """
    Machine node embedding 机器节点编码，用于处理图数据的节点之间的关系
    GAT（Graph Attention Network）模型，通过’注意力机制‘来学习节点之间的依赖关系，能够捕捉到图结构中的局部信息
    """

    def __init__(self,
                 in_feats,  # 输入维度
                 out_feats,  # 输出维度
                 num_head,  # 注意力头数
                 feat_drop=0.1,  # 特征丢弃率，用于在训练过程中随机丢弃部分输入特征，以减少过拟合
                 attn_drop=0.,  # 注意力丢弃率，用于在训练过程中随机丢弃部分注意力系数，以增加模型的鲁棒性
                 negative_slope=0.2,  # 负斜率
                 residual=False,
                 activation=None):

        super(GATedge, self).__init__()  # 用于调用父类构造函数，并将 GATedge 作为第一个参数进行传递
        self._num_heads = num_head  # 实际实验中使用单头
        self._in_src_feats = in_feats[0]  # 输入特征中源节点的特征维度
        self._in_dst_feats = in_feats[1]  # 输入特征中目标节点的特征维度
        self._out_feats = out_feats

        # 根据输入特征的类型选择相应的线性变换层
        if isinstance(in_feats, tuple):  # 是元组，对源节点特征、目标节点特征和边特征进行线性变换
            self.fc_src = nn.Linear(self._in_src_feats, out_feats * num_head, bias=False)
            self.fc_dst = nn.Linear(self._in_dst_feats, out_feats * num_head, bias=False)
            self.fc_edge = nn.Linear(1, out_feats * num_head, bias=False)
        else:  # 不是元组，则使用一个线性变换层fc
            self.fc = nn.Linear(self._in_src_feats, out_feats * num_head, bias=False)
        # 用于计算注意力权重（可学习）
        self.attn_l = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        self.attn_r = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        self.attn_e = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        # 定义了特征丢弃和注意力丢弃的Dropout层，以及使用负斜率参数e定义的LeakyReLU激活函数。
        self.feat_drop = nn.Dropout(feat_drop)
        self.attn_drop = nn.Dropout(attn_drop)
        self.leaky_relu = nn.LeakyReLU(negative_slope)

        # 用于设置残差连接（最后实验没用）
        if residual:
            if self._in_dst_feats != out_feats:  # 判断目标节点特征的维度是否等于输出特征的维度
                self.res_fc = nn.Linear(self._in_dst_feats, num_head * out_feats,
                                    bias=False)  # 将目标节点特征映射到num_head * out_feats的输出维度
            else:
                self.res_fc = Identity()  # 不对目标节点特征进行额外的变换
        else:
            self.register_buffer('res_fc', None)

        self.reset_parameters()  # 调用reset_parameters()函数来初始化模型中的参数
        self.activation = activation  # 定义了激活函数activation用于对模型输出进行非线性变换

    # 用于初始化模型中的参数，采用了Xavier正态分布初始化方法
    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')  # 调用函数计算出 ReLU 激活函数的增益
        if hasattr(self, 'fc'):  # 判断模型是否存在线性变换层fc
            nn.init.xavier_normal_(self.fc.weight, gain=gain)  # 对其权重进行Xavier正态分布初始化，使用增益值为计算得到的ReLU增益
        else:
            nn.init.xavier_normal_(self.fc_src.weight, gain=gain)
            nn.init.xavier_normal_(self.fc_dst.weight, gain=gain)
            nn.init.xavier_normal_(self.fc_edge.weight, gain=gain)
        nn.init.xavier_normal_(self.attn_l, gain=gain)
        nn.init.xavier_normal_(self.attn_r, gain=gain)
        nn.init.xavier_normal_(self.attn_e, gain=gain)

    # 神经网络模型的前向传播函数
    def forward(self, ope_ma_adj_batch, batch_idxes, feat):
        # Two linear transformations are used for the machine nodes and operation nodes, respective
        # In linear transformation, an W^O (\in R^{d \times 7}) for \mu_{ijk} is equivalent to
        #   W^{O'} (\in R^{d \times 6}) and W^E (\in R^{d \times 1}) for the nodes and edges respectively
        if isinstance(feat, tuple):
            h_src = self.feat_drop(feat[0])  # 分别对源节点和目标节点的特征进行丢弃率(dropout)操作
            h_dst = self.feat_drop(feat[1])
            if not hasattr(self, 'fc_src'):
                self.fc_src, self.fc_dst = self.fc, self.fc
            feat_src = self.fc_src(h_src)
            feat_dst = self.fc_dst(h_dst)
        else:
            # Deprecated in final experiment 不再使用
            h_src = h_dst = self.feat_drop(feat)
            feat_src = feat_dst = self.fc(h_src).view(  # 直接对特征进行丢弃率操作和线性变换，并调整形状为-1行、_num_heads列和_out_feats维度。
                -1, self._num_heads, self._out_feats)
        feat_edge = self.fc_edge(feat[2].unsqueeze(-1))  # 对边特征进行线性变换

        # 计算注意力系数
        el = (feat_src * self.attn_l).sum(dim=-1).unsqueeze(-1)  # 对源节点特征与注意力权重参数逐元素相乘并沿最后一维求和
        er = (feat_dst * self.attn_r).sum(dim=-1).unsqueeze(-1)
        ee = (feat_edge * self.attn_l).sum(dim=-1).unsqueeze(-1)
        el_add_ee = ope_ma_adj_batch[batch_idxes].unsqueeze(-1) * el.unsqueeze(-2) + ee  # unsqueeze 扩展维度
        a = el_add_ee + ope_ma_adj_batch[batch_idxes].unsqueeze(-1) * er.unsqueeze(-3)
        eijk = self.leaky_relu(a)  # 通过Leaky ReLU激活函数
        ekk = self.leaky_relu(er + er)

        # 对注意力参数进行归一化处理
        mask = torch.cat((ope_ma_adj_batch[batch_idxes].unsqueeze(-1) == 1,  # 构造一个掩码(mask)，用于过滤掉无效的注意力系数
                          torch.full(size=(ope_ma_adj_batch[batch_idxes].size(0), 1,
                                           ope_ma_adj_batch[batch_idxes].size(2), 1),
                                     dtype=torch.bool, fill_value=True)), dim=-3)
        e = torch.cat((eijk, ekk.unsqueeze(-3)), dim=-3)  # 将eijk和ekk拼接在一起，并在无效位置上填充负无穷
        e[~mask] = float('-inf')
        alpha = F.softmax(e.squeeze(-1), dim=-2)  # 对e在倒数第二维上进行softmax操作，得到归一化后的注意力系数alpha
        alpha_ijk = alpha[..., :-1, :]  # alpha_ijk表示对应源节点和目标节点之间的注意力系数
        alpha_kk = alpha[..., -1, :].unsqueeze(-2)  # alpha_kk表示对应目标节点自身的注意力系数

        # 计算并返回机器嵌入
        Wmu_ijk = feat_edge + feat_src.unsqueeze(-2)  # 将边特征与源节点特征扩展维度相加，乘以alpha_ijk并求和得到b
        a = Wmu_ijk * alpha_ijk.unsqueeze(-1)
        b = torch.sum(a, dim=-3)
        c = feat_dst * alpha_kk.squeeze().unsqueeze(-1)  # 将目标节点特征与alpha_kk相乘并求和得到c
        nu_k_prime = torch.sigmoid(b + c)  # 将b和c相加，经过sigmoid激活函数
        return nu_k_prime


class MLPsim(nn.Module):
    """
    Part of operation node embedding 生成高质量的节点嵌入  用于计算节点嵌入的多层感知机（MLP）
    """

    def __init__(self,
                 in_feats,  # 输入部分维度
                 out_feats,  # 输出部分维度
                 hidden_dim,  # 隐藏层
                 num_head,
                 feat_drop=0.,
                 attn_drop=0.,
                 negative_slope=0.2,
                 residual=False):

        super(MLPsim, self).__init__()
        self._num_heads = num_head
        self._in_feats = in_feats
        self._out_feats = out_feats

        self.feat_drop = nn.Dropout(feat_drop)
        self.attn_drop = nn.Dropout(attn_drop)
        self.leaky_relu = nn.LeakyReLU(negative_slope)  # LeakyReLU激活函数，引入非线性变换，解决传统ReLU激活函数中的"dead relu"问题。
        self.project = nn.Sequential(  # 通过多个线性变换和ELU激活函数组成的多层感知机层，接收输入特征，经过一系列线性变换和非线性激活后，得到最终的节点嵌入向量
            nn.Linear(self._in_feats, hidden_dim),  # 输入特征维度到隐藏维度的映射
            nn.ELU(),  # 引入非线性，以帮助神经网络模型学习复杂的非线性关系（比 ReLU 函数好一些
            nn.Linear(hidden_dim, hidden_dim),  # 隐藏维度到隐藏维度的映射
            nn.ELU(),
            nn.Linear(hidden_dim, self._out_feats),  # 隐藏维度到输出特征维度的映射
        )

        if residual:
            if self._in_dst_feats != out_feats:
                self.res_fc = nn.Linear(
                    self._in_dst_feats, self._num_heads * out_feats, bias=False)
            else:
                self.res_fc = Identity()
        else:
            self.register_buffer('res_fc', None)

    def forward(self, feat, adj):
        # MLP_{\theta_x}, where x = 1, 2, 3, 4
        # Note that message-passing should along the edge (according to the adjacency matrix)
        a = adj.unsqueeze(-1) * feat.unsqueeze(-3)  # feat与adj分别沿不同的维度进行广播之后，进行逐元素相乘操作，得到a
        b = torch.sum(a, dim=-2)  # 沿倒数第二维求和，得到b
        c = self.project(b)  # 将b经过多层感知机映射得到节点嵌入向量c
        return c
