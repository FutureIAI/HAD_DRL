from gym.envs.registration import register

# 使用 register 函数在 Gym 环境中注册一个新的环境
# https://www.gymlibrary.ml/content/environment_creation/ for reference
register(
    id='fajsp-v0',  # 环境名称 (包括版本号)
    entry_point='solutions.FAJSP_DRL.env:FAJSPEnv',  # 环境类的位置, like 'foldername.filename:classname'
)