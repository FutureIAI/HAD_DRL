# 分配规则
def get_operations_remaining(simulationEnv, operation):
    """用于获取作业中剩余的操作数量"""
    return len([operation for operation in operation.job.operations if
                operation not in simulationEnv.processed_operations])


def get_work_remaining(simulationEnv, operation):
    """用于获取作业中剩余的工作量"""
    operations_remaining = [operation for operation in operation.job.operations if
                            operation not in simulationEnv.processed_operations]
    return sum([sum(operation.processing_times.values()) / len(operation.processing_times) for operation in
                operations_remaining])  # 通过计算未完成操作的平均处理时间来得到剩余工作量


def get_earliest_end_time_machines(simulationEnv, operation):
    """用于获取在将操作调度到各个机器时的最早结束时间"""
    finish_times = {}  # 存储每个机器上操作调度结束的时间
    machine_options = operation.processing_times.keys()  # 获取操作的所有机器选项
    for machine_option in machine_options:
        machine = simulationEnv.JobShop.get_machine(machine_option)
        if machine.scheduled_operations == []:  # 该机器没有已调度的操作，结束时间设置为当前时间加上操作在该机器上的处理时间
            finish_times[machine_option] = simulationEnv.simulator.now + operation.processing_times[machine_option]
        else:  # 若有，将结束时间设置为操作处理时间加上该机器上已处理操作的最大结束时间
            finish_times[machine_option] = operation.processing_times[machine_option] + max(
                [operation['end_time'] for operation in machine._processed_operations])
    earliest_end_time = min(finish_times.values())  # 函数找到字典中的最小值
    return [key for key, value in finish_times.items() if value == earliest_end_time]  # 返回对应的机器选项


def check_precedence_relations(simulationEnv, operation):
    """检查一个操作的所有前置关系是否被满足"""
    for preceding_operation in operation.predecessors:
        if preceding_operation not in simulationEnv.processed_operations:  # 没有在已调度列表中
            return False
    return True
