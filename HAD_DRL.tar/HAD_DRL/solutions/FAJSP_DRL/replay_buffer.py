import torch
import numpy as np
import random
from collections import deque


class ReplayBuffer(object):
    def __init__(self, args):
        self.batch_size = args["batch_size"]
        self.buffer_capacity = args["buffer_capacity"]
        self.current_size = 0
        self.memory = Memory(args)
        self.memory_counter = 0

    def store_transition(self, state, action, reward, next_state):
        self.memory.remember((state, action, reward, next_state))
        self.memory_counter += 1

    def sample(self, total_steps):
        batch = self.memory.sample(total_steps)
        return batch

class Memory(object):
    def __init__(self, args):
        self.capacity = args["buffer_capacity"]
        self.memory = deque(maxlen=self.capacity)  # 创建一个deque容器对象，用于存储记忆数据

    def remember(self, sample):  # 将一个记忆样本数据sample添加到记忆存储器中，即将其追加到self.memory中
        self.memory.append(sample)

    def sample(self, n):  # 从记忆存储器中随机采样n个样本
        n = min(n, len(self.memory))
        index = np.random.randint(1, n + 1)
        sample_batch = random.sample(self.memory, index)  # 从self.memory中随机选择n个样本
        return sample_batch  # 返回列表作为采样批次