import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn.parameter import Parameter
import math


class DuelingNet(nn.Module):  # DuelingNet网络模型，将动作值函数分解为状态值函数和优势函数
    def __init__(self, args):
        super(DuelingNet, self).__init__()
        self.fc1 = nn.Linear(args["state_dim"], args["hidden_dim"])  # 定义一个神经网络的线性层，前输入个数，后输出个数
        self.fc2 = nn.Linear(args["hidden_dim"], args["hidden_dim"])
        self.V = nn.Linear(args["hidden_dim"], 1)  # 估计状态值函数
        self.A = nn.Linear(args["hidden_dim"], args["action_dim"])  # 估计优势函数

    def forward(self, s):
        s = s.view(-1, 20)
        s = torch.relu(self.fc1(s))  # 激活函数
        s = torch.relu(self.fc2(s))
        V = self.V(s)  # [batch_size, 1] 通过状态值线性层计算状态值函数的估计值
        A = self.A(s)  # [batch_size, action_dim] 通过优势线性层计算优势函数的估计值
        Q = V + (A - torch.mean(A, dim=-1, keepdim=True))  # Q(s,a)=V(s)+A(s,a)-mean(A(s,a))平均值
        return Q


class Net(nn.Module):  # 普通网络模型
    def __init__(self, args):
        super(Net, self).__init__()
        self.fc1 = Linear(args["state_dim"], args["hidden_dim"])
        self.fc2 = Linear(args["hidden_dim"], args["hidden_dim"])
        self.fc3 = Linear(args["hidden_dim"], args["action_dim"])

    def forward(self, s):
        s = torch.relu(self.fc1(s))
        s = torch.relu(self.fc2(s))
        Q = self.fc3(s)  # [batch_size, action_dim]
        Q = torch.mean(Q, dim=0)  # 计算均值并保持维度
        return Q


class CNN_FNN(nn.Module):  # 表示一个卷积神经网络和全连接神经网络的结合模型
    def __init__(self, args):
        super(CNN_FNN, self).__init__()
        self.conv1 = nn.Sequential(  # 定义了一个卷积层self.conv1
            nn.Conv2d(  # 输入通道数为1，输出通道数为6，卷积核大小为3，步长为1，填充为1
                in_channels=2,
                out_channels=6,
                kernel_size=3,
                stride=1,
                padding=1,  # 使得出来的图片大小不变P=（3 - 1）/ 2,
            ),
            nn.ReLU(),  # 通过ReLU激活函数和最大池化操作后
            nn.MaxPool2d(kernel_size=2, ceil_mode=False)
        )
        # summary(self.conv1, (3,6,6)) 定义了三个全连接层：self.fc1、self.fc2和self.out
        self.fc1 = nn.Linear(6 * int(args["ope_max"] / 2) * int(args["num_mas"] / 2), args["hidden_dim"])
        self.fc2 = nn.Linear(args["hidden_dim"], args["hidden_dim"])
        self.out = nn.Linear(args["hidden_dim"], 2)

    def forward(self, x):  # 前向传播方法forward
        x = self.conv1(x)  # 输入x通过卷积层self.conv1进行卷积操作
        x = x.view(x.size(0), -1)  # 通过.view(x.size(0), -1)将卷积结果展平成一维张量
        x = self.fc1(x)  # 将展平的结果输入到全连接层self.fc1中，并经过ReLU激活函数处理
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        action_prob = self.out(x)  # 结果输入到全连接层self.out中，得到最终的输出action_prob
        # action_prob = torch.tanh(self.out(x))  # 是否限制[-1,1]
        return action_prob


class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 自适应平均池化层
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),  # 将输入通道数降低为原来的 1/reduction
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),  # 将通道数恢复到原来的大小
            nn.Sigmoid()  # 将输出的注意力权重限制在0到1之间
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class Linear(nn.Module):
    r"""Applies a linear transformation to the incoming data: :math:`y = xA^T + b`

    This module supports :ref:`TensorFloat32<tf32_on_ampere>`.

    On certain ROCm devices, when using float16 inputs this module will use :ref:`different precision<fp16_on_mi200>` for backward.

    Args:
        in_features: size of each input sample
        out_features: size of each output sample
        bias: If set to ``False``, the layer will not learn an additive bias.
            Default: ``True``

    Shape:
        - Input: :math:`(*, H_{in})` where :math:`*` means any number of
          dimensions including none and :math:`H_{in} = \text{in\_features}`.
        - Output: :math:`(*, H_{out})` where all but the last dimension
          are the same shape as the input and :math:`H_{out} = \text{out\_features}`.

    Attributes:
        weight: the learnable weights of the module of shape
            :math:`(\text{out\_features}, \text{in\_features})`. The values are
            initialized from :math:`\mathcal{U}(-\sqrt{k}, \sqrt{k})`, where
            :math:`k = \frac{1}{\text{in\_features}}`
        bias:   the learnable bias of the module of shape :math:`(\text{out\_features})`.
                If :attr:`bias` is ``True``, the values are initialized from
                :math:`\mathcal{U}(-\sqrt{k}, \sqrt{k})` where
                :math:`k = \frac{1}{\text{in\_features}}`

    Examples::

        >>> m = nn.Linear(20, 30)
        >>> input = torch.randn(128, 20)
        >>> output = m(input)
        >>> print(output.size())
        torch.Size([128, 30])
    """
    __constants__ = ['in_features', 'out_features']
    in_features: int
    out_features: int
    weight: Tensor

    def __init__(self, in_features: int, out_features: int, bias: bool = True,
                 device=None, dtype=None) -> None:
        factory_kwargs = {'device': device, 'dtype': dtype}
        super(Linear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.empty((out_features, in_features), **factory_kwargs))
        if bias:
            self.bias = Parameter(torch.empty(out_features, **factory_kwargs))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        # Setting a=sqrt(5) in kaiming_uniform is the same as initializing with
        # uniform(-1/sqrt(in_features), 1/sqrt(in_features)). For details, see
        # https://github.com/pytorch/pytorch/issues/57109
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))  # 对张量进行 Kaiming 均匀分布初始化
        if self.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, input: Tensor) -> Tensor:
        return F.linear(input, self.weight, self.bias)

    def extra_repr(self) -> str:
        return 'in_features={}, out_features={}, bias={}'.format(
            self.in_features, self.out_features, self.bias is not None
        )