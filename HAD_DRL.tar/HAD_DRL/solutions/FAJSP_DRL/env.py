# GITHUB REPO: https://github.com/songwenas12/fjsp-drl

import random
import sys
import copy

import gym
import torch
import torch.nn as nn
import numpy as np
from pathlib import Path
from dataclasses import dataclass

from solutions.FAJSP_DRL.load_data import load_fajs, nums_detec, load_fajs_case, add_fajs
from scheduling_environment.jobShop import JobShop
from scheduling_environment.job import Job
from scheduling_environment.machine import Machine
from scheduling_environment.operation import Operation
from solutions.FAJSP_DRL.reward import Features, Immediate_reward, Cumulative_reward


# 将基本路径（base path）添加到 Python 模块搜索路径中
base_path = Path(__file__).resolve().parents[2]
sys.path.append(str(base_path))


@dataclass
class EnvState:
    """环境状态的类"""
    # 状态
    opes_appertain_batch: torch.Tensor = None  # 属于每个操作的批次。表示是一个张量
    ope_pre_adj_batch: torch.Tensor = None  # 操作之间的先前调整关系
    ope_sub_adj_batch: torch.Tensor = None  # 操作之间的后续调整关系
    reward: torch.tensor = None

    num_ope_biases_batch: torch.Tensor  = None
    end_ope_biases_batch: torch.Tensor = None  # 每个结束操作的偏差
    nums_opes_batch: torch.Tensor = None  # 每个批次的操作数量
    pre_opes: torch.Tensor = None
    wor_ma_first_batch: torch.Tensor = None
    wor_ma_end_batch: torch.Tensor = None
    ma_power_batch: torch.Tensor = None

    # 动态
    batch_idxes: torch.Tensor = None  # 批次的索引
    feat_opes_batch: torch.Tensor = None  # 批次中操作的特征
    feat_mas_batch: torch.Tensor = None  # 批次中机器的特征
    proc_times_batch: torch.Tensor = None  # 批次中操作的处理时间
    proc_power_batch: torch.Tensor = None
    ope_ma_adj_batch: torch.Tensor = None  # 操作之间的机器调整关系
    time_batch: torch.Tensor = None  # 批次中的时间
    schedule_ope: torch.Tensor = None
    schedule_job: torch.Tensor = None
    ope_pre_num: torch.Tensor = None
    wo_ma_T: torch.Tensor = None
    wo_ma_time: torch.Tensor = None
    wo_ma_kt: torch.Tensor = None
    ma_idlepower: torch.Tensor = None
    ma_opepower: torch.Tensor = None
    reward_batch: torch.Tensor = None
    feature: torch.Tensor = None

    mask_job_procing_batch: torch.Tensor = None  # 正在处理作业的掩码
    mask_job_finish_batch: torch.Tensor = None  # 已完成作业的掩码
    mask_ma_procing_batch: torch.Tensor = None  # 正在处理主机的掩码
    mask_wo_procing_batch: torch.Tensor = None
    ope_step_batch: torch.Tensor = None  # 操作步骤的批次

    def update(self, batch_idxes, feat_opes_batch, feat_mas_batch, proc_times_batch, proc_power_batch,
               ope_ma_adj_batch, ope_pre_adj_batch, ope_sub_adj_batch,
               opes_appertain_batch, num_ope_biases_batch, end_ope_biases_batch, nums_opes,
               mask_job_procing_batch, mask_job_finish_batch, mask_ma_procing_batch, mask_wo_procing_batch,
               ope_step_batch, time, schedule_ope, schedule_job, ope_pre_num, pre_opes, feature, reward_batch, reward):
        self.batch_idxes = batch_idxes
        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch
        self.proc_times_batch = proc_times_batch
        self.proc_power_batch = proc_power_batch
        self.ope_ma_adj_batch = ope_ma_adj_batch
        self.ope_pre_adj_batch = ope_pre_adj_batch
        self.ope_sub_adj_batch = ope_sub_adj_batch
        self.opes_appertain_batch = opes_appertain_batch
        self.num_ope_biases_batch = num_ope_biases_batch
        self.end_ope_biases_batch = end_ope_biases_batch
        self.schedule_ope = schedule_ope
        self.schedule_job = schedule_job
        self.ope_pre_num = ope_pre_num
        self.pre_opes = pre_opes
        self.feature = feature

        self.mask_job_procing_batch = mask_job_procing_batch
        self.mask_job_finish_batch = mask_job_finish_batch
        self.mask_ma_procing_batch = mask_ma_procing_batch
        self.mask_wo_procing_batch = mask_wo_procing_batch
        self.ope_step_batch = ope_step_batch
        self.time_batch = time
        self.nums_opes_batch = nums_opes
        self.reward_batch = reward_batch
        self.reward = reward


def convert_feat_job_2_ope(feat_job_batch, opes_appertain_batch):
    """
    作业特征转化为操作特征 (such as dimension)
    """
    return feat_job_batch.gather(1, opes_appertain_batch)  # 将每个操作对应的作业特征组合成一个操作特征


class FAJSPEnv(gym.Env):
    """
    FAJSP 环境
    """
    def __init__(self, case, env_paras, data_source='file'):
        """
        :param case: 实例生成器或实例的地址
        :param env_paras: 包含了环境参数的字典
        :param data_source: 指示实例是来自生成器还是文件
        """

        # 加载参数
        # 静态
        self.show_mode = env_paras["show_mode"]  # 结果显示模式(deprecated in the final experiment)
        self.batch_size = env_paras["batch_size"]  # 训练期间并行处理的作业数量
        self.num_opes = env_paras["num_opes"]
        self.num_relas = env_paras["num_relas"]
        self.num_mas = env_paras["num_mas"]
        self.num_wos = env_paras["num_wos"]
        self.paras = env_paras
        self.device = env_paras["device"]
        # 加载实例
        num_data = 13  # 从实例中提取的数据量
        tensors = [[] for _ in range(num_data)]  # 存储从实例中提取的数据的列表
        self.simulation_envs: list[JobShop] = []  # 跟踪调度环境实例的变量列表
        self.num_jobs = 0
        lines = []  # 存储实例数据的列表
        self.data_source = data_source

        if data_source == 'case':  # 通过生成器产生实例
            for i in range(self.batch_size):
                lines.append(case.get_case(i)[0])  # 生成一个实例并保存
                num_jobs, num_mas, num_opes = nums_detec(lines[i])  # 解析实例数据
                self.num_opes = max(self.num_opes, num_opes)  # 记录在平行实例中的操作最大数
        else:  # 从文件下载实例
            for i in range(self.batch_size):
                with open(case[i]) as file_object:
                    line = file_object.readlines()
                    lines.append(line)
                num_mas, num_opes, num_relas, num_wos = nums_detec(line)
        # 加载特征
        for i in range(self.batch_size):
            if data_source == 'case':
                load_data = load_fajs_case(lines[i], self.num_mas, self.num_opes)
            else:
                load_data, env = load_fajs(case[i], self.num_mas, self.num_opes, self.num_wos)
                num_jobs = env.nr_of_jobs
                self.num_jobs = max(num_jobs, self.num_jobs)
                self.pre_opes = env.precedence_relations_jobs
                self.simulation_envs.append(env)
            for j in range(num_data):
                tensors[j].append(load_data[j].to(self.device))  # tensors列表中将包含所有实例的特征数据

        # 动态特征
        # shape: (batch_size, num_opes, num_mas)，运行时间
        self.proc_times_batch = torch.stack(tensors[0], dim=0)
        # shape: (batch_size, num_opes, num_mas)，操作—机器
        self.ope_ma_adj_batch = torch.stack(tensors[1], dim=0).long()
        # shape: (batch_size, num_opes, num_opes), 计算累积量所需的邻接矩阵
        self.cal_cumul_adj_batch = torch.stack(tensors[7], dim=0).float()
        # shape: (batch_size, num_wos, num_mas)，工人的初始能力
        self.wor_ma_first_batch = torch.stack(tensors[8], dim=0).float()
        # shape: (batch_size, num_wos, num_mas)，工人最大学习率
        self.wor_ma_end_batch = torch.stack(tensors[9], dim=0).float()
        # shape: (batch_size, num_opes, num_mas)，加工功率
        self.proc_power_batch = torch.stack(tensors[10], dim=0).float()

        # 静态特征
        # shape: (batch_size, num_opes, num_opes)
        self.ope_pre_adj_batch = torch.stack(tensors[2], dim=0)  # 前驱
        # shape: (batch_size, num_opes, num_opes)
        self.ope_sub_adj_batch = torch.stack(tensors[3], dim=0)  # 后继
        # shape: (batch_size, num_opes), 作业和操作的映射关系
        self.opes_appertain_batch = torch.stack(tensors[4], dim=0).long()
        # shape: (batch_size, num_jobs), 每个作业第一个操作的ID
        self.num_ope_biases_batch = torch.stack(tensors[5], dim=0).long()
        # shape: (batch_size, num_jobs), 每个作业的操作数
        self.nums_ope_batch = torch.stack(tensors[6], dim=0).long()
        # shape: (batch_size, num_jobs), 每个作业最后一个操作的ID
        self.end_ope_biases_batch = self.num_ope_biases_batch + self.nums_ope_batch - 1
        # shape: (batch_size), 每个实例的操作数
        self.nums_opes = torch.sum(self.nums_ope_batch, dim=1)
        # shape: (batch_size, num_mas)，待机功率
        self.ma_idlepower_batch = torch.stack(tensors[11], dim=0).float()
        # shape：(batch_size, num_mas)，运行功率
        self.ma_opepower_batch = torch.stack(tensors[12], dim=0).float()

        # 动态变量
        self.batch_idxes = torch.arange(self.batch_size)  # 还未完成的实例索引
        self.time = torch.zeros(self.batch_size)  # 每个实例的当前时间
        self.N = torch.zeros(self.batch_size).int()  # 已经调度的操作数量
        self.pre_mas = torch.full(size=(self.batch_size, self.num_wos), dtype=torch.long, fill_value=-1)
        # shape: (batch_size, num_jobs), 每个作业中下一个待处理的操作的ID
        self.ope_step_batch = copy.deepcopy(self.num_ope_biases_batch)
        '''
        features, dynamic
            ope:
                Status
                Number of neighboring machines
                Processing time
                Number of unscheduled operations in the job
                Job completion time
                Start time
            ma:
                Number of neighboring operations
                Available time
                Utilization
        '''
        self.schedule_ope = torch.full(size=(self.batch_size, num_opes), dtype=torch.bool, fill_value=False)
        self.schedule_job = torch.full(size=(self.batch_size, num_jobs), dtype=torch.bool, fill_value=False)
        self.ope_pre_num = torch.sum(self.ope_pre_adj_batch, dim=1)
        for i in range(self.num_opes):
            zero_mask = torch.eq(self.ope_pre_num[:, i], 0)
            self.schedule_ope[:, i] = zero_mask  # ope是否可调度
        for ba in range(self.batch_size):
            for i in range(self.num_opes):
                if self.schedule_ope[ba, i]:
                    self.schedule_job[ba, self.opes_appertain_batch[ba, i]] = True  # 有一个ope可操作所在job就设置为true

        # 生成原始特征向量
        feat_opes_batch = torch.zeros(size=(self.batch_size, self.paras["ope_feat_dim"], self.num_opes))  # 存储操作特征向量
        feat_mas_batch = torch.zeros(size=(self.batch_size, self.paras["ma_feat_dim"], num_mas))  # 存储机器的特征向量

        # a = torch.zeros(size=(self.batch_size, self.num_opes))
        # a = torch.count_nonzero(self.ope_ma_adj_batch, dim=2)
        feat_opes_batch[:, 1, :] = torch.count_nonzero(self.ope_ma_adj_batch, dim=2)  # 每个操作的邻居机器的数量
        feat_opes_batch[:, 2, :] = torch.sum(self.proc_times_batch, dim=2).div(feat_opes_batch[:, 1, :] + 1e-9)  # 每个操作的平均处理时间
        feat_opes_batch[:, 3, :] = convert_feat_job_2_ope(self.nums_ope_batch, self.opes_appertain_batch)  # 每个操作所属作业中未调度操作的数量
        feat_opes_batch[:, 5, :] = torch.bmm(feat_opes_batch[:, 2, :].unsqueeze(1), self.cal_cumul_adj_batch).squeeze()  # 每个操作的完成时间
        end_time_batch = (feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]).gather(1, self.end_ope_biases_batch)  # 完成时间通过累积前面所有操作的处理时间和路径上较长完成时间来计算
        feat_opes_batch[:, 4, :] = convert_feat_job_2_ope(end_time_batch, self.opes_appertain_batch)  # 每个作业最后一个操作的完成时间

        self.except_makspan = torch.zeros(size=(self.batch_size, 2, self.num_opes))
        for ope in range(self.num_opes):
            if self.ope_pre_num[:, ope] == 1:  # 工件中间工序（前驱数为1）
                for i in range(self.num_opes):
                    if self.ope_sub_adj_batch[:, ope, i]:
                        self.except_makspan[:, 0, ope] = self.except_makspan[:, 1, i]  # 开始时间
                        self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + feat_opes_batch[:, 2, ope]  # 完成时间
            elif self.ope_pre_num[:, ope] > 1:  # 前驱数大于1
                maxnum = torch.zeros(size=(self.batch_size, self.num_opes))
                for i in range(self.num_opes):
                    if self.ope_sub_adj_batch[:, ope, i]:
                        maxnum[:, i] = self.except_makspan[:, 1, i]
                self.except_makspan[:, 0, ope] = torch.max(maxnum)
                self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + feat_opes_batch[:, 2, ope]
            else:  # 工件第一个工序
                self.except_makspan[:, 0, ope] = 0
                self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + feat_opes_batch[:, 2, ope]
        # feat_opes_batch[:, 4, :] = convert_feat_job_2_ope(end_time_batch, self.opes_appertain_batch)  # 每个作业最后一个操作的完成时间

        feat_mas_batch[:, 0, :] = torch.count_nonzero(self.ope_ma_adj_batch, dim=1)  # 每个机器的邻居操作数量

        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch

        # 当前状态、动态的掩码
        # shape: (batch_size, num_jobs), 正在执行的作业
        self.mask_job_procing_batch = torch.full(size=(self.batch_size, num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_jobs), 已经完成的作业
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_mas), 正在执行的机器
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, num_mas), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_wos)，正在执行的人员
        self.mask_wo_procing_batch = torch.full(size=(self.batch_size, num_wos), dtype=torch.bool, fill_value=False)

        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 5))
        self.schedules_batch[:, :, 3] = feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]  # 结束时间

        self.machines_batch = torch.zeros(size=(self.batch_size, self.num_mas, 5))
        self.machines_batch[:, :, 0] = torch.ones(size=(self.batch_size, self.num_mas))  # 将第三个维度的第一个元素初始化为1，表示机器为活动状态

        self.wo_ma_T = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))
        self.wo_ma_time = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))
        self.wo_ma_kt = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))

        self.ma_power = torch.zeros(size=(self.batch_size, self.num_mas, 2))
        self.ma_power[:, :, 0] = self.ma_idlepower_batch
        self.ma_power[:, :, 1] = self.ma_opepower_batch

        self.feature = torch.zeros(size=(self.batch_size, 4))
        self.reward_batch = torch.zeros(size=(self.batch_size, self.num_opes + 1, 4))  # 0except,1energy,2EI,3reward,4makespan
        self.reward_batch[:, self.N.item(), 0] = torch.max(self.except_makspan[:, 1, :], dim=1)[0]  # shape: (batch_size, num_opes) 工作批次的完成时间
        self.reward = torch.zeros(self.batch_size).int()
        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # shape: (batch_size) 工作批次的完成状态

        self.state = EnvState(batch_idxes=self.batch_idxes,
                              feat_opes_batch=self.feat_opes_batch, feat_mas_batch=self.feat_mas_batch,
                              proc_times_batch=self.proc_times_batch, proc_power_batch=self.proc_power_batch,
                              ope_ma_adj_batch=self.ope_ma_adj_batch,
                              ope_pre_adj_batch=self.ope_pre_adj_batch, ope_sub_adj_batch=self.ope_sub_adj_batch,
                              num_ope_biases_batch=self.num_ope_biases_batch,
                              end_ope_biases_batch=self.end_ope_biases_batch,
                              mask_job_procing_batch=self.mask_job_procing_batch,
                              mask_job_finish_batch=self.mask_job_finish_batch,
                              mask_ma_procing_batch=self.mask_ma_procing_batch,
                              mask_wo_procing_batch=self.mask_wo_procing_batch,
                              schedule_ope=self.schedule_ope, schedule_job=self.schedule_job,
                              ope_pre_num=self.ope_pre_num, pre_opes=self.pre_opes,
                              opes_appertain_batch=self.opes_appertain_batch,
                              ope_step_batch=self.ope_step_batch, time_batch=self.time,
                              nums_opes_batch=self.nums_opes, feature=self.feature,
                              reward_batch=self.reward_batch, reward=self.reward)

        # 在重置环境时保存初始状态的数据
        self.old_num_opes = copy.deepcopy(self.num_opes)
        self.old_num_jobs = copy.deepcopy(self.num_jobs)
        self.old_proc_times_batch = copy.deepcopy(self.proc_times_batch)
        self.old_proc_power_batch = copy.deepcopy(self.proc_power_batch)
        self.old_ope_ma_adj_batch = copy.deepcopy(self.ope_ma_adj_batch)
        self.old_cal_cumul_adj_batch = copy.deepcopy(self.cal_cumul_adj_batch)
        self.old_end_ope_biases_batch = copy.deepcopy(self.end_ope_biases_batch)
        self.old_opes_appertain_batch = copy.deepcopy(self.opes_appertain_batch)
        self.old_ope_step_batch = copy.deepcopy(self.ope_step_batch)
        self.old_feat_opes_batch = copy.deepcopy(self.feat_opes_batch)
        self.old_feat_mas_batch = copy.deepcopy(self.feat_mas_batch)
        self.old_schedule_ope = copy.deepcopy(self.schedule_ope)
        self.old_schedule_job = copy.deepcopy(self.schedule_job)
        self.old_ope_pre_num = copy.deepcopy(self.ope_pre_num)
        self.old_except_makespan = copy.deepcopy(self.except_makspan)
        self.old_pre_opes = copy.deepcopy(self.pre_opes)
        self.old_ope_pre_adj_batch = copy.deepcopy(self.ope_pre_adj_batch)
        self.old_ope_sub_adj_batch = copy.deepcopy(self.ope_sub_adj_batch)
        self.old_num_ope_biases_batch = copy.deepcopy(self.num_ope_biases_batch)
        self.old_nums_ope_batch = copy.deepcopy(self.nums_ope_batch)
        self.old_nums_opes = copy.deepcopy(self.nums_opes)
        self.old_state = copy.deepcopy(self.state)

    def step(self, actions, weight):
        """
        执行一步模拟环境的转换
        """
        opes = actions[0, :]
        mas = actions[1, :]
        jobs = actions[2, :]
        # print(actions)
        self.N += 1  # 记录环境转换的步数

        wo, proc_times = self.SPT(actions)
        # print(proc_times)
        self.pre_mas[:, wo] = mas  # 设置上一个工人使用的机器
        self.wo_ma_T[:, wo, mas] += 1  # 使用次数加1
        self.wo_ma_time[:, wo, mas] += proc_times  # 累积工作时间
        self.wo_ma_kt[:, wo, mas] = proc_times + self.time  # 总体时间轴
        self.mask_wo_procing_batch[self.batch_idxes, wo] = True

        # 未选中的操作-机器弧移除
        remain_ope_ma_adj = torch.zeros(size=(self.batch_size, self.num_mas), dtype=torch.int64)
        remain_ope_ma_adj[self.batch_idxes, mas] = 1
        self.ope_ma_adj_batch[self.batch_idxes, opes] = remain_ope_ma_adj[self.batch_idxes, :]
        time_ope = self.proc_times_batch[:, opes, :]
        self.proc_times_batch *= self.ope_ma_adj_batch  # 通过乘法运算更新了操作处理时间批次数据
        self.proc_times_batch[:, opes, mas] = proc_times
        self.proc_power_batch += self.ope_ma_adj_batch

        # 更新操作的特征信息和累计处理时间
        self.feat_opes_batch[self.batch_idxes, :3, opes] = torch.stack(
            (torch.ones(self.batch_idxes.size(0), dtype=torch.float),
             torch.ones(self.batch_idxes.size(0), dtype=torch.float), proc_times), dim=1)
        last_opes = torch.where(opes - 1 < self.num_ope_biases_batch[self.batch_idxes, jobs], self.num_opes - 1, opes - 1)
        self.cal_cumul_adj_batch[self.batch_idxes, last_opes, :] = 0  # 将这些操作之后的累计处理时间重置为0

        for i in range(self.num_opes):
            if self.ope_pre_adj_batch[:, opes, i]:
                self.ope_pre_num[:, i] -= 1

        # 更新作业中未调度操作的数量
        start_ope = self.num_ope_biases_batch[self.batch_idxes, jobs]
        end_ope = self.end_ope_biases_batch[self.batch_idxes, jobs]
        for i in range(self.batch_idxes.size(0)):
            self.feat_opes_batch[self.batch_idxes[i], 3, start_ope[i]:end_ope[i] + 1] -= 1  # 在起始操作到终止操作范围内的元素都减1

        # Update '开始时间' and '作业完成时间'
        self.feat_opes_batch[self.batch_idxes, 5, opes] = self.time[self.batch_idxes]  # 工人最早开始时间
        is_scheduled = self.feat_opes_batch[self.batch_idxes, 0, :]
        mean_proc_time = self.feat_opes_batch[self.batch_idxes, 2, :]
        start_times = self.feat_opes_batch[self.batch_idxes, 5, :] * is_scheduled
        if self.pre_opes[jobs.item()] != []:
            for i in range(len(self.pre_opes[jobs.item()])):
                start_times = torch.max(start_times, (self.schedules_batch[
                    self.batch_idxes, self.end_ope_biases_batch[:, self.pre_opes[jobs.item()][i]], 3]) * is_scheduled)  # 已调度操作的实际开始时间
        un_scheduled = 1 - is_scheduled  # unscheduled opes 未调度
        estimate_times = torch.bmm((start_times + mean_proc_time).unsqueeze(1),
                                   self.cal_cumul_adj_batch[self.batch_idxes, :, :]).squeeze() * un_scheduled  # 估计的未调度操作的开始时间
        self.feat_opes_batch[self.batch_idxes, 5, :] = start_times + estimate_times  # 更新为实际开始时间与估计开始时间之和
        end_time_batch = (self.feat_opes_batch[self.batch_idxes, 5, :] +  # 计算操作的结束时间
                          self.feat_opes_batch[self.batch_idxes, 2, :]).gather(1, self.end_ope_biases_batch[self.batch_idxes, :])
        self.feat_opes_batch[self.batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch, self.opes_appertain_batch[
                                                                                              self.batch_idxes, :])

        # 更新部分调度（状态）
        self.schedules_batch[self.batch_idxes, opes, :2] = torch.stack((torch.ones(self.batch_idxes.size(0)), mas),
                                                                       dim=1)  # 表示该操作已经被调度
        self.schedules_batch[self.batch_idxes, opes, 2] = start_times[self.batch_idxes, opes]  # 实际开始时间
        self.schedules_batch[self.batch_idxes, opes, 3] = start_times[self.batch_idxes, opes] + proc_times  # 实际结束时间
        self.schedules_batch[self.batch_idxes, opes, 4] = wo
        self.machines_batch[self.batch_idxes, mas, 0] = torch.zeros(self.batch_idxes.size(0))  # 该机器当前没有任务在执行
        last_time = self.machines_batch[self.batch_idxes, mas, 1]
        self.machines_batch[self.batch_idxes, mas, 1] = start_times[self.batch_idxes, opes] + proc_times  # 机器的下一次空闲时间
        self.machines_batch[self.batch_idxes, mas, 2] += proc_times  # 机器已经累计处理的时间
        self.machines_batch[self.batch_idxes, mas, 3] = jobs.float()  # 机器当前执行的作业号
        self.machines_batch[self.batch_idxes, mas, 4] = wo

        # 更新机器的特征向量
        self.feat_mas_batch[self.batch_idxes, 0, :] = torch.count_nonzero(self.ope_ma_adj_batch[self.batch_idxes, :, :], dim=1).float()  # 计算每台机器当前正在执行的操作数量
        self.feat_mas_batch[self.batch_idxes, 1, mas] = start_times[self.batch_idxes, opes] + proc_times
        utiliz = self.machines_batch[self.batch_idxes, :, 2]  # 机器状态中的已使用时间
        cur_time = start_times[self.batch_idxes, opes].expand_as(utiliz)  # 当前时间
        utiliz = torch.minimum(utiliz, cur_time)
        utiliz = utiliz.div(start_times[self.batch_idxes, opes] + 1e-9)  # 归一化为累计使用时间与总可用时间之比
        self.feat_mas_batch[self.batch_idxes, 2, :] = utiliz

        # 根据动作更新其他变量
        self.ope_step_batch[self.batch_idxes, jobs] += 1  # 操作+1
        self.mask_job_procing_batch[self.batch_idxes, jobs] = True  # 正在执行
        self.mask_ma_procing_batch[self.batch_idxes, mas] = True
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1,
                                                 True, self.mask_job_finish_batch)  # 操作的步数等于其预期步数，操作已完成
        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # 每个批次中的所有作业是否都完成了
        self.done = self.done_batch.all()  # 整个作业是否都完成了

        if (np.random.poisson(self.paras["lambda"]) >= 1) & (self.num_opes < self.paras["num_max"]):
            self.add_job()
        # if self.N == self.paras["probability"]:
        #     self.add_job()

        start_time = torch.zeros(size=(self.batch_size, self.num_opes))
        # 检查是否还有待处理的操作-机器对, 如果没有，则环境将转移到下一个时间步
        flag_trans_2_next_time = self.if_no_eligible()  # 检查是否存在仍未分配的操作-机器对
        # print(flag_trans_2_next_time)
        while (flag_trans_2_next_time == 0):  # 还有作业没有完成时(when =0)
            self.next_time(flag_trans_2_next_time)  # 将环境转移到下一个时间步
            flag_trans_2_next_time = self.if_no_eligible()  # 更新flag_trans_2_next_time矩阵
            if self.done_batch.all():
                break

        # un_scheduled = 1 - is_scheduled  # unscheduled opes 未调度
        # estimate_times = torch.bmm((start_time + mean_proc_time).unsqueeze(1),self.cal_cumul_adj_batch[self.batch_idxes, :, :]).squeeze() * un_scheduled  # 估计的未调度操作的开始时间

        is_schedul = self.feat_opes_batch[self.batch_idxes, 0, :]
        m_proc_time = self.feat_opes_batch[self.batch_idxes, 2, :]
        for i in range(self.num_opes):
            if (is_schedul[:, i] != 1) and (self.ope_pre_num[:, i] == 0):
                start_time[:, i] += self.time  # 能调度的工序
        for ope in range(self.num_opes):
            if self.schedules_batch[:, ope, 0] == 1:  # 已调度
                self.except_makspan[:, 0, ope] = self.schedules_batch[:, ope, 2]  # 开始时间
                self.except_makspan[:, 1, ope] = self.schedules_batch[:, ope, 3]  # 结束时间
            else:  # 未调度
                if self.ope_pre_num[:, ope] == 1:  # 工件中间工序（前驱数为1）
                    for i in range(self.num_opes):
                        if self.ope_sub_adj_batch[:, ope, i]:
                            self.except_makspan[:, 0, ope] = torch.max(self.except_makspan[:, 1, i], start_time[:, ope])
                            self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + m_proc_time[:, ope]
                elif self.ope_pre_num[:, ope] > 1:  # 前驱数大于1
                    maxnum = torch.zeros(size=(self.batch_size, self.num_opes))
                    for i in range(self.num_opes):
                        if self.ope_sub_adj_batch[:, ope, i]:
                            maxnum[:, i] = self.except_makspan[:, 1, i]
                    self.except_makspan[:, 0, ope] = torch.max(torch.max(maxnum), start_time[:, ope])
                    self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + m_proc_time[:, ope]
                else:  # 工件第一个工序
                    self.except_makspan[:, 0, ope] = start_time[:, ope]
                    self.except_makspan[:, 1, ope] = self.except_makspan[:, 0, ope] + m_proc_time[:, ope]
        # self.feat_opes_batch[self.batch_idxes, 5, :] = start_time + estimate_times
        # end_time_batch = (self.feat_opes_batch[self.batch_idxes, 5, :] + self.feat_opes_batch[self.batch_idxes, 2, :]).gather(1, self.end_ope_biases_batch[self.batch_idxes, :])
        # self.feat_opes_batch[:, 4, :] = self.feat_opes_batch[:, 5, :] + self.feat_opes_batch[:, 2, :]
        # self.feat_opes_batch[self.batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch, self.opes_appertain_batch[self.batch_idxes, :])

        # 奖励，任务完成时间减去每个操作的剩余步数，这一步总耗能耗，用DQN概率当作权重
        times = torch.max(self.except_makspan[:, 1, :], dim=1)[0]
        # print(times)
        n = self.N[self.batch_idxes].item()
        ma_ave_uti, ma_ave_uti_a, _, TE_ij, EI, TE_mid = Features(self, n, opes, mas, last_time, start_times[self.batch_idxes, opes], time_ope)
        self.reward_batch[:, n, 2] = TE_ij  # 能耗指标
        r_t = Immediate_reward(self, n, ma_ave_uti, ma_ave_uti_a, EI, TE_ij, TE_mid, self.reward_batch[:, n - 1, 0], times, proc_times, mean_proc_time[:, opes], weight)
        #reward = Cumulative_reward(self.reward_batch[:, n - 1, 0], self.reward_batch[:, n - 1, 2], times, TE_ij)
        self.reward_batch[:, n, 3] = r_t  # 即时奖励
        # self.reward_batch[:, n] = weight[0] * (self.makespan_batch[:, n - 1] - times) + weight[1] * (power - self.totalpower_batch[:, n - 1])
        self.reward_batch[:, n, 0] = times  # 预计完成时间
        self.reward_batch[:, n, 1] = self.reward_batch[:, n - 1, 1] + TE_ij  # 总能耗
        self.reward = self.reward_batch[:, n, 3]
        # print(self.reward)
        self.feature[:, 0] = ma_ave_uti
        self.feature[:, 1] = ma_ave_uti_a
        self.feature[:, 3] = EI

        # 更新未完成实例的向量
        # mask_finish = (self.N + 1) <= self.nums_opes  # >= 表示已完成，mask_finash 为 true
        # if ~(mask_finish.all()):
        #     self.batch_idxes = torch.arange(self.batch_size)[mask_finish]  # 生成一个新的批次索引向量

        # 更新环境的状态
        self.state.update(self.batch_idxes, self.feat_opes_batch, self.feat_mas_batch,
                          self.proc_times_batch, self.proc_power_batch,
                          self.ope_ma_adj_batch, self.ope_pre_adj_batch, self.ope_sub_adj_batch,
                          self.opes_appertain_batch, self.num_ope_biases_batch, self.end_ope_biases_batch, self.nums_opes,
                          self.mask_job_procing_batch, self.mask_job_finish_batch, self.mask_ma_procing_batch, self.mask_wo_procing_batch,
                          self.ope_step_batch, self.time, self.schedule_ope, self.schedule_job, self.ope_pre_num, self.pre_opes,
                          self.feature, self.reward_batch, self.reward)
        return self.state, self.N.item(), self.done_batch

    def if_no_eligible(self):
        """
        检测当前时间是否还有可以待处理的操作-机器对
        """
        if torch.all(self.mask_wo_procing_batch).item():
            return torch.tensor([0], dtype=torch.float64)

        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch,
                                     self.end_ope_biases_batch, self.ope_step_batch)  # 限制操作步数不超过给定的时间偏移量
        op_proc_time = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1,
                                                                                           self.proc_times_batch.size(
                                                                                               2)))  # 实际的操作处理时间
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(1).expand_as(op_proc_time)
        # wo_eligible = ~self.mask_wo_procing_batch.unsqueeze(1)
        # wo_eligible = torch.nn.functional.pad(wo_eligible, pad=(0, 2), value=False).expand_as(op_proc_time)
        job_eligible = ~(self.mask_job_procing_batch + self.mask_job_finish_batch)[:, :, None].expand_as(op_proc_time)
        ope_eligible = (self.schedule_job)[:, :, None].expand_as(op_proc_time)
        eligible = ma_eligible & job_eligible & ope_eligible
        flag_trans_2_next_time = torch.sum(torch.where(eligible, op_proc_time.double(), 0.0).transpose(1, 2), dim=[1, 2])  # 每个元素表示对应实例中有多少个操作-机器对是可供处理的
        # shape: (batch_size)
        # 值为0 表示对应实例没有待处理的操作-机器对
        # 即环境需要转向下一时间步，即改变time
        return flag_trans_2_next_time

    def next_time(self, flag_trans_2_next_time):
        """
        Transit to the next time  转向下一时间步
        """
        # 哪些实例需要进行时间步的转移
        flag_need_trans = (flag_trans_2_next_time == 0) & (~self.done_batch)  # True
        # 每个机器的已经使用时间
        a = self.machines_batch[:, :, 1]
        # 筛选出使用时间大于当前时间的机器
        b = torch.where(a > self.time[:, None], a, torch.max(self.feat_opes_batch[:, 4, :]) + 1.0)
        # 对应实例进行时间步转移所需的最小时间
        c = torch.min(b, dim=1)[0]
        # 表示在上述时间步转移时机器已经完成了任务
        d = torch.where((a == c[:, None]) & (self.machines_batch[:, :, 0] == 0) & flag_need_trans[:, None], True, False)
        # The time for each batch to transit to or stay in
        e = torch.where(flag_need_trans, c, self.time)  # condition为true，则选前者
        self.time = e

        # 更新部分调度（state）、变量和特征向量
        aa = self.machines_batch.transpose(1, 2)
        aa[d, 0] = 1
        self.machines_batch = aa.transpose(1, 2)  # 设置为1表示可用

        utiliz = self.machines_batch[:, :, 2]  # 累计处理时间
        cur_time = self.time[:, None].expand_as(utiliz)
        utiliz = torch.minimum(utiliz, cur_time)  # 进行逐元素比较，取较小值
        utiliz = utiliz.div(self.time[:, None] + 1e-5)
        self.feat_mas_batch[:, 2, :] = utiliz  # 累计处理时间与当前时间之比

        jobs = torch.where(d, self.machines_batch[:, :, 3].double(), -1.0).float()  # 执行完成的置为-1
        jobs_index = np.argwhere(jobs.cpu() >= 0).to(self.device)
        job_idxes = jobs[jobs_index[0], jobs_index[1]].long()
        job_batch_idxes = jobs_index[0]

        # for i in range(self.num_opes):
        #     if job_idxes == self.opes_appertain_batch[:, i]:
        #         if (self.ope_pre_num[:, i] == 0):
        #             self.schedule_ope[:, i] = True
        # for i in range(self.num_opes):
        #     if job_idxes == self.opes_appertain_batch[:, i]:
        #         if self.schedule_ope[:, i]:
        #             self.schedule_job[:, self.opes_appertain_batch[:, i]] = True
        for pre, ids in self.pre_opes.items():
            if len(ids) > 0:
                for i in range(len(ids)):
                    condition = torch.logical_and(ids[i] == job_idxes, self.ope_step_batch[:, job_idxes] == self.end_ope_biases_batch[:, job_idxes] + 1)
                    if torch.all(condition).item():
                        self.schedule_job[:, pre] = True
        # print(self.schedule_job)

        wos = torch.where(d, self.machines_batch[:, :, 4].double(), -1.0).float()
        wos_index = np.argwhere(wos.cpu() >= 0).to(self.device)
        wo_idxes = wos[wos_index[0], wos_index[1]].long()
        wo_batch_idxes = wos_index[0]

        self.mask_job_procing_batch[job_batch_idxes, job_idxes] = False
        self.mask_ma_procing_batch[d] = False  # 完成执行的机器置为 false
        self.mask_wo_procing_batch[wo_batch_idxes, wo_idxes] = False
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1,
                                                 True, self.mask_job_finish_batch)  # 作业全部操作完成就置为 true

    def reset(self):
        """
        重置环境，使其回到初始状态
        """
        self.num_opes = copy.deepcopy(self.old_num_opes)
        self.num_jobs = copy.deepcopy(self.old_num_jobs)
        self.proc_times_batch = copy.deepcopy(self.old_proc_times_batch)
        self.proc_power_batch = copy.deepcopy(self.old_proc_power_batch)
        self.ope_ma_adj_batch = copy.deepcopy(self.old_ope_ma_adj_batch)
        self.cal_cumul_adj_batch = copy.deepcopy(self.old_cal_cumul_adj_batch)
        self.except_makspan = copy.deepcopy(self.old_except_makespan)
        self.pre_opes = copy.deepcopy(self.old_pre_opes)
        self.ope_pre_adj_batch = copy.deepcopy(self.old_ope_pre_adj_batch)
        self.ope_sub_adj_batch = copy.deepcopy(self.old_ope_sub_adj_batch)
        self.opes_appertain_batch = copy.deepcopy(self.old_opes_appertain_batch)
        self.num_ope_biases_batch = copy.deepcopy(self.old_num_ope_biases_batch)
        self.nums_ope_batch = copy.deepcopy(self.old_nums_ope_batch)
        self.end_ope_biases_batch = copy.deepcopy(self.old_end_ope_biases_batch)
        self.nums_opes = copy.deepcopy(self.old_nums_opes)
        self.feat_opes_batch = copy.deepcopy(self.old_feat_opes_batch)
        self.feat_mas_batch = copy.deepcopy(self.old_feat_mas_batch)
        self.schedule_ope = copy.deepcopy(self.old_schedule_ope)
        self.schedule_job = copy.deepcopy(self.old_schedule_job)
        self.ope_pre_num = copy.deepcopy(self.old_ope_pre_num)
        self.state = copy.deepcopy(self.old_state)

        self.batch_idxes = torch.arange(self.batch_size)
        self.time = torch.zeros(self.batch_size)
        self.N = torch.zeros(self.batch_size).int()
        self.pre_mas = torch.full(size=(self.batch_size, self.num_wos), dtype=torch.long, fill_value=-1)
        self.ope_step_batch = copy.deepcopy(self.num_ope_biases_batch)
        self.mask_job_procing_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, self.num_mas), dtype=torch.bool, fill_value=False)
        self.mask_wo_procing_batch = torch.full(size=(self.batch_size, self.num_wos), dtype=torch.bool, fill_value=False)
        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 5))
        self.schedules_batch[:, :, 2] = self.feat_opes_batch[:, 5, :]
        self.schedules_batch[:, :, 3] = self.feat_opes_batch[:, 5, :] + self.feat_opes_batch[:, 2, :]
        self.machines_batch = torch.zeros(size=(self.batch_size, self.num_mas, 5))
        self.machines_batch[:, :, 0] = torch.ones(size=(self.batch_size, self.num_mas))

        self.wo_ma_T = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))
        self.wo_ma_time = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))
        self.wo_ma_kt = torch.zeros(size=(self.batch_size, self.num_wos, self.num_mas))

        self.feature = torch.zeros(size=(self.batch_size, 4))
        self.reward_batch = torch.zeros(size=(self.batch_size, self.num_opes + 1, 4))
        self.reward_batch[:, self.N.item(), 0] = torch.max(self.except_makspan[:, 1, :], dim=1)[0]
        self.reward = torch.zeros(self.batch_size).int()
        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # shape: (batch_size) 工作批次的完成状态
        # self.makespan_batch = torch.zeros(size=(self.batch_size, self.num_opes + 1)).long()
        # self.makespan_batch[:, self.N] = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]  # shape: (batch_size, num_opes) 工作批次的完成时间
        # self.totalpower_batch = torch.zeros(size=(self.batch_size, self.num_opes + 1)).long()
        # self.reward_batch = torch.zeros(size=(self.batch_size, self.num_opes + 1)).long()
        # self.done_batch = self.mask_job_finish_batch.all(dim=1)  # 检查是否所有作业都已经完成
        return self.state

    def get_idx(self, id_ope, batch_id):
        """
        根据实例索引和操作（绝对）索引，获取作业和操作（相对）索引
        """
        idx_job = max([idx for (idx, val) in enumerate(self.num_ope_biases_batch[batch_id]) if id_ope >= val])  # 判断id_ope在哪个作业中
        idx_ope = id_ope - self.num_ope_biases_batch[batch_id][idx_job]  # 计算id_ope所属作业中的相对索引idx_ope
        return idx_job, idx_ope

    def validate_gantt(self):
        """
        验证调度是否可行（机器上安排的前后操作时间重叠、机器上安排的操作时间不等于处理时间、作业前后操作时间重叠、调度操作数不等与总操作数
        """
        ma_gantt_batch = [[[] for _ in range(self.num_mas)] for __ in range(self.batch_size)]  # 保存每个机器上的操作列表
        for batch_id, schedules in enumerate(self.schedules_batch):
            for i in range(int(self.nums_opes[batch_id])):  # 表示该操作被分配到了batch_id号实例的第int(step[1])台机器上
                step = schedules[i]  # step[1]机器编号、2操作编号、3开始结束时间
                ma_gantt_batch[batch_id][int(step[1])].append([i, float('{:.2f}'.format(step[2].item())), float('{:.2f}'.format(step[3].item()))])
        proc_time_batch = self.proc_times_batch

        # 检查是否存在机器上的操作时间重叠和处理时间错误
        flag_proc_time = 0
        flag_ma_overlap = 0
        flag = 0  # 记录错误情况的数量
        for k in range(self.batch_size):
            ma_gantt = ma_gantt_batch[k]
            proc_time = proc_time_batch[k]
            for i in range(self.num_mas):  # 遍历每个作业的每台机器上的操作列表
                ma_gantt[i].sort(key=lambda s: s[1])  # 根据操作的开始时间进行排序，以确保操作按照时间顺序排列
                for j in range(len(ma_gantt[i])):
                    if (len(ma_gantt[i]) <= 1) or (j == len(ma_gantt[i]) - 1):  # 操作数<= 1，或者当前操作是列表中的最后一个操作
                        break
                    if ma_gantt[i][j][2] > ma_gantt[i][j + 1][1]:  # 该机器当前操作的结束时间大于下一个操作的开始时间
                        flag_ma_overlap += 1
                    if ma_gantt[i][j][2] - ma_gantt[i][j][1] != proc_time[ma_gantt[i][j][0]][i]:  # 处理时间不对等
                        print(ma_gantt[i][j][2] - ma_gantt[i][j][1], proc_time[ma_gantt[i][j][0]][i])
                        flag_proc_time += 1
                    flag += 1

        # 检查作业的顺序和重叠情况
        flag_ope_overlap = 0  # 记录重叠情况的数量
        for k in range(self.batch_size):
            schedule = self.schedules_batch[k]
            nums_ope = self.nums_ope_batch[k]
            num_ope_biases = self.num_ope_biases_batch[k]
            for i in range(self.num_jobs):
                if int(nums_ope[i]) <= 1:
                    continue
                for j in range(int(nums_ope[i]) - 1):
                    step = schedule[num_ope_biases[i] + j]
                    step_next = schedule[num_ope_biases[i] + j + 1]
                    if step[3] > step_next[2]:  # 当前操作的结束时间大于下一个操作的开始时间
                        flag_ope_overlap += 1

        # 检查是否有未调度的操作
        flag_unscheduled = 0
        for batch_id, schedules in enumerate(self.schedules_batch):
            count = 0
            for i in range(schedules.size(0)):
                if schedules[i][0] == 1:
                    count += 1
            add = 0 if (count == self.nums_opes[batch_id]) else 1  # 已安排的操作数量和总操作数量比较
            flag_unscheduled += add

        if flag_ma_overlap + flag_ope_overlap + flag_proc_time + flag_unscheduled != 0:
            return False, self.schedules_batch
        else:
            return True, self.schedules_batch

    def close(self):
        pass

    def SPT(self, actions):
        opes = actions[0, :]
        mas = actions[1, :]
        ope_time = torch.zeros(self.num_wos)
        T = 0

        for worker in range(self.num_wos):
            if not self.mask_wo_procing_batch[:, worker]:
                pre_ma = self.pre_mas[:, worker]
                first_rate = self.wor_ma_first_batch[:, worker, mas]
                end_rate = self.wor_ma_end_batch[:, worker, mas]
                rate = 0
                if (pre_ma == mas.item()):  # worker上一个machine就是mas
                    kt = self.time - self.wo_ma_kt[:, worker, pre_ma]
                    if (kt == 0):  # 无间断时间
                        rate = first_rate - 0.10 * self.wo_ma_T[:, worker, mas]
                        rate = torch.where(rate > end_rate, rate, end_rate)
                    elif (kt >= self.paras["F_total"]):  # 虽然是同一个mas，但是间隔时间超过全遗忘时间
                        rate = first_rate
                    else:  # 仍是同一个mas，且间隔时间未超过全遗忘时间
                        F = self.wo_ma_time[:, worker, mas] / self.wo_ma_T[:, worker, mas]
                        ret = self.ret_n(kt, F)
                        print("回退次数为", ret)
                        if self.wo_ma_T[:, worker, mas] <= ret:
                            T = 0
                        else:
                            T = self.wo_ma_T[:, worker, mas] - ret
                        rate = first_rate - 0.10 * T
                        rate = torch.where(rate > end_rate, rate, end_rate)
                elif ((pre_ma != mas.item()) & (self.wo_ma_T[:, worker, mas] == 0)):  # 第一次在此mas上工作
                    rate = first_rate
                elif ((pre_ma != mas.item()) & (self.wo_ma_T[:, worker, mas] > 0)):  # 上一个工作的不是mas，且不是第一次
                    kt = self.time - self.wo_ma_kt[:, worker, mas]
                    if (kt >= self.paras["F_total"]):  # 超过全遗忘时间
                        rate = first_rate
                    else:
                        F = self.wo_ma_time[:, worker, mas] / self.wo_ma_T[:, worker, mas]
                        ret = self.ret_n(kt, F)
                        print("回退次数为", ret)
                        if self.wo_ma_T[:, worker, mas] <= ret:
                            T = 0
                        else:
                            T = self.wo_ma_T[:, worker, mas] - ret
                        rate = first_rate - 0.10 * T
                        rate = torch.where(rate > end_rate, rate, end_rate)
                wo_time = rate * self.proc_times_batch[self.batch_idxes, opes, mas]
                rounded_num = torch.round(wo_time * 100) / 100
                formatted_num = '{:.2f}'.format(rounded_num.item())
                # ope_time[worker] = torch.tensor([[float(formatted_num)]])
                ope_time[worker] = torch.tensor(float(formatted_num))
        values = torch.tensor([1000])
        indices = 0
        for i in range(self.num_wos):
            if (ope_time[i] > 0) & (ope_time[i] < values):
                values = ope_time[i]
                indices = i
        prec_time = torch.unsqueeze(values, 0)
        wo = indices
        return wo, prec_time

    def ret_n(self, kt, F):
        i = 0
        while(i * F <= self.paras["F_total"]):
            if ((i * F <= kt) & ((i + 1) * F > kt)):
                return i + 1
            i += 1

    def add_job(self):
        Jobshop = JobShop()
        # choose = [1, 2, 3, 4, 5]
        # num = random.randint(choose)
        # if num == 1:
        #     num_operation = 3
        # elif num == 2:
        #     num_operation = 4
        # elif num == 3:
        #     num_operation = 3
        # elif num == 4:
        #     num_operation = 3
        # else:
        #     num_operation = 2
        # choose.remove(num)
        min_ope_per_job = 1
        max_ope_per_job = 4
        min_duration_per_operation = 1
        max_duration_per_operation = 99

        num_operations = min(random.randint(min_ope_per_job, max_ope_per_job), self.paras["num_max"] - self.num_opes)  # 操作数量
        # 限制最大 ope数
        counter = 0
        job_id = self.num_jobs
        operation_num = self.num_opes

        for i in range(num_operations):  # 生成1个作业（非装配
            mas = random.randint(1, 5)  # 机器个数
            arr_mas = random.sample(list(range(mas)), mas)  # 具体可用机器集
            print(mas, arr_mas)
            operation = Operation(None, job_id, self.num_opes + i)
            for id in range(len(arr_mas)):  # 为每个机器生成运行时间
                duration = random.randint(min_duration_per_operation, max_duration_per_operation)
                power = self.ma_power[:, id, 1] * duration
                # print(id, duration, power)
                operation.add_operation_option(arr_mas[id], duration, power)  # 生成操作选项
            Jobshop.add_operation(operation)
            if counter != 0:  # 对于除第一个操作外的其他操作，建立前序关系以确保操作的顺序性
                Jobshop.precedence_relations_operations[self.num_opes + i] = [
                    Jobshop.get_operation(self.num_opes + i - 1)]
                operation.add_predecessors([Jobshop.get_operation(self.num_opes + i - 1)])
            else:
                job = Job(job_id)
                Jobshop.add_job(job)
                Jobshop.precedence_relations_operations[self.num_opes + i] = []

            counter += 1

        for operation in Jobshop.operations:
            job = Jobshop.get_job(operation.job_id)
            job.add_operation(operation)
            operation.update_job(job)

        Jobshop.set_nr_of_jobs(len(Jobshop.jobs))
        Jobshop.set_nr_of_machines(self.num_mas)
        Jobshop.precedence_relations_jobs[job_id] = []
        # for machine_id in range(0, self.num_mas):
        #     idlepower = random.randint(min_idlepower_mas, max_idlepower_mas)
        #     Jobshop.add_machine((Machine(machine_id, idlepower)))

        load_data = add_fajs(Jobshop, self.num_mas, num_operations)
        self.num_opes += num_operations
        self.num_jobs += 1
        print(self.num_opes, self.num_jobs)  # Debugging print statement
        # 加载特征
        self.pre_opes[self.num_jobs - 1] = []  # 设置作业的前驱关系
        num_data = 9  # 从实例中提取的数据量
        tensors = [[] for _ in range(num_data)]
        for j in range(num_data):
            tensors[j].append(load_data[j].to(self.device))  # tensors列表中将包含所有实例的特征数据

        # 动态特征
        # shape: (batch_size, num_opes, num_mas)，运行时间
        proc_times_batch = torch.stack(tensors[0], dim=0)
        # shape: (batch_size, num_opes, num_mas)，操作—机器
        ope_ma_adj_batch = torch.stack(tensors[1], dim=0).long()
        # shape: (batch_size, num_opes, num_opes), 计算累积量所需的邻接矩阵
        cal_cumul_adj_batch = torch.stack(tensors[7], dim=0).float()
        temp_cal_sumul = self.cal_cumul_adj_batch
        # shape: (batch_size, num_opes, num_mas)
        proc_power_batch = torch.stack(tensors[8], dim=0)

        # 静态特征
        # shape: (batch_size, num_opes, num_opes)
        ope_pre_adj_batch = torch.stack(tensors[2], dim=0)  # 前驱
        temp_ope_pre = self.ope_pre_adj_batch
        # shape: (batch_size, num_opes, num_opes)
        ope_sub_adj_batch = torch.stack(tensors[3], dim=0)  # 后继
        temp_ope_sub = self.ope_sub_adj_batch
        # shape: (batch_size, num_opes), 作业和操作的映射关系
        opes_appertain_batch = torch.stack(tensors[4], dim=0).long()
        # shape: (batch_size, num_jobs), 每个作业第一个操作的ID
        num_ope_biases_batch = torch.stack(tensors[5], dim=0).long()
        # shape: (batch_size, num_jobs), 每个作业的操作数
        nums_ope_batch = torch.stack(tensors[6], dim=0).long()
        end_ope_biases_batch = num_ope_biases_batch + nums_ope_batch - 1

        self.proc_times_batch = torch.cat((self.proc_times_batch, proc_times_batch), dim=1)
        self.ope_ma_adj_batch = torch.cat((self.ope_ma_adj_batch, ope_ma_adj_batch), dim=1)
        self.proc_power_batch = torch.cat((self.proc_power_batch, proc_power_batch), dim=1)

        self.cal_cumul_adj_batch = torch.zeros(size=(self.batch_size, self.num_opes, self.num_opes))
        self.cal_cumul_adj_batch[:, :operation_num, :operation_num] = temp_cal_sumul
        self.cal_cumul_adj_batch[:, operation_num:, operation_num:] = cal_cumul_adj_batch

        self.ope_pre_adj_batch = torch.full(size=(self.batch_size, self.num_opes, self.num_opes), dtype=torch.bool,
                                            fill_value=False)
        self.ope_pre_adj_batch[:, :operation_num, :operation_num] = temp_ope_pre
        self.ope_pre_adj_batch[:, operation_num:, operation_num:] = ope_pre_adj_batch

        self.ope_sub_adj_batch = torch.full(size=(self.batch_size, self.num_opes, self.num_opes), dtype=torch.bool,
                                            fill_value=False)
        self.ope_sub_adj_batch[:, :operation_num, :operation_num] = temp_ope_sub
        self.ope_sub_adj_batch[:, operation_num:, operation_num:] = ope_sub_adj_batch

        self.opes_appertain_batch = torch.cat((self.opes_appertain_batch, opes_appertain_batch), dim=1)
        self.num_ope_biases_batch = torch.cat((self.num_ope_biases_batch, num_ope_biases_batch), dim=1)
        self.nums_ope_batch = torch.cat((self.nums_ope_batch, nums_ope_batch), dim=1)
        self.end_ope_biases_batch = self.num_ope_biases_batch + self.nums_ope_batch - 1
        self.nums_opes = torch.sum(self.nums_ope_batch, dim=1)

        # 生成原始特征向量
        feat_opes_batch = torch.zeros(size=(self.batch_size, self.paras["ope_feat_dim"], num_operations))  # 存储操作特征向量
        feat_mas_batch = torch.zeros(size=(self.batch_size, self.paras["ma_feat_dim"], self.num_mas))  # 存储机器的特征向量

        # a = torch.zeros(size=(self.batch_size, self.num_opes))
        # a = torch.count_nonzero(self.ope_ma_adj_batch, dim=2)
        feat_opes_batch[:, 1, :] = torch.count_nonzero(ope_ma_adj_batch, dim=2)  # 每个操作的邻居机器的数量
        feat_opes_batch[:, 2, :] = torch.sum(proc_times_batch, dim=2).div(
            feat_opes_batch[:, 1, :] + 1e-9)  # 每个操作的平均处理时间
        feat_opes_batch[:, 3, :] = convert_feat_job_2_ope(nums_ope_batch,
                                                          opes_appertain_batch - job_id)  # 每个操作所属作业中未调度操作的数量
        feat_opes_batch[:, 5, :] = torch.bmm(feat_opes_batch[:, 2, :].unsqueeze(1),
                                             cal_cumul_adj_batch).squeeze()  # 每个操作的完成时间
        end_time_batch = (feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]).gather(1,
                                                                                      end_ope_biases_batch - operation_num)  # 完成时间通过累积前面所有操作的处理时间和路径上较长完成时间来计算
        feat_opes_batch[:, 4, :] = convert_feat_job_2_ope(end_time_batch, opes_appertain_batch - job_id)  # 每个作业最后一个操作的完成时间

        feat_mas_batch[:, 0, :] = torch.count_nonzero(ope_ma_adj_batch, dim=1)  # 每个机器的邻居操作数量

        self.feat_opes_batch = torch.cat((self.feat_opes_batch, feat_opes_batch), dim=2)
        self.feat_mas_batch = self.feat_mas_batch + feat_mas_batch
        schedule_ope = torch.full(size=(self.batch_size, num_operations), dtype=torch.bool, fill_value=False)
        schedule_job = torch.full(size=(self.batch_size, 1), dtype=torch.bool, fill_value=False)
        ope_pre_num = torch.sum(ope_pre_adj_batch, dim=1)
        for i in range(num_operations):
            zero_mask = torch.eq(ope_pre_num[:, i], 0)
            schedule_ope[:, i] = zero_mask  # ope是否可调度
        for ba in range(self.batch_size):
            for i in range(num_operations):
                if schedule_ope[ba, i]:
                    schedule_job[ba, opes_appertain_batch[ba, i] - job_id] = True  # 有一个ope可操作所在job就设置为true
        self.schedule_job = torch.cat((self.schedule_job, schedule_job), dim=1)
        self.schedule_ope = torch.cat((self.schedule_ope, schedule_ope), dim=1)
        self.ope_pre_num = torch.cat((self.ope_pre_num, ope_pre_num), dim=1)

        except_makspan = torch.zeros(size=(self.batch_size, 2, num_operations))
        self.except_makspan = torch.cat((self.except_makspan, except_makspan), dim=2)

        ope_step_batch = torch.zeros(size=(self.batch_size, 1))
        ope_step_batch[:, 0] = num_ope_biases_batch[:, 0]
        self.ope_step_batch = torch.cat((self.ope_step_batch, ope_step_batch), dim=1).to(dtype=torch.int64)

        # 当前状态、动态的掩码
        # shape: (batch_size, num_jobs), 正在执行的作业
        mask_job_procing_batch = torch.full(size=(self.batch_size, 1), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_jobs), 已经完成的作业
        mask_job_finish_batch = torch.full(size=(self.batch_size, 1), dtype=torch.bool, fill_value=False)
        self.mask_job_procing_batch = torch.cat((self.mask_job_procing_batch, mask_job_procing_batch), dim=1)
        self.mask_job_finish_batch = torch.cat((self.mask_job_finish_batch, mask_job_finish_batch), dim=1)

        schedules_batch = torch.zeros(size=(self.batch_size, num_operations, 5))
        schedules_batch[:, :, 3] = feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]
        self.schedules_batch = torch.cat((self.schedules_batch, schedules_batch), dim=1)

        reward_batch = torch.zeros(size=(self.batch_size, num_operations, 4))
        self.reward_batch = torch.cat((self.reward_batch, reward_batch), dim=1)
        self.done_batch = self.mask_job_finish_batch.all(dim=1)

    # def add_job(self):
    #     Jobshop = JobShop()
    #     min_nr_operations_per_job = 1
    #     max_nr_operations_per_job = 4
    #     min_duration_per_operation = 1
    #     max_duration_per_operation = 99
    #
    #     num_operations = random.randint(min_nr_operations_per_job, max_nr_operations_per_job)  # 操作数量
    #     if num_operations <= self.paras["num_max"] - self.num_opes:  # 限制最大 ope数
    #         counter = 0
    #         job_id = self.num_jobs
    #         operation_num = self.num_opes
    #
    #         for i in range(num_operations):  # 生成1个作业（非装配
    #             mas = random.randint(1, 5)  # 机器个数
    #             arr_mas = random.sample(list(range(mas)), mas)  # 具体可用机器集
    #             print(mas, arr_mas)
    #             operation = Operation(None, job_id, self.num_opes + i)
    #             for id in range(len(arr_mas)):  # 为每个机器生成运行时间
    #                 duration = random.randint(min_duration_per_operation, max_duration_per_operation)
    #                 power = self.ma_power[:, id, 1] * duration
    #                 operation.add_operation_option(arr_mas[id], duration, power)  # 生成操作选项
    #             Jobshop.add_operation(operation)
    #             if counter != 0:  # 对于除第一个操作外的其他操作，建立前序关系以确保操作的顺序性
    #                 Jobshop.precedence_relations_operations[self.num_opes + i] = [
    #                     Jobshop.get_operation(self.num_opes + i - 1)]
    #                 operation.add_predecessors([Jobshop.get_operation(self.num_opes + i - 1)])
    #             else:
    #                 job = Job(job_id)
    #                 Jobshop.add_job(job)
    #                 Jobshop.precedence_relations_operations[self.num_opes + i] = []
    #
    #             counter += 1
    #
    #         for operation in Jobshop.operations:
    #             job = Jobshop.get_job(operation.job_id)
    #             job.add_operation(operation)
    #             operation.update_job(job)
    #
    #         Jobshop.set_nr_of_jobs(len(Jobshop.jobs))
    #         Jobshop.set_nr_of_machines(self.num_mas)
    #         Jobshop.precedence_relations_jobs[job_id] = []
    #         # for machine_id in range(0, self.num_mas):
    #         #     idlepower = random.randint(min_idlepower_mas, max_idlepower_mas)
    #         #     Jobshop.add_machine((Machine(machine_id, idlepower)))
    #
    #         load_data = add_fajs(Jobshop, self.num_mas, num_operations)
    #         self.num_opes += num_operations
    #         self.num_jobs += 1
    #         print(self.num_opes, self.num_jobs)  # Debugging print statement
    #         # 加载特征
    #         self.pre_opes[self.num_jobs - 1] = []  # 设置作业的前驱关系
    #         num_data = 13  # 从实例中提取的数据量
    #         tensors = [[] for _ in range(num_data)]
    #         for j in range(num_data):
    #             tensors[j].append(load_data[j].to(self.device))  # tensors列表中将包含所有实例的特征数据
    #
    #         # 动态特征
    #         # shape: (batch_size, num_opes, num_mas)，运行时间
    #         proc_times_batch = torch.stack(tensors[0], dim=0)
    #         # shape: (batch_size, num_opes, num_mas)，操作—机器
    #         ope_ma_adj_batch = torch.stack(tensors[1], dim=0).long()
    #         # shape: (batch_size, num_opes, num_opes), 计算累积量所需的邻接矩阵
    #         cal_cumul_adj_batch = torch.stack(tensors[7], dim=0).float()
    #         temp_cal_sumul = self.cal_cumul_adj_batch
    #         # shape: (batch_size, num_opes, num_mas)
    #         proc_power_batch = torch.stack(tensors[10], dim=0)
    #
    #         # 静态特征
    #         # shape: (batch_size, num_opes, num_opes)
    #         ope_pre_adj_batch = torch.stack(tensors[2], dim=0)  # 前驱
    #         temp_ope_pre = self.ope_pre_adj_batch
    #         # shape: (batch_size, num_opes, num_opes)
    #         ope_sub_adj_batch = torch.stack(tensors[3], dim=0)  # 后继
    #         temp_ope_sub = self.ope_sub_adj_batch
    #         # shape: (batch_size, num_opes), 作业和操作的映射关系
    #         opes_appertain_batch = torch.stack(tensors[4], dim=0).long()
    #         # shape: (batch_size, num_jobs), 每个作业第一个操作的ID
    #         num_ope_biases_batch = torch.stack(tensors[5], dim=0).long()
    #         # shape: (batch_size, num_jobs), 每个作业的操作数
    #         nums_ope_batch = torch.stack(tensors[6], dim=0).long()
    #         end_ope_biases_batch = num_ope_biases_batch + nums_ope_batch - 1
    #
    #         self.proc_times_batch = torch.cat((self.proc_times_batch, proc_times_batch), dim=1)
    #         self.ope_ma_adj_batch = torch.cat((self.ope_ma_adj_batch, ope_ma_adj_batch), dim=1)
    #         self.proc_power_batch = torch.cat((self.proc_power_batch, proc_power_batch), dim=1)
    #
    #         self.cal_cumul_adj_batch = torch.zeros(size=(self.batch_size, self.num_opes, self.num_opes))
    #         self.cal_cumul_adj_batch[:, :operation_num, :operation_num] = temp_cal_sumul
    #         self.cal_cumul_adj_batch[:, operation_num:, operation_num:] = cal_cumul_adj_batch
    #
    #         self.ope_pre_adj_batch = torch.full(size=(self.batch_size, self.num_opes, self.num_opes), dtype=torch.bool,
    #                                             fill_value=False)
    #         self.ope_pre_adj_batch[:, :operation_num, :operation_num] = temp_ope_pre
    #         self.ope_pre_adj_batch[:, operation_num:, operation_num:] = ope_pre_adj_batch
    #
    #         self.ope_sub_adj_batch = torch.full(size=(self.batch_size, self.num_opes, self.num_opes), dtype=torch.bool,
    #                                             fill_value=False)
    #         self.ope_sub_adj_batch[:, :operation_num, :operation_num] = temp_ope_sub
    #         self.ope_sub_adj_batch[:, operation_num:, operation_num:] = ope_sub_adj_batch
    #
    #         self.opes_appertain_batch = torch.cat((self.opes_appertain_batch, opes_appertain_batch), dim=1)
    #         self.num_ope_biases_batch = torch.cat((self.num_ope_biases_batch, num_ope_biases_batch), dim=1)
    #         self.nums_ope_batch = torch.cat((self.nums_ope_batch, nums_ope_batch), dim=1)
    #         self.end_ope_biases_batch = self.num_ope_biases_batch + self.nums_ope_batch - 1
    #         self.nums_opes = torch.sum(self.nums_ope_batch, dim=1)
    #
    #         # 生成原始特征向量
    #         feat_opes_batch = torch.zeros(
    #             size=(self.batch_size, self.paras["ope_feat_dim"], num_operations))  # 存储操作特征向量
    #         feat_mas_batch = torch.zeros(size=(self.batch_size, self.paras["ma_feat_dim"], self.num_mas))  # 存储机器的特征向量
    #
    #         a = torch.zeros(size=(self.batch_size, num_operations))
    #         a = torch.count_nonzero(ope_ma_adj_batch, dim=2)
    #         # feat_opes_batch[:, 1, :] = torch.count_nonzero(ope_ma_adj_batch, dim=2)  # 每个操作的邻居机器的数量
    #         feat_opes_batch[:, 1, :] = torch.sum(proc_power_batch, dim=2).div(a + 1e-9)
    #         feat_opes_batch[:, 2, :] = torch.sum(proc_times_batch, dim=2).div(a + 1e-9)  # 每个操作的平均处理时间
    #         feat_opes_batch[:, 3, :] = convert_feat_job_2_ope(nums_ope_batch,
    #                                                           opes_appertain_batch - job_id)  # 每个操作所属作业中未调度操作的数量
    #         feat_opes_batch[:, 5, :] = torch.bmm(feat_opes_batch[:, 2, :].unsqueeze(1),
    #                                              cal_cumul_adj_batch).squeeze()  # 每个操作的完成时间
    #         end_time_batch = (feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]).gather(1,
    #                                                                                       end_ope_biases_batch - operation_num)  # 完成时间通过累积前面所有操作的处理时间和路径上较长完成时间来计算
    #         feat_opes_batch[:, 4, :] = convert_feat_job_2_ope(end_time_batch,
    #                                                           opes_appertain_batch - job_id)  # 每个作业最后一个操作的完成时间
    #         feat_mas_batch[:, 0, :] = torch.count_nonzero(ope_ma_adj_batch, dim=1)  # 每个机器的邻居操作数量
    #         self.feat_opes_batch = torch.cat((self.feat_opes_batch, feat_opes_batch), dim=2)
    #         self.feat_mas_batch = self.feat_mas_batch + feat_mas_batch
    #
    #         ope_step_batch = torch.zeros(size=(self.batch_size, 1))
    #         ope_step_batch[:, 0] = num_ope_biases_batch[:, 0]
    #         self.ope_step_batch = torch.cat((self.ope_step_batch, ope_step_batch), dim=1).to(dtype=torch.int64)
    #
    #         self.schedule_ope = torch.full(size=(self.batch_size, self.num_opes), dtype=torch.bool, fill_value=False)
    #         self.schedule_job = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
    #         self.ope_pre_num = torch.sum(self.ope_pre_adj_batch, dim=1)
    #         for i in range(self.num_opes):
    #             if (self.ope_pre_num[:, i] == 0):
    #                 self.schedule_ope[:, i] = True
    #         for i in range(self.num_opes):
    #             if self.schedule_ope[:, i]:
    #                 self.schedule_job[:, self.opes_appertain_batch[:, i]] = True
    #
    #         # 当前状态、动态的掩码
    #         # shape: (batch_size, num_jobs), 正在执行的作业
    #         mask_job_procing_batch = torch.full(size=(self.batch_size, 1), dtype=torch.bool, fill_value=False)
    #         # shape: (batch_size, num_jobs), 已经完成的作业
    #         mask_job_finish_batch = torch.full(size=(self.batch_size, 1), dtype=torch.bool, fill_value=False)
    #         self.mask_job_procing_batch = torch.cat((self.mask_job_procing_batch, mask_job_procing_batch), dim=1)
    #         self.mask_job_finish_batch = torch.cat((self.mask_job_finish_batch, mask_job_finish_batch), dim=1)
    #
    #         schedules_batch = torch.zeros(size=(self.batch_size, num_operations, 4))
    #         schedules_batch[:, :, 3] = feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]
    #         self.schedules_batch = torch.cat((self.schedules_batch, schedules_batch), dim=1)
    #
    #         reward_batch = torch.zeros(size=(self.batch_size, num_operations, 4))
    #         feature = torch.zeros(size=(self.batch_size, num_operations, 4))
    #
    #         self.reward_batch = torch.cat((self.reward_batch, reward_batch))
    #         self.feature = torch.cat((self.feature, feature))
    #
    #         # 在重置环境时保存初始状态的数据
    #         self.old_proc_times_batch = copy.deepcopy(self.proc_times_batch)
    #         self.old_proc_power_batch = copy.deepcopy(self.proc_power_batch)
    #         self.old_ope_ma_adj_batch = copy.deepcopy(self.ope_ma_adj_batch)
    #         self.old_cal_cumul_adj_batch = copy.deepcopy(self.cal_cumul_adj_batch)
    #         self.old_feat_opes_batch = copy.deepcopy(self.feat_opes_batch)
    #         self.old_feat_mas_batch = copy.deepcopy(self.feat_mas_batch)
    #         self.old_state = copy.deepcopy(self.state)


class CaseGenerator:
    """
    FAJSP 实例生成器
    """
    def __init__(self, job_init, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=None, path='../data/',
                 flag_same_opes=True, flag_doc=False):
        if nums_ope is None:
            nums_ope = []
        self.flag_doc = flag_doc  # 是否将实例保存到文件中
        self.flag_same_opes = flag_same_opes  # 是否允许作业中的操作重复
        self.nums_ope = nums_ope
        self.path = path  # 保存实例文件的路径
        self.job_init = job_init  # 作业的初始顺序
        self.num_mas = num_mas

        self.mas_per_ope_min = 1  # 每个操作所需的最小机器数量
        self.mas_per_ope_max = num_mas
        self.opes_per_job_min = opes_per_job_min  # 每个作业包含的最小操作数量
        self.opes_per_job_max = opes_per_job_max
        self.proctime_per_ope_min = 1  # 每个操作的最小平均处理时间
        self.proctime_per_ope_max = 20
        self.proctime_dev = 0.2  # 处理时间的标准差

    def get_case(self, idx=0):
        """
        生成 FAJSP 实例
        :param idx: 实例数
        """
        self.num_jobs = self.job_init
        if not self.flag_same_opes:
            self.nums_ope = [random.randint(self.opes_per_job_min, self.opes_per_job_max) for _ in range(self.num_jobs)]
        self.num_opes = sum(self.nums_ope)  # 操作数量
        self.nums_option = [random.randint(self.mas_per_ope_min, self.mas_per_ope_max) for _ in range(self.num_opes)]
        self.num_options = sum(self.nums_option)  # 机器数量
        self.ope_ma = []  # 存储每个操作所需的机器数量
        for val in self.nums_option:  # 从1~num_mas中随机抽取nums_option[i]个数，代表该操作所需的机器编号
            self.ope_ma = self.ope_ma + sorted(random.sample(range(1, self.num_mas+1), val))
        self.proc_time = []  # 运行时间总和
        self.proc_times_mean = [random.randint(self.proctime_per_ope_min, self.proctime_per_ope_max) for _ in range(self.num_opes)]
        for i in range(len(self.nums_option)):  # 确定上限和下限
            low_bound = max(self.proctime_per_ope_min,round(self.proc_times_mean[i]*(1-self.proctime_dev)))
            high_bound = min(self.proctime_per_ope_max,round(self.proc_times_mean[i]*(1+self.proctime_dev)))
            proc_time_ope = [random.randint(low_bound, high_bound) for _ in range(self.nums_option[i])]
            self.proc_time = self.proc_time + proc_time_ope
        self.num_ope_biass = [sum(self.nums_ope[0:i]) for i in range(self.num_jobs)]
        self.num_ma_biass = [sum(self.nums_option[0:i]) for i in range(self.num_opes)]
        line0 = '{0}\t{1}\t{2}\n'.format(self.num_jobs, self.num_mas, self.num_options / self.num_opes)
        lines = []
        lines_doc = []
        lines.append(line0)
        lines_doc.append('{0}\t{1}\t{2}'.format(self.num_jobs, self.num_mas, self.num_options / self.num_opes))
        for i in range(self.num_jobs):
            flag = 0  # 记录当前处理的步骤
            flag_time = 0  # 切换到处理时间的标志
            flag_new_ope = 1  # 跟踪操作的变化
            idx_ope = -1
            idx_ma = 0
            line = []
            option_max = sum(self.nums_option[self.num_ope_biass[i]:(self.num_ope_biass[i]+self.nums_ope[i])])
            idx_option = 0
            while True:
                if flag == 0:  # 遇到新工作
                    line.append(self.nums_ope[i])
                    flag += 1
                elif flag == flag_new_ope:  # 遇到新操作
                    idx_ope += 1
                    idx_ma = 0
                    flag_new_ope += self.nums_option[self.num_ope_biass[i] + idx_ope] * 2 + 1
                    line.append(self.nums_option[self.num_ope_biass[i] + idx_ope])
                    flag += 1
                elif flag_time == 0:  # 机器编号
                    line.append(self.ope_ma[self.num_ma_biass[self.num_ope_biass[i] + idx_ope] + idx_ma])
                    flag += 1
                    flag_time = 1
                else:  # 处理时间
                    line.append(self.proc_time[self.num_ma_biass[self.num_ope_biass[i] + idx_ope] + idx_ma])
                    flag += 1
                    flag_time = 0
                    idx_option += 1
                    idx_ma += 1
                if idx_option == option_max:
                    str_line = " ".join([str(val) for val in line])
                    lines.append(str_line + '\n')
                    lines_doc.append(str_line)
                    break
        lines.append('\n')
        if self.flag_doc:  # flag_doc 为 true，新建一个文件保存信息
            doc = open(self.path + '{0}j_{1}m_{2}.fjs'.format(self.num_jobs, self.num_mas, str.zfill(str(idx+1),3)),'a')
            for i in range(len(lines_doc)):
                print(lines_doc[i], file=doc)
            doc.close()
        return lines, self.num_jobs, self.num_jobs
