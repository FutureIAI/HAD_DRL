# 显示甘特图和节点图表
import copy
import torch
import random
import os
import networkx as nx  # 用于创建、操作和研究复杂网络的库
from statistics import mean
from scheduling_environment.jobShop import JobShop
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


def create_colormap():  # 用于创建一个颜色映射
    colors = [
        '#1f77b4', '#aec7e8', '#ff7f0e', '#ffbb78', '#2ca02c',
        '#98df8a', '#d62728', '#ff9896', '#9467bd', '#c5b0d5',
        '#8c564b', '#c49c94', '#e377c2', '#f7b6d2', '#7f7f7f',
        '#c7c7c7', '#bcbd22', '#dbdb8d', '#17becf', '#9edae5',
        '#393b79', '#637939', '#8c6d31', '#843c39', '#5254a3',
        '#6b4c9a', '#8ca252', '#bd9e39', '#ad494a', '#636363',
        '#8c6d8c', '#9c9ede', '#cedb9c', '#e7ba52', '#e7cb94',
        '#843c39', '#ad494a', '#d6616b', '#e7969c', '#7b4173',
        '#a55194', '#ce6dbd', '#de9ed6', '#f1b6da', '#fde0ef',
        '#636363', '#969696', '#bdbdbd', '#d9d9d9', '#f0f0f0',
        '#3182bd', '#6baed6', '#9ecae1', '#c6dbef', '#e6550d',
        '#fd8d3c', '#fdae6b', '#fdd0a2', '#31a354', '#74c476',
        '#a1d99b', '#c7e9c0', '#756bb1', '#9e9ac8', '#bcbddc',
        '#dadaeb', '#636363', '#969696', '#bdbdbd', '#d9d9d9',
        '#f0f0f0', '#a63603', '#e6550d', '#fd8d3c', '#fdae6b',
        '#fdd0a2', '#31a354', '#74c476', '#a1d99b', '#c7e9c0',
        '#756bb1', '#9e9ac8', '#bcbddc', '#dadaeb', '#636363',
        '#969696', '#bdbdbd', '#d9d9d9', '#f0f0f0', '#6a3d9a',
        '#8e7cc3', '#b5a0d8', '#ce6dbd', '#de9ed6', '#f1b6da',
        '#fde0ef', '#3182bd', '#6baed6', '#9ecae1', '#c6dbef'
    ]
    return mcolors.ListedColormap(colors)


# 绘制作业车间调度的甘特图
def draw_gantt_chart(JobShop):
    fig, ax = plt.subplots()  # 创建了一个图形对象 fig 和一个坐标轴对象 ax
    colormap = create_colormap()

    for machine in JobShop.machines:
        # 将该机器上已处理的操作按照开始时间进行排序，然后遍历每个操作
        machine_operations = sorted(machine._processed_operations, key=lambda op: op['start_time'])
        for operation in machine_operations:
            operation_start = operation['start_time']
            operation_end = operation['end_time']
            operation_duration = operation_end - operation_start
            operation_label = f"J{operation['operation'].job_id}O{operation['operation'].operation_id}"  # 将作业ID和操作ID结合起来作为标签
            # operation_label = f"{operation['operation'].operation_id}"  # 只使用操作ID作为标签

            # 根据作业ID来选择颜色，如果作业ID超过了颜色映射对象的数量，则进行取余操作来循环使用颜色
            color_index = operation['operation'].job_id % len(JobShop.jobs)
            if color_index >= colormap.N:
                color_index = color_index % colormap.N
            color = colormap(color_index)

            ax.broken_barh(  # 在图形上绘制一个水平的矩形框，表示每个操作的持续时间
                [(operation_start, operation_duration)],  # 表示矩形框的 x 轴起始位置和宽度
                (machine.machine_id - 0.4, 0.8),  # 表示矩形框的 y 轴起始位置和高度
                facecolors=color,  # 填充颜色
                edgecolor='black'  # 边框颜色
            )

            # 判断是否存在设置时间
            setup_start = operation['start_setup']
            setup_time = operation['setup_time']
            if setup_time != None:
                ax.broken_barh(  # 绘制一个灰色的小矩形框来表示设置时间
                    [(setup_start, setup_time)],
                    (machine.machine_id - 0.4, 0.8),
                    facecolors='grey',
                    edgecolor='black', linewidth=0.5, hatch='/')
            middle_of_operation = operation_start + operation_duration / 2
            ax.text(  # 在操作的中间位置添加文本标签
                middle_of_operation,
                machine.machine_id,  # 表示 y 轴方向
                operation_label,  # 显示的文本内容，即操作ID
                ha='center',
                va='center',
                fontsize=8
            )

    fig = ax.figure  # 获取当前绘图所在的 Figure 对象
    fig.set_size_inches(16, 8)

    ax.set_yticks(range(JobShop.nr_of_machines))  # 设置 y 轴刻度和标签
    ax.set_yticklabels([f'M{machine_id}' for machine_id in range(JobShop.nr_of_machines)])
    ax.set_xlabel('Time')
    ax.set_ylabel('Machine')
    ax.set_title('Job Shop Scheduling Gantt Chart')  # 设置图表标题
    ax.grid(False)  # 启用网格线

    plt.show()


def draw_precedence_relations(JobShop: JobShop):
    colormap = create_colormap()

    precedence_relations = copy.deepcopy(JobShop.precedence_relations_operations)
    G = nx.DiGraph()  # 根据先行关系构建了一个有向图 G

    # 将所有节点之间的先行关系表示为有向图的边
    for key, value in precedence_relations.items():
        value = [i.operation_id for i in value]  # 将其值（即操作列表）转换为操作 ID 的列表
        precedence_relations.update({key: value})  # 更新到 precedence_relations 字典中

    for key, value in precedence_relations.items():
        for i in range(len(value)):
            G.add_edge(value[i], key)  # 通过循环将其与该节点添加为有向图 G 的边

    left_nodes, right_nodes, middle_nodes = [], [], {}

    # 通过检查其在 precedence_relations 字典中的值（即操作列表）是否为空来确定其所属位置。
    for node in G.nodes:
        if precedence_relations[node] == []:  # 如果该节点没有前驱操作，则将其添加到 left_nodes 列表中
            left_nodes.append(node)

    for node in G.nodes:
        final = True
        for key, value in precedence_relations.items():
            if node in value:
                final = False
        if final:  # 如果该节点不在任何其他节点的后继操作列表中，则将其添加到 right_nodes 列表中
            right_nodes.append(node)

    max_length = 0  # 用于确定中间节点的位置信息
    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))  # 执行深度优先搜索
            middle_nodes[length] = []  # 键值对 {length: []} 其中 length 是该节点到其前驱节点的距离，空列表用于存储位于该距离处的所有节点
            if length > max_length:  # 计算每个中间节点到其前驱节点的最大距离
                max_length = length

    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))
            middle_nodes[length].append(node)

    # 左侧节点，节点的位置设置为 (0, i)，其中 i 是节点在列表 left_nodes 中的索引
    pos = {n: (0, i) for i, n in enumerate(left_nodes)}

    # 右侧节点
    if (max_length + 1 % 2) == 0:  # 是偶数，i 是节点在列表 right_nodes 中的索引
        pos.update({n: (max_length + 1, i) for i, n in enumerate(right_nodes)})
    else:
        pos.update({n: (max_length + 1, i + 0.5) for i, n in enumerate(right_nodes)})

    # 设置所有中间节点的位置 (according to number of predecessors)
    for key, value in middle_nodes.items():  # 键表示节点的标识，值是一个列表，包含具有相同标识的中间节点
        if (key % 2) == 0:  # 键是偶数
            pos.update({n: (max_length - key + 1, i) for i, n in enumerate(value)})
        else:  # 键是奇数
            pos.update({n: (max_length - key + 1, i + 0.5) for i, n in enumerate(value)})

    options = {
        "font_size": 8,  # 文字大小
        "node_size": 500,  # 节点大小
        "node_color": [],  # 节点颜色
        "edgecolors": "black",  # 边界颜色
        "linewidths": 1,  # 线宽
        "width": 1,  # 图表宽度
    }

    # 为节点基于其属性分配颜色
    for node in G.nodes:
        options["node_color"].append(colormap(JobShop.get_operation(node).job_id % colormap.N))

    # 使用给定的位置和选项绘制网络图
    nx.draw_networkx(G, pos, **options)

    ax = plt.gca()
    ax.margins(0.20)

    fig = ax.figure
    fig.set_size_inches(16, 8)

    plt.axis("off")
    plt.show()


def draw_gantt(env, current_date):
    fig, ax = plt.subplots()  # 创建了一个图形对象 fig 和一个坐标轴对象 ax
    colormap = create_colormap()
    batch_size = env.batch_size

    ma_gantt_batch = [[[] for _ in range(env.num_mas)] for __ in range(batch_size)]  # 保存每个机器上的操作列表
    for batch_id, schedules in enumerate(env.schedules_batch):
        for i in range(int(env.nums_opes[batch_id])):  # 表示该操作被分配到了batch_id号实例的第int(step[1])台机器上
            step = schedules[i]  # step[1]机器编号、2操作编号、3开始结束时间、4人员
            ma_gantt_batch[batch_id][int(step[1])].append([i, float('{:.2f}'.format(step[2].item())), float('{:.2f}'.format(step[3].item())), int(step[4].item())])
    for k in range(batch_size):
        ma_gantt = ma_gantt_batch[k]
        for i in range(env.num_mas):
            ma_gantt[i].sort(key=lambda s: s[1])
            # 将该机器上已处理的操作按照开始时间进行排序，然后遍历每个操作
            machine_operations = ma_gantt[i]
            for operation in machine_operations:
                operation_start = operation[1]
                operation_end = operation[2]
                operation_duration = operation_end - operation_start
                operation_label = f"J{env.opes_appertain_batch[k][operation[0]]}O{operation[0]}W{operation[3]}"  # 将作业ID和操作ID结合起来作为标签
                # operation_label = f"{operation[0]}"  # 只使用操作ID作为标签

                # 根据作业ID来选择颜色，如果作业ID超过了颜色映射对象的数量，则进行取余操作来循环使用颜色
                color_index = env.opes_appertain_batch[k][operation[0]] % env.num_jobs
                if color_index >= colormap.N:
                    color_index = color_index % colormap.N
                color = colormap(color_index)

                ax.broken_barh(  # 在图形上绘制一个水平的矩形框，表示每个操作的持续时间
                    [(operation_start, operation_duration)],  # 表示矩形框的 x 轴起始位置和宽度
                    (i - 0.4, 0.8),  # 表示矩形框的 y 轴起始位置和高度
                    facecolors=color,  # 填充颜色
                    edgecolor='black'  # 边框颜色
                )

                # # 判断是否存在设置时间
                # setup_start = operation['start_setup']
                # setup_time = operation['setup_time']
                # if setup_time != None:
                #     ax.broken_barh(  # 绘制一个灰色的小矩形框来表示设置时间
                #         [(setup_start, setup_time)],
                #         (i - 0.4, 0.8),
                #         facecolors='grey',
                #         edgecolor='black', linewidth=0.5, hatch='/')
                middle_of_operation = operation_start + operation_duration / 2
                ax.text(  # 在操作的中间位置添加文本标签
                    middle_of_operation,
                    i,  # 表示 y 轴方向
                    operation_label,  # 显示的文本内容，即操作ID
                    ha='center',
                    va='center',
                    fontsize=8
                )


    fig = ax.figure  # 获取当前绘图所在的 Figure 对象
    fig.set_size_inches(16, 8)

    ax.set_yticks(range(env.num_mas))  # 设置 y 轴刻度和标签
    ax.set_yticklabels([f'M{machine_id}' for machine_id in range(env.num_mas)])
    ax.set_xlabel('Time')
    ax.set_ylabel('Machine')
    ax.set_title('Job Shop Scheduling Gantt Chart')  # 设置图表标题
    ax.grid(False)  # 启用网格线

    plt.savefig(f'C:/Users/CGZ/Desktop/result/{current_date}(beat.png', format='png')
    plt.show()


def draw_pre_rela(env):
    colormap = create_colormap()

    precedence_relations = copy.deepcopy(env.pre_opes)
    G = nx.DiGraph()  # 根据先行关系构建了一个有向图 G

    # 将所有节点之间的先行关系表示为有向图的边
    for key, value in precedence_relations.items():
        value = [i.operation_id for i in value]  # 将其值（即操作列表）转换为操作 ID 的列表
        precedence_relations.update({key: value})  # 更新到 precedence_relations 字典中

    for key, value in precedence_relations.items():
        for i in range(len(value)):
            G.add_edge(value[i], key)  # 通过循环将其与该节点添加为有向图 G 的边

    left_nodes, right_nodes, middle_nodes = [], [], {}

    # 通过检查其在 precedence_relations 字典中的值（即操作列表）是否为空来确定其所属位置。
    for node in G.nodes:
        if precedence_relations[node] == []:  # 如果该节点没有前驱操作，则将其添加到 left_nodes 列表中
            left_nodes.append(node)

    for node in G.nodes:
        final = True
        for key, value in precedence_relations.items():
            if node in value:
                final = False
        if final:  # 如果该节点不在任何其他节点的后继操作列表中，则将其添加到 right_nodes 列表中
            right_nodes.append(node)

    max_length = 0  # 用于确定中间节点的位置信息
    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))  # 执行深度优先搜索
            middle_nodes[length] = []  # 键值对 {length: []} 其中 length 是该节点到其前驱节点的距离，空列表用于存储位于该距离处的所有节点
            if length > max_length:  # 计算每个中间节点到其前驱节点的最大距离
                max_length = length

    for node in G.nodes:
        if node not in left_nodes and node not in right_nodes:
            length = len(nx.nodes(nx.dfs_tree(G, node)))
            middle_nodes[length].append(node)

    # 左侧节点，节点的位置设置为 (0, i)，其中 i 是节点在列表 left_nodes 中的索引
    pos = {n: (0, i) for i, n in enumerate(left_nodes)}

    # 右侧节点
    if (max_length + 1 % 2) == 0:  # 是偶数，i 是节点在列表 right_nodes 中的索引
        pos.update({n: (max_length + 1, i) for i, n in enumerate(right_nodes)})
    else:
        pos.update({n: (max_length + 1, i + 0.5) for i, n in enumerate(right_nodes)})

    # 设置所有中间节点的位置 (according to number of predecessors)
    for key, value in middle_nodes.items():  # 键表示节点的标识，值是一个列表，包含具有相同标识的中间节点
        if (key % 2) == 0:  # 键是偶数
            pos.update({n: (max_length - key + 1, i) for i, n in enumerate(value)})
        else:  # 键是奇数
            pos.update({n: (max_length - key + 1, i + 0.5) for i, n in enumerate(value)})

    options = {
        "font_size": 8,  # 文字大小
        "node_size": 500,  # 节点大小
        "node_color": [],  # 节点颜色
        "edgecolors": "black",  # 边界颜色
        "linewidths": 1,  # 线宽
        "width": 1,  # 图表宽度
    }

    # 为节点基于其属性分配颜色
    for node in G.nodes:
        options["node_color"].append(colormap(env.opes_appertain_batch[:, node] % colormap.N))

    # 使用给定的位置和选项绘制网络图
    nx.draw_networkx(G, pos, **options)

    ax = plt.gca()
    ax.margins(0.20)

    fig = ax.figure
    fig.set_size_inches(16, 8)

    plt.axis("off")
    plt.show()


def draw_reward(env):
    batch_size = env.batch_size
    x = []
    reward = []
    makespan = []
    power = []
    ei = []
    for batch in range(batch_size):
        for ope in range(env.num_opes):
            x.append(ope)
            reward.append(env.reward_batch[batch, ope, 3])
            makespan.append(env.reward_batch[batch, ope, 0])
            power.append(env.reward_batch[batch, ope, 1])
            ei.append(env.reward_batch[batch, ope, 2])
    # 创建折线图
    plt.plot(x, reward, label='total_reward')
    plt.plot(x, makespan, label='makespan')
    plt.plot(x, power, label='power')
    plt.plot(x, ei, label='EI')

    # 添加标题和标签
    plt.title('Total Reward')
    plt.xlabel('N')
    plt.ylabel('reward')
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    plt.show()


